-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.

--[[
================================================================================
DragonUI Options Panel - Panels Tab
================================================================================
The reskinned Blizzard windows: Character Panel, Pets & Mounts, World Map, Loot Window, Talents and Spellbook.
================================================================================
]]

local addon = DragonUI
if not addon then return end

local LO = addon.LO
local C = addon.PanelControls
local Panel = addon.OptionsPanel

-- ============================================================================
-- HELPERS
-- ============================================================================

local function EnsureModuleTable(moduleName)
    return C:EnsureModuleTable(moduleName)
end

local function GetModuleField(moduleName, field)
    local m = addon.db.profile.modules
    return m and m[moduleName] and m[moduleName][field]
end

local function IsEnabled(moduleName)
    return GetModuleField(moduleName, "enabled") == true
end

-- ============================================================================
-- SUB-TABS
-- ============================================================================

local activeSubTab = "character"

local subTabs = {
    { key = "character",   label = LO["Character"] },
    { key = "collections", label = LO["Pets & Mounts"] },
    { key = "worldmap",    label = LO["World Map"] },
    { key = "loot",        label = LO["Loot Window"] },
    { key = "talents",     label = LO["Talents"] },
    { key = "spellbook",   label = LO["Spellbook"] },
    { key = "professions", label = LO["Professions"] },
}

-- Search navigation sub-tab setter.
Panel.subTabSetters = Panel.subTabSetters or {}
Panel.subTabSetters["panels"] = function(key) activeSubTab = key or "character" end

-- A window's own cog edits settings listed here; a rebuild would wipe search results.
addon.core.RegisterMessage(Panel, "DRAGONUI_WINDOW_SETTING_CHANGED", function(_, subTab)
    if activeSubTab ~= subTab or Panel.currentTab ~= "panels" then return end
    if Panel._lastRenderedQuery or not (Panel.frame and Panel.frame:IsShown()) then return end
    Panel:SelectTab("panels")
end)

-- ============================================================================
-- CHARACTER PANEL
-- ============================================================================

local function BuildCharacterSubTab(scroll)
    local cpSection = C:AddSection(scroll, LO["Character Panel"])

    C:AddDescription(cpSection, LO["Modern reskin of the Blizzard character window."])

    C:AddModuleToggle(cpSection, {
        label = LO["Enable Character Panel"],
        desc = LO["Apply the DragonUI reskin to the character window."],
        moduleName = "characterpanel",
        after = function() Panel:SelectTab("panels") end,
    })

    -- Keys sort in display order: the embedded dropdown lists them alphabetically.
    C:AddDropdown(cpSection, {
        label = LO["Portrait"],
        values = {
            character = LO["Character"],
            class = LO["Class Icon"],
            spec = LO["Specialization Icon"],
        },
        width = 200,
        getFunc = function()
            local CP = addon.CharacterPanel
            return CP and CP.PortraitStyle and CP.PortraitStyle() or "spec"
        end,
        setFunc = function(val)
            local cfg = EnsureModuleTable("characterpanel")
            cfg.portrait_style = val
            cfg.class_portrait = nil
            if addon.CharacterPanel and addon.CharacterPanel.UpdatePortrait then
                addon.CharacterPanel.UpdatePortrait()
            end
        end,
        disabled = function() return not IsEnabled("characterpanel") end,
    })

    C:AddToggle(cpSection, {
        label = LO["Class-Colored Level Text"],
        desc = LO["Color the class name in the \"Level X Race Class\" line."],
        getFunc = function()
            return GetModuleField("characterpanel", "class_level_text") ~= false
        end,
        setFunc = function(val)
            EnsureModuleTable("characterpanel").class_level_text = val
            if addon.CharacterPanel and addon.CharacterPanel.RefreshLevelText then
                addon.CharacterPanel.RefreshLevelText()
            end
        end,
        disabled = function() return not IsEnabled("characterpanel") end,
    })

    -- C:AddToggle(cpSection, {
    --     label = LO["Hide Model Controls"],
    --     desc = LO["Hide the rotate, zoom and reset buttons over the character model."],
    --     getFunc = function()
    --         return GetModuleField("characterpanel", "hide_model_controls") == true
    --     end,
    --     setFunc = function(val)
    --         EnsureModuleTable("characterpanel").hide_model_controls = val
    --         -- Rebuilt so the sub-option below picks up its new disabled state.
    --         Panel:SelectTab("panels")
    --     end,
    --     callback = function()
    --         local CP = addon.CharacterPanel
    --         if CP and CP.RefreshModelControls then CP.RefreshModelControls() end
    --     end,
    --     disabled = function() return not IsEnabled("characterpanel") end,
    --     requiresReload = false,
    -- })

    -- C:AddToggle(cpSection, {
    --     label = LO["Keep the Reset Button"],
    --     desc = LO["Leave the reset button on its own while the rest of the model controls stay hidden."],
    --     indent = 18,
    --     getFunc = function()
    --         return GetModuleField("characterpanel", "model_controls_reset_only") == true
    --     end,
    --     setFunc = function(val)
    --         EnsureModuleTable("characterpanel").model_controls_reset_only = val
    --     end,
    --     callback = function()
    --         local CP = addon.CharacterPanel
    --         if CP and CP.RefreshModelControls then CP.RefreshModelControls() end
    --     end,
    --     disabled = function()
    --         return not IsEnabled("characterpanel")
    --             or GetModuleField("characterpanel", "hide_model_controls") ~= true
    --     end,
    --     requiresReload = false,
    -- })

    -- Item Level draws these even on the stock window, so only that module greys them out.
    local function AddItemLevelToggle(field, label, desc)
        C:AddToggle(cpSection, {
            label = label,
            desc = desc,
            getFunc = function() return GetModuleField("itemlevel", field) == true end,
            setFunc = function(val)
                EnsureModuleTable("itemlevel")[field] = val
            end,
            callback = function()
                if addon.RefreshItemLevel then addon:RefreshItemLevel() end
                addon.Menu.Refresh()
            end,
            disabled = function() return not IsEnabled("itemlevel") end,
            requiresReload = false,
        })
    end

    AddItemLevelToggle("show_repair_cost", LO["Show Repair Cost"],
        LO["Show the total repair cost of your equipped items in the character window."])
    AddItemLevelToggle("show_durability", LO["Durability on Character Slots"],
        LO["Show each equipped item's durability percentage on its character panel slot, opposite the item level."])

    -- ====================================================================
    -- STATS SIDEBAR
    -- ====================================================================
--     C:AddSpacer(scroll)
--     local statsSection = C:AddSection(scroll, LO["Stats Sidebar"])

--     C:AddDescription(statsSection, LO["The headline numbers above the stat categories."])

--     local function RefreshSummary()
--         local CP = addon.CharacterPanel
--         if CP and CP.ApplyGearSummaryVisibility then CP.ApplyGearSummaryVisibility() end
--     end

--     C:AddToggle(statsSection, {
--         label = LO["Show Item Level"],
--         desc = LO["Show the average item level of your equipped gear."],
--         getFunc = function()
--             return GetModuleField("characterpanel", "show_item_level") ~= false
--         end,
--         setFunc = function(val)
--             EnsureModuleTable("characterpanel").show_item_level = val
--         end,
--         callback = RefreshSummary,
--         disabled = function() return not IsEnabled("characterpanel") end,
--         requiresReload = false,
--     })

--     C:AddToggle(statsSection, {
--         label = LO["Show GearScore"],
--         desc = LO["Show the GearScore of your equipped gear."],
--         getFunc = function()
--             return GetModuleField("characterpanel", "show_gear_score") == true
--         end,
--         setFunc = function(val)
--             EnsureModuleTable("characterpanel").show_gear_score = val
--         end,
--         callback = RefreshSummary,
--         disabled = function() return not IsEnabled("characterpanel") end,
--         requiresReload = false,
--     })
    -- C:AddToggle(statsSection, {
    --     label = LO["Show GearScore"],
    --     desc = LO["Show the GearScore of your equipped gear."],
    --     getFunc = function()
    --         return GetModuleField("characterpanel", "show_gear_score") == true
    --     end,
    --     setFunc = function(val)
    --         EnsureModuleTable("characterpanel").show_gear_score = val
    --     end,
    --     callback = RefreshSummary,
    --     disabled = function() return not IsEnabled("characterpanel") end,
    --     requiresReload = false,
    -- })

    -- C:AddDescription(statsSection, LO["Set which stat and which combat panel lead the list:"])

    -- C:AddDropdown(statsSection, {
    --     label = LO["Highlight Main Stat"],
    --     desc = LO["The attribute your class is built around."],
    --     values = {
    --         auto = LO["Auto (by class)"],
    --         off = LO["Off"],
    --         STRENGTH = _G.SPELL_STAT1_NAME,
    --         AGILITY = _G.SPELL_STAT2_NAME,
    --         STAMINA = _G.SPELL_STAT3_NAME,
    --         INTELLECT = _G.SPELL_STAT4_NAME,
    --         SPIRIT = _G.SPELL_STAT5_NAME,
    --     },
    --     getFunc = function()
    --         return GetModuleField("characterpanel", "stat_highlight") or "auto"
    --     end,
    --     setFunc = function(val)
    --         EnsureModuleTable("characterpanel").stat_highlight = val
    --     end,
    --     callback = function()
    --         local CP = addon.CharacterPanel
    --         if CP and CP.RefreshSidebar then CP.RefreshSidebar() end
    --     end,
    --     disabled = function() return not IsEnabled("characterpanel") end,
    --     requiresReload = false,
    -- })

    -- C:AddDropdown(statsSection, {
    --     label = LO["Combat Statistics"],
    --     desc = LO["Which one leads the list: Melee, Ranged, or Spell."],
    --     values = {
    --         auto = LO["Auto (by class)"],
    --         off = LO["Off"],
    --         PLAYERSTAT_MELEE_COMBAT = _G.PLAYERSTAT_MELEE_COMBAT,
    --         PLAYERSTAT_RANGED_COMBAT = _G.PLAYERSTAT_RANGED_COMBAT,
    --         PLAYERSTAT_SPELL_COMBAT = _G.PLAYERSTAT_SPELL_COMBAT,
    --     },
    --     getFunc = function()
    --         return GetModuleField("characterpanel", "combat_order") or "auto"
    --     end,
    --     setFunc = function(val)
    --         EnsureModuleTable("characterpanel").combat_order = val
    --     end,
    --     callback = function()
    --         local CP = addon.CharacterPanel
    --         if CP and CP.ApplyStatsAutoSort then CP.ApplyStatsAutoSort() end
    --     end,
    --     disabled = function() return not IsEnabled("characterpanel") end,
    --     requiresReload = false,
    -- })

    -- ====================================================================
    -- EQUIPMENT SET PER SPEC (per character, so it lives in db.char)
    -- ====================================================================
    C:AddSpacer(scroll)
    local specSection = C:AddSection(scroll, LO["Equipment Sets"])

    C:AddDescription(specSection, LO["Equip a set automatically when you switch talent specialization. Saved per character."])

    -- "" sorts first, so None leads the list.
    local setValues = { [""] = LO["None"] }
    for i = 1, (GetNumEquipmentSets and GetNumEquipmentSets() or 0) do
        local name = GetEquipmentSetInfo(i)
        if name then setValues[name] = name end
    end

    local function noDualSpec()
        return (GetNumTalentGroups and GetNumTalentGroups(false, false) or 1) < 2
    end

    for group = 1, 2 do
        C:AddDropdown(specSection, {
            label = addon.GetTalentSpecName and addon.GetTalentSpecName(group)
                or (group == 2 and _G.TALENT_SPEC_SECONDARY or _G.TALENT_SPEC_PRIMARY),
            values = setValues,
            getFunc = function()
                local sets = addon.db.char.specEquipmentSets
                local name = sets and sets[group]
                return (name and setValues[name]) and name or ""
            end,
            setFunc = function(val)
                local CP = addon.CharacterPanel
                if CP and CP.AssignSpecSet then CP.AssignSpecSet(group, val ~= "" and val or nil) end
            end,
            -- A set serves one spec, so the other dropdown may have just lost it.
            callback = function()
                addon:After(0, function()
                    if Panel.currentTab == "panels" then Panel:SelectTab("panels") end
                end)
            end,
            disabled = noDualSpec,
            width = 200,
        })
    end
end

-- ============================================================================
-- PETS & MOUNTS
-- ============================================================================

local function BuildCollectionsSubTab(scroll)
    local colSection = C:AddSection(scroll, LO["Pets & Mounts"])

    C:AddDescription(colSection, LO["A dedicated window for your mounts and companion pets, replacing the old Pet tab of the character window."])

    C:AddModuleToggle(colSection, {
        label = LO["Enable Pets & Mounts"],
        desc = LO["Add the Pets & Mounts micro menu button and its window."],
        moduleName = "collections",
    })

    -- ====================================================================
    -- KEY BINDING
    -- ====================================================================
    C:AddSpacer(scroll)
    local keySection = C:AddSection(scroll, LO["Key Binding"])

    C:AddDescription(keySection, LO["Opens the window without the micro menu."])

    C:AddKeybinding(keySection, {
        label = LO["Toggle Pets & Mounts"],
        desc = LO["Click, then press the key to bind. Press Escape to clear it."],
        action = "DRAGONUI_TOGGLE_COLLECTIONS",
        width = 240,
    })
end

-- ============================================================================
-- WORLD MAP
-- ============================================================================

local function BuildWorldMapSubTab(scroll)
    local mapSection = C:AddSection(scroll, LO["World Map"])

    C:AddDescription(mapSection, LO["Retail-style world map with breadcrumb navigation and a quest log side panel."])

    C:AddModuleToggle(mapSection, {
        label = LO["Enable World Map"],
        desc = LO["Apply the DragonUI reskin to the world map."],
        moduleName = "worldmap",
        after = function() Panel:SelectTab("panels") end,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Undiscovered Areas"],
        desc = LO["Draw the map art of areas you have not explored yet, dimmed."],
        getFunc = function() return GetModuleField("worldmap", "fog") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").fog = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Dungeon Entrances"],
        desc = LO["Show dungeon and raid entrance pins on zone maps."],
        getFunc = function() return GetModuleField("worldmap", "entrances") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").entrances = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Graveyards"],
        desc = LO["Show graveyard pins on zone maps."],
        getFunc = function() return GetModuleField("worldmap", "graveyards") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").graveyards = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Flight Points"],
        desc = LO["Show flight master pins on zone maps."],
        getFunc = function() return GetModuleField("worldmap", "flightPoints") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").flightPoints = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Inns"],
        desc = LO["Show innkeeper pins on zone maps, marking the inn your hearthstone is set to."],
        getFunc = function() return GetModuleField("worldmap", "inns") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").inns = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Landmarks"],
        desc = LO["Show towns, flight points and other landmark pins on the map."],
        getFunc = function() return GetModuleField("worldmap", "landmarks") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").landmarks = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Map Coordinates"],
        desc = LO["Show your coordinates and the cursor's in the corner of the map."],
        getFunc = function() return GetModuleField("worldmap", "coordinates") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").coordinates = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddToggle(mapSection, {
        label = LO["Show Zone Levels"],
        desc = LO["Show the recommended level range next to zone names and instance pins."],
        getFunc = function() return GetModuleField("worldmap", "zoneLevels") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").zoneLevels = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    -- Keys sort in display order: the embedded dropdown lists them alphabetically.
    C:AddDropdown(mapSection, {
        label = LO["Group Member Pins"],
        desc = LO["How party and raid members show on the world map and the battlefield map. Class colors and class icons also color their names in the tooltip and add their health."],
        values = {
            blizzard = LO["Default (Blizzard)"],
            color = LO["Class Colors"],
            icon = LO["Class Icons"],
        },
        width = 200,
        getFunc = function() return GetModuleField("worldmap", "groupPins") or "color" end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").groupPins = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
            addon.Menu.Refresh()
        end,
        disabled = function() return not IsEnabled("worldmap") end,
    })

    C:AddToggle(mapSection, {
        label = LO["Fade Map While Moving"],
        desc = LO["Dim the map while you move, unless the cursor is over it."],
        getFunc = function() return GetModuleField("worldmap", "fadeWhenMoving") ~= false end,
        setFunc = function(val)
            EnsureModuleTable("worldmap").fadeWhenMoving = val
            if addon.RefreshWorldMapSystem then addon.RefreshWorldMapSystem() end
            addon.Menu.Refresh()
            Panel:SelectTab("panels")
        end,
        disabled = function() return not IsEnabled("worldmap") end,
        requiresReload = false,
    })

    C:AddSlider(mapSection, {
        label = LO["Moving Map Alpha"],
        desc = LO["How visible the map stays while you move."],
        dbPath = "modules.worldmap.moveAlpha",
        min = 0.1,
        max = 1,
        step = 0.05,
        isPercent = true,
        width = 200,
        callback = function() addon.Menu.Refresh() end,
        disabled = function()
            return not IsEnabled("worldmap") or GetModuleField("worldmap", "fadeWhenMoving") == false
        end,
    })
end

-- ============================================================================
-- LOOT WINDOW
-- ============================================================================

local function BuildLootSubTab(scroll)
    local lootSection = C:AddSection(scroll, LO["Loot Window"])

    C:AddDescription(lootSection, LO["Configure the DragonUI loot window."])

    C:AddToggle(lootSection, {
        label = LO["Enable Loot Window"],
        desc = LO["Apply the DragonUI skin to the Blizzard loot window."],
        getFunc = function() return IsEnabled("loot_skin") end,
        setFunc = function(val)
            EnsureModuleTable("loot_skin").enabled = val
            if addon.LootSkinModule then addon.LootSkinModule:Refresh() end
            Panel:SelectTab("panels")
        end,
        requiresReload = false,
    })

    C:AddToggle(lootSection, {
        label = LO["Open at Cursor"],
        desc = LO["Open the loot window at the cursor instead of its saved position."],
        getFunc = function()
            return GetCVar and GetCVar("lootUnderMouse") == "1"
        end,
        setFunc = function(val)
            if SetCVar then SetCVar("lootUnderMouse", val and "1" or "0") end
            if addon.LootSkinModule then addon.LootSkinModule:ApplySavedPosition() end
        end,
        disabled = function() return not IsEnabled("loot_skin") end,
        requiresReload = false,
    })

    C:AddDescription(lootSection, LO["Disable Open at Cursor, then drag the loot window to save its position."])
    C:AddDescription(lootSection, LO["If auto loot is on, hold your auto loot key (Shift by default) while looting, then drag the window to save its position."])

    C:AddToggle(lootSection, {
        label = LO["Animate Loot Reflow"],
        desc = LO["Smoothly close gaps and resize the loot window after collecting items."],
        getFunc = function()
            return GetModuleField("loot_skin", "animated_reflow") ~= false
        end,
        setFunc = function(val)
            EnsureModuleTable("loot_skin").animated_reflow = val
            if addon.LootSkinModule then addon.LootSkinModule:RefreshSettings() end
        end,
        disabled = function() return not IsEnabled("loot_skin") end,
        requiresReload = false,
    })

    C:AddToggle(lootSection, {
        label = LO["Auto-Hide Empty Loot"],
        desc = LO["Close the loot window when there is nothing left to loot."],
        getFunc = function()
            return GetModuleField("loot_skin", "auto_hide_empty") == true
        end,
        setFunc = function(val)
            EnsureModuleTable("loot_skin").auto_hide_empty = val
        end,
        disabled = function() return not IsEnabled("loot_skin") end,
        requiresReload = false,
    })

    C:AddSlider(lootSection, {
        label = LO["Auto Loot Hold"],
        desc = LO["Seconds auto-looted items stay in the loot window before sliding out. Clicks pass through while they wait. 0 slides them out at once."],
        getFunc = function()
            return GetModuleField("loot_skin", "auto_loot_hold") or 0
        end,
        setFunc = function(val)
            EnsureModuleTable("loot_skin").auto_loot_hold = val
        end,
        min = 0, max = 5, step = 0.5,
        width = 200,
        disabled = function() return not IsEnabled("loot_skin") end,
    })

    C:AddSpacer(lootSection)

    C:AddButton(lootSection, {
        label = LO["Reset Loot Window Position"],
        desc = LO["Clear the saved position. The Blizzard default will be used next time you open the loot window."],
        callback = function()
            if addon.LootSkinModule then addon.LootSkinModule:ResetPosition() end
        end,
        disabled = function() return not IsEnabled("loot_skin") end,
    })
end

-- ============================================================================
-- TALENTS
-- ============================================================================

local function TalentSettings()
    addon.db.profile.talents = addon.db.profile.talents or {}
    return addon.db.profile.talents
end

local function BuildTalentsSubTab(scroll)
    local talentSection = C:AddSection(scroll, LO["Talents"])

    C:AddDescription(talentSection, LO["Retail-style talent window"])

    C:AddModuleToggle(talentSection, {
        label = LO["Enable Talent Window"],
        desc = LO["Replace Blizzard's talent and glyph window."],
        moduleName = "talents",
        after = function() Panel:SelectTab("panels") end,
    })

    C:AddSlider(talentSection, {
        label = LO["Scale"],
        desc = LO["Size of the talent window on top of your UI scale; 1.0 matches the other panels. It never grows past the screen."],
        min = 0.5,
        max = 1.5,
        step = 0.05,
        width = 200,
        getFunc = function() return TalentSettings().scale or 1 end,
        setFunc = function(val)
            TalentSettings().scale = val
            local T = addon.TalentModule
            if T and T.ApplyScale then T.ApplyScale() end
        end,
        disabled = function() return not IsEnabled("talents") end,
    })

    local glyphSection = C:AddSection(scroll, _G.GLYPHS)

    C:AddToggle(glyphSection, {
        label = LO["Show Glyph Names"],
        desc = LO["Name each inscribed glyph beside its socket."],
        getFunc = function() return TalentSettings().glyph_names == true end,
        setFunc = function(val)
            TalentSettings().glyph_names = val
            local T = addon.TalentModule
            if T and T.GlyphsRefresh then T.GlyphsRefresh() end
        end,
        disabled = function() return not IsEnabled("talents") end,
        requiresReload = false,
    })

    C:AddToggle(glyphSection, {
        label = LO["Show Glyph Effects"],
        desc = LO["List what your inscribed glyphs do beside the sockets."],
        getFunc = function() return TalentSettings().glyph_effects ~= false end,
        setFunc = function(val)
            TalentSettings().glyph_effects = val
            local T = addon.TalentModule
            if T and T.GlyphsRefresh then T.GlyphsRefresh() end
        end,
        disabled = function() return not IsEnabled("talents") end,
        requiresReload = false,
    })
end

-- ============================================================================
-- SPELLBOOK
-- ============================================================================
local function BuildSpellbookSubTab(scroll)
    local sbSection = C:AddSection(scroll, LO["Spellbook"])
    C:AddDescription(sbSection, LO["Scale the spellbook window."])

    C:AddModuleToggle(sbSection, {
        label = LO["Enable Spellbook"],
        desc = LO["Enable the DragonUI spellbook module."],
        moduleName = "spellbook",
        after = function() Panel:SelectTab("panels") end,
    })

    C:AddSlider(sbSection, {
        label = LO["Spellbook Content Scale"],
        desc = LO["Scales the pages, cards and controls inside the spellbook; its frame keeps its size."],
        dbPath = "modules.spellbook.scale",
        min = 0.5,
        max = 1.2,
        step = 0.05,
        width = 200,
        disabled = function() return not IsEnabled("spellbook") end,
        callback = function(val)
            addon.RefreshSpellbookScale(val)
        end,
    })

    C:AddToggle(sbSection, {
        label = LO["Show Lower Rank Selector"],
        desc = LO["Spell cards with lower ranks offer them through the selector chosen below."],
        dbPath = "modules.spellbook.rankSelectorShown",
        disabled = function() return not IsEnabled("spellbook") end,
        callback = function()
            addon.RefreshSpellbookRankSelector()
            Panel:SelectTab("panels")
        end,
    })

    C:AddDropdown(sbSection, {
        label = LO["Lower rank selector"],
        desc = LO["How a spell card offers its lower ranks: a menu under the icon or a side flyout."],
        dbPath = "modules.spellbook.rankSelector",
        values = {
            dropdown = LO["Menu under the icon"],
            flyout = LO["Side flyout"],
        },
        width = 200,
        disabled = function()
            return not IsEnabled("spellbook") or GetModuleField("spellbook", "rankSelectorShown") == false
        end,
        callback = function(val)
            addon.RefreshSpellbookRankSelector(val)
        end,
    })
end

-- ============================================================================
-- PROFESSIONS
-- ============================================================================
local function BuildProfessionsSubTab(scroll)
    local section = C:AddSection(scroll, LO["Professions"])
    C:AddDescription(section, LO["Forever-style professions window with side tabs and an overview page."])

    C:AddModuleToggle(section, {
        label = LO["Enable Professions"],
        desc = LO["Use the Forever professions window instead of the stock one."],
        moduleName = "professions",
        after = function() Panel:SelectTab("panels") end,
    })

    C:AddSlider(section, {
        label = LO["Professions Window Scale"],
        desc = LO["Scales the whole professions window; the room it takes beside other panels follows its size."],
        dbPath = "modules.professions.scale",
        min = 0.6,
        max = 1.2,
        step = 0.05,
        width = 200,
        disabled = function() return not IsEnabled("professions") end,
        callback = function(val)
            if addon.RefreshProfessionsScale then addon.RefreshProfessionsScale(val) end
        end,
    })

    C:AddSlider(section, {
        label = LO["Side Tabs Scale"],
        desc = LO["Scales only the profession tabs beside the window, on top of the window scale."],
        dbPath = "modules.professions.tabScale",
        min = 0.5,
        max = 1,
        step = 0.05,
        width = 200,
        disabled = function() return not IsEnabled("professions") end,
        callback = function()
            if addon.RefreshProfessionsTabScale then addon.RefreshProfessionsTabScale() end
        end,
    })

    -- Same setting as the Micro Menu tab's toggle.
    C:AddToggle(section, {
        label = LO["Professions Micro Button"],
        desc = LO["Show the Professions button in the micro menu. It opens the professions overview."],
        dbPath = "modules.professions.micro_button",
        disabled = function() return not IsEnabled("professions") end,
        callback = function()
            if addon.RefreshProfessionsMicroButton then addon.RefreshProfessionsMicroButton(true) end
        end,
    })
end

-- ============================================================================
-- SUB-TAB DISPATCH
-- ============================================================================

local subTabBuilders = {
    character   = BuildCharacterSubTab,
    collections = BuildCollectionsSubTab,
    worldmap    = BuildWorldMapSubTab,
    loot        = BuildLootSubTab,
    talents     = BuildTalentsSubTab,
    spellbook   = BuildSpellbookSubTab,
    professions = BuildProfessionsSubTab,
}

-- ============================================================================
-- MAIN TAB BUILDER
-- ============================================================================

local function BuildPanelsTab(scroll)
    C:AddSubTabs(scroll, subTabs, activeSubTab, function(key)
        activeSubTab = key
        Panel:SelectTab("panels")
    end, subTabBuilders)

    if not Panel.indexing then
        local builder = subTabBuilders[activeSubTab]
        if builder then builder(scroll) end
    end
end

-- Register the tab
-- Straight after Enhancements, whose Character Panel and Pets & Mounts sections moved here.
Panel:RegisterTab("panels", LO["Panels"], BuildPanelsTab, 11.5)
