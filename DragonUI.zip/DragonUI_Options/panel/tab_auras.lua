-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.

--[[
================================================================================
DragonUI Options Panel - Auras Tab
================================================================================
Player buff/debuff layout, weapon enchants, aura borders, and target/focus auras.
================================================================================
]]

local addon = DragonUI
if not addon then return end

local floor = math.floor
local LO = addon.LO
local C = addon.PanelControls
local Panel = addon.OptionsPanel

local function RefreshTargetFocusAuraTimers()
    if addon.RefreshAuraCooldownTextSystem then
        addon.RefreshAuraCooldownTextSystem()
    end
end

local function RefreshTargetFocusAuraLayout()
    if addon.RefreshTargetFocusAuraLayout then
        addon.RefreshTargetFocusAuraLayout()
    end
end

local function RefreshFocusFrame()
    if addon.RefreshFocusFrame then addon.RefreshFocusFrame() end
end

-- Discrete steps mapped to real wrap math: N per full 122px row -> size = floor(125/N) - 3; 6 = Blizzard 17px.
local function PerRowToSize(perRow)
    return math.floor(125 / perRow) - 3
end

local function SizeToPerRow(size)
    if not size or size <= 0 then
        size = 17
    end
    local perRow = math.floor(125 / (size + 3))
    if perRow < 4 then perRow = 4 end
    if perRow > 8 then perRow = 8 end
    return perRow
end

-- Reflects the effective layout size (icon_size x icon_scale), matching GetCustomAuraSizes in target.lua.
local function EffectivePerRow(auraCfg)
    local size = tonumber(auraCfg and auraCfg.icon_size) or 0
    local scale = tonumber(auraCfg and auraCfg.icon_scale) or 1
    if size <= 0 then
        size = 17
    end
    return SizeToPerRow(math.floor(size * scale + 0.5))
end

local function RefreshPlayerAuraSpacing()
    if addon.BuffFrameModule and addon.BuffFrameModule.RefreshAuraSpacing then
        addon.BuffFrameModule:RefreshAuraSpacing()
        return
    end

    if BuffFrame_UpdateAllBuffAnchors then
        BuffFrame_UpdateAllBuffAnchors()
    end
    if addon.BuffFrameModule then
        addon.BuffFrameModule:UpdatePosition()
    end
end

local AURA_ANCHORS = {
    TOP = LO["Top"],
    BOTTOM = LO["Bottom"],
    LEFT = LO["Left"],
    RIGHT = LO["Right"],
    CENTER = LO["Center"],
    TOPLEFT = LO["Top Left"],
    TOPRIGHT = LO["Top Right"],
    BOTTOMLEFT = LO["Bottom Left"],
    BOTTOMRIGHT = LO["Bottom Right"],
}

local AURA_FONTS = {
    actionbar = LO["Actionbar Font"],
    primary = LO["Primary Font"],
    narrow = LO["Narrow Font"],
    arial = LO["Arial Font"],
    system = LO["System Font"],
}

local function GetAuraCooldownConfig()
    local modules = addon.db and addon.db.profile and addon.db.profile.modules
    modules = modules or {}
    modules.auracooldowns = modules.auracooldowns or {}
    modules.auracooldowns.target = modules.auracooldowns.target or {}
    modules.auracooldowns.focus = modules.auracooldowns.focus or {}
    modules.auracooldowns.buffs = modules.auracooldowns.buffs or {}
    modules.auracooldowns.debuffs = modules.auracooldowns.debuffs or {}

    if modules.auracooldowns.target.max_duration_minutes == nil and type(modules.auracooldowns.target.max_duration) == "number" then
        modules.auracooldowns.target.max_duration_minutes = floor((modules.auracooldowns.target.max_duration / 60) + 0.5)
    end
    if modules.auracooldowns.focus.max_duration_minutes == nil and type(modules.auracooldowns.focus.max_duration) == "number" then
        modules.auracooldowns.focus.max_duration_minutes = floor((modules.auracooldowns.focus.max_duration / 60) + 0.5)
    end

    if modules.auracooldowns.target.enabled == nil then
        local timerUnits = modules.auracooldowns.timer_units
        modules.auracooldowns.target.enabled = modules.auracooldowns.timers_enabled == true and (timerUnits == "target" or timerUnits == "both") or false
    end
    if modules.auracooldowns.focus.enabled == nil then
        local timerUnits = modules.auracooldowns.timer_units
        modules.auracooldowns.focus.enabled = modules.auracooldowns.timers_enabled == true and (timerUnits == "focus" or timerUnits == "both") or false
    end

    modules.auracooldowns.timers_enabled = modules.auracooldowns.target.enabled == true or modules.auracooldowns.focus.enabled == true
    modules.auracooldowns.enabled = modules.auracooldowns.icons_enabled == true or modules.auracooldowns.timers_enabled == true

    return modules.auracooldowns
end

local function IsTimerCustomizationEnabled()
    return GetAuraCooldownConfig().timers_enabled == true
end

local function IsIconCustomizationEnabled()
    return GetAuraCooldownConfig().icons_enabled == true
end

local function SyncAuraModuleEnabled(cfg)
    cfg.enabled = cfg.icons_enabled == true or cfg.timers_enabled == true
end

local function SetAuraFeatureEnabled(featureKey, value)
    local cfg = GetAuraCooldownConfig()
    cfg[featureKey] = value and true or false
    SyncAuraModuleEnabled(cfg)
end

local function SyncAuraTimerState(cfg)
    cfg.timers_enabled = cfg.target.enabled == true or cfg.focus.enabled == true
    SyncAuraModuleEnabled(cfg)
end

local function SetAuraUnitEnabled(unitKey, value)
    local cfg = GetAuraCooldownConfig()
    cfg[unitKey].enabled = value and true or false
    SyncAuraTimerState(cfg)
end

local function IsTargetTimerSettingsDisabled()
    return not IsTimerCustomizationEnabled() or GetAuraCooldownConfig().target.enabled ~= true
end

local function IsFocusTimerSettingsDisabled()
    return not IsTimerCustomizationEnabled() or GetAuraCooldownConfig().focus.enabled ~= true
end

local function GetAuraCooldownDefaults()
    local defaults = addon.defaults
        and addon.defaults.profile
        and addon.defaults.profile.modules
        and addon.defaults.profile.modules.auracooldowns
    return defaults
end

local function ResetAuraTimerSettings()
    local defaults = GetAuraCooldownDefaults()
    if not defaults then return end

    local cfg = GetAuraCooldownConfig()

    cfg.duration_anchor = defaults.duration_anchor
    cfg.duration_offset_x = defaults.duration_offset_x
    cfg.duration_offset_y = defaults.duration_offset_y
    cfg.duration_font = defaults.duration_font

    cfg.target.enabled = defaults.target and defaults.target.enabled == true or false
    cfg.target.min_duration = defaults.target and defaults.target.min_duration or 0
    cfg.target.max_duration_minutes = defaults.target and defaults.target.max_duration_minutes or 0
    cfg.target.font_size = defaults.target and defaults.target.font_size or 11

    cfg.focus.enabled = defaults.focus and defaults.focus.enabled == true or false
    cfg.focus.min_duration = defaults.focus and defaults.focus.min_duration or 0
    cfg.focus.max_duration_minutes = defaults.focus and defaults.focus.max_duration_minutes or 0
    cfg.focus.font_size = defaults.focus and defaults.focus.font_size or 11

    SyncAuraTimerState(cfg)
end

local function ResetAuraIconSettings()
    local defaults = GetAuraCooldownDefaults()
    if not defaults then return end

    local cfg = GetAuraCooldownConfig()

    cfg.icons_enabled = defaults.icons_enabled == true
    cfg.stack_anchor = defaults.stack_anchor
    cfg.stack_offset_x = defaults.stack_offset_x
    cfg.stack_offset_y = defaults.stack_offset_y
    cfg.count_font = defaults.count_font
    cfg.buffs = addon.DeepCopy(defaults.buffs or {}, {})
    cfg.debuffs = addon.DeepCopy(defaults.debuffs or {}, {})

    SyncAuraModuleEnabled(cfg)
end

-- ============================================================================
-- AURAS TAB BUILDER
-- ============================================================================

local function GetAuraBordersField(field)
    local m = addon.db.profile.modules
    return m and m.auraborders and m.auraborders[field]
end

local function IsAuraBordersEnabled()
    return GetAuraBordersField("enabled") == true
end

local function RefreshAuraBorders()
    if addon.RefreshAuraBordersSystem then
        addon.RefreshAuraBordersSystem()
    end
end

-- Dropdown index order; options dropdowns list entries by key.
local BORDER_STYLES = { "detailed", "rounded", "square" }

-- Detailed keeps the untinted action-bar art, so the buff color only drives Rounded and Square.
local function IsBuffColorDisabled()
    local style = GetAuraBordersField("border_style")
    return not IsAuraBordersEnabled() or (style ~= "rounded" and style ~= "square")
end

-- ============================================================================
-- ACTIVE SUB-TAB STATE
-- ============================================================================

local activeSubTab = "player"

local subTabs = {
    { key = "player", label = LO["Player"] },
    { key = "targetfocus", label = LO["Target"] .. " / " .. LO["Focus"] },
}

-- Search navigation sub-tab setter.
Panel.subTabSetters = Panel.subTabSetters or {}
Panel.subTabSetters["auras"] = function(key) activeSubTab = key or "player" end

-- Borders and tooltips reach every aura icon, so they sit above the sub-tabs.
local function BuildAuraStyle(scroll)
    -- ====================================================================
    -- AURA BORDERS
    -- ====================================================================
    local borderSection = C:AddSection(scroll, LO["Aura Borders"])

    C:AddToggle(borderSection, {
        label = LO["Enable Aura Borders"],
        desc = LO["Show modern borders around buff and debuff icons."],
        getFunc = function() return IsAuraBordersEnabled() end,
        setFunc = function(val)
            C:EnsureModuleTable("auraborders").enabled = val
        end,
        callback = function()
            RefreshAuraBorders()
            -- Rebuild so the style dropdown / color enable-state refresh at once.
            Panel:SelectTab("auras")
        end,
        requiresReload = false,
    })

    local buffColorPicker

    C:AddDropdown(borderSection, {
        label = LO["Border Style"],
        values = {
            [1] = LO["Detailed"],
            [2] = LO["Rounded"],
            [3] = LO["Square"],
        },
        getFunc = function()
            local style = GetAuraBordersField("border_style")
            for index, key in ipairs(BORDER_STYLES) do
                if key == style then return index end
            end
            return 1
        end,
        setFunc = function(val)
            C:EnsureModuleTable("auraborders").border_style = BORDER_STYLES[val] or BORDER_STYLES[1]
        end,
        callback = function()
            RefreshAuraBorders()
            if buffColorPicker and buffColorPicker.SetDisabled then
                buffColorPicker:SetDisabled(IsBuffColorDisabled())
            end
        end,
        disabled = function() return not IsAuraBordersEnabled() end,
        width = 200,
    })

    buffColorPicker = C:AddColorPicker(borderSection, {
        label = LO["Buff Border Color"],
        getFunc = function()
            local c = GetAuraBordersField("buff_color")
            if c and c.r then return c.r, c.g, c.b end
            return 0.2, 0.2, 0.2
        end,
        setFunc = function(r, g, b)
            local ab = C:EnsureModuleTable("auraborders")
            ab.buff_color = { r = r, g = g, b = b }
            -- Keep this color across reloads even if Dark Mode stays enabled.
            ab.buff_color_user_override = true
        end,
        callback = RefreshAuraBorders,
        disabled = IsBuffColorDisabled,
        hasAlpha = false,
    })

    C:AddSpacer(scroll)

    -- ====================================================================
    -- AURA TOOLTIPS
    -- ====================================================================
    local tooltipSection = C:AddSection(scroll, LO["Aura Tooltips"])

    C:AddToggle(tooltipSection, {
        label = LO["Show Spell IDs"],
        desc = LO["Show spell IDs on aura, spell and chat-link tooltips. Requires the Tooltip module."],
        getFunc = function()
            local tt = addon.db.profile.modules and addon.db.profile.modules.tooltip
            return tt and tt.show_aura_spell_id == true
        end,
        setFunc = function(val)
            C:EnsureModuleTable("tooltip").show_aura_spell_id = val
        end,
        disabled = function()
            local tt = addon.db.profile.modules and addon.db.profile.modules.tooltip
            return not (tt and tt.enabled == true)
        end,
        requiresReload = false,
    })

    C:AddSpacer(scroll)
end

local function BuildPlayerAuras(scroll)
    -- ====================================================================
    -- WEAPON ENCHANTS
    -- ====================================================================
    local weaponSection = C:AddSection(scroll, LO["Weapon Enchants"])

    C:AddDescription(weaponSection,
        LO["Weapon enchant icons include rogue poisons, sharpening stones, wizard oils, and similar temporary weapon enhancements."])

    C:AddToggle(weaponSection, {
        label = LO["Separate Weapon Enchants"],
        desc = LO["Detach weapon enchant icons (poisons, sharpening stones, etc.) from the buff bar into their own independently moveable frame. Position it freely using Editor Mode."],
        getFunc = function()
            return addon.db.profile.buffs and addon.db.profile.buffs.separate_weapon_enchants
        end,
        setFunc = function(val)
            if not addon.db.profile.buffs then addon.db.profile.buffs = {} end
            addon.db.profile.buffs.separate_weapon_enchants = val
        end,
        callback = function(val)
            if addon.BuffFrameModule then
                addon.BuffFrameModule:ToggleWeaponEnchantSeparation(val)
            end
        end,
        requiresReload = false,
    })

    C:AddDescription(weaponSection,
        "|cff888888" .. LO["When enabled, a 'Weapon Enchants' mover appears in Editor Mode that you can drag to any position on screen."] .. "|r")

    C:AddSpacer(weaponSection)

    -- ====================================================================
    -- VANITY BUFFS (Conquest of Azeroth)
    -- ====================================================================
    local vanitySection = C:AddSection(scroll, LO["Vanity Buffs"])

    C:AddDescription(vanitySection,
        LO["Vanity buffs are cosmetic auras consolidated by Conquest of Azeroth (mounts, toys, transmog effects). The consolidated container is provided by the Ascension_VanityCollection addon."])

    C:AddToggle(vanitySection, {
        label = LO["Hide Vanity Buffs"],
        desc = LO["Hide the Conquest of Azeroth vanity-buff consolidated container and its contained auras from the buff frame. Existing buff order and positioning are preserved."],
        dbPath = "buffs.hide_vanity_buffs",
        callback = function()
            if addon.BuffFrameModule and addon.BuffFrameModule.RefreshVanityBuffsVisibility then
                addon.BuffFrameModule:RefreshVanityBuffsVisibility()
            end
        end,
    })

    C:AddSpacer(scroll)
    local playerAuraSection = C:AddSection(scroll, LO["Player Buffs & Debuffs"])

    C:AddDescription(playerAuraSection,
        LO["Layout settings for the player buff and debuff bar. These do not affect target or focus auras."])

    C:AddToggle(playerAuraSection, {
        label = LO["Show Toggle Button"],
        desc = LO["Show a collapse/expand button next to the buff icons."],
        dbPath = "buffs.show_toggle_button",
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddHeading(playerAuraSection, LO["Buffs"])

    C:AddDropdown(playerAuraSection, {
        label = LO["Buff Order"],
        desc = LO["How to sort player buff icons on the buff bar."],
        dbPath = "buffs.buff_order",
        values = {
            blizzard = LO["Default (Blizzard)"],
            player_first = LO["Player Buffs First"],
            other_first = LO["Other Player Buffs First"],
            duration = LO["Duration Buffs First"],
        },
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Buff Icon Scale"],
        dbPath = "buffs.buff_scale",
        min = 0.5, max = 2, step = 0.05,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Buffs Per Row"],
        desc = LO["How many buff icons to show in each row."],
        dbPath = "buffs.buffs_per_row",
        min = 1, max = 32, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Max Buff Rows"],
        desc = LO["Maximum number of buff rows to display. Use 0 for no limit."],
        dbPath = "buffs.max_buff_rows",
        min = 0, max = 10, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Buff Horizontal Gap"],
        dbPath = "buffs.buff_horizontal_gap",
        min = 0, max = 20, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Buff Vertical Gap"],
        desc = LO["Space between buff rows."],
        dbPath = "buffs.buff_vertical_gap",
        min = 0, max = 40, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddHeading(playerAuraSection, LO["Debuffs"])

    C:AddToggle(playerAuraSection, {
        label = LO["Show Debuffs"],
        desc = LO["Show your debuffs on the player aura bar."],
        dbPath = "buffs.show_debuffs",
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Debuff Icon Scale"],
        dbPath = "buffs.debuff_scale",
        min = 0.5, max = 2, step = 0.05,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Debuffs Per Row"],
        desc = LO["How many debuff icons to show in each row."],
        dbPath = "buffs.debuffs_per_row",
        min = 1, max = 32, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Max Debuff Rows"],
        desc = LO["Maximum number of debuff rows to display. Use 0 for no limit."],
        dbPath = "buffs.max_debuff_rows",
        min = 0, max = 10, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Debuff Horizontal Gap"],
        dbPath = "buffs.debuff_horizontal_gap",
        min = 0, max = 20, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Debuff Vertical Gap"],
        desc = LO["Space between debuff rows."],
        dbPath = "buffs.debuff_vertical_gap",
        min = 0, max = 40, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Debuff Attached Offset Y"],
        desc = LO["Vertical gap below the buff bar when debuffs are attached (not detached in Editor Mode)."],
        dbPath = "buffs.debuff_offset_y",
        min = 0, max = 120, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddHeading(playerAuraSection, LO["Layout Preview"])

    C:AddDescription(playerAuraSection,
        LO["Shows fake buff and debuff icons so you can tune scale, rows, and spacing without needing real auras. Turn this off when finished."])

    C:AddToggle(playerAuraSection, {
        label = LO["Enable Layout Preview"],
        dbPath = "buffs.layout_preview",
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Preview Buff Count"],
        dbPath = "buffs.layout_preview_buffs",
        min = 0, max = 64, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })

    C:AddSlider(playerAuraSection, {
        label = LO["Preview Debuff Count"],
        dbPath = "buffs.layout_preview_debuffs",
        min = 0, max = 40, step = 1,
        width = 220,
        callback = RefreshPlayerAuraSpacing,
    })


    -- ====================================================================
    -- RESET POSITION
    -- ====================================================================
    C:AddSpacer(scroll)
    local resetSection = C:AddSection(scroll, LO["Positions"])

    C:AddButton(resetSection, {
        label = LO["Reset Buff Frame Position"],
        width = 220,
        callback = function()
            if addon.BuffFrameModule then
                addon.BuffFrameModule:ResetBuffFramePosition()
            end
            addon:Print(LO["Buff frame position reset."])
        end,
    })

    C:AddButton(resetSection, {
        label = LO["Reset Weapon Enchant Position"],
        width = 220,
        callback = function()
            if addon.db.profile.widgets and addon.db.profile.widgets.weapon_enchants then
                local w = addon.db.profile.widgets.weapon_enchants
                w.anchor = "TOPRIGHT"
                w.posX = -100
                w.posY = -15
                w.custom_position = false
            end
            if addon.BuffFrameModule then
                addon.BuffFrameModule:UpdateWeaponEnchantPosition()
            end
            addon:Print(LO["Weapon enchant position reset."])
        end,
    })

    C:AddSpacer(resetSection)

    local isDebuffDetached = C:GetDBValue("widgets.debuffs.custom_position")
    if isDebuffDetached then
        C:AddDescription(resetSection, "|cff" .. C.Theme.accentHex .. "- " .. LO["Debuffs detached - positioned freely via Editor Mode"] .. "|r")
    else
        C:AddDescription(resetSection, "|cffaaaaaa- " .. LO["Debuffs attached - follow buff row"] .. "|r")
    end

    C:AddButton(resetSection, {
        label = LO["Reset Debuff Position"],
        width = 220,
        disabled = function()
            return not C:GetDBValue("widgets.debuffs.custom_position")
        end,
        callback = function()
            if addon.BuffFrameModule then
                addon.BuffFrameModule:ResetDebuffPosition()
            end
            addon:Print(LO["Debuff position reset."])
            Panel:SelectTab("auras")
        end,
    })
end

local function BuildTargetFocusAuras(scroll)
    -- ====================================================================
    -- TARGET/FOCUS AURA CUSTOMIZATION
    -- ====================================================================
    -- Same settings as the Unit Frames sub-tabs (one database key each), repeated here where the aura options live.
    local showSection = C:AddSection(scroll, LO["Show Auras"])

    C:AddHeading(showSection, LO["Target"])
    C:AddToggle(showSection, {
        label = LO["Show Buffs"],
        desc = LO["Show the buffs under the target frame."],
        dbPath = "unitframe.target.show_buffs",
        callback = RefreshTargetFocusAuraLayout,
    })
    C:AddToggle(showSection, {
        label = LO["Show Debuffs"],
        desc = LO["Show the debuffs under the target frame."],
        dbPath = "unitframe.target.show_debuffs",
        callback = RefreshTargetFocusAuraLayout,
    })

    C:AddHeading(showSection, LO["Focus"])
    C:AddToggle(showSection, {
        label = LO["Show Buff/Debuff on Focus"],
        desc = LO["Uses the native large focus frame mode to show buffs and debuffs on the focus frame."],
        dbPath = "unitframe.focus.show_buff_debuff",
        callback = RefreshFocusFrame,
    })

    C:AddSpacer(scroll)
    local timerSection = C:AddSection(scroll, LO["Aura Timers"])
    local iconSection
    local dynamicWidgets = {}
    local isRefreshingAuraWidgets = false

    local function RegisterDynamicWidget(widget, disabledFunc, valueFunc)
        table.insert(dynamicWidgets, { widget = widget, disabledFunc = disabledFunc, valueFunc = valueFunc })
        return widget
    end

    local function RefreshAuraControlStates()
        isRefreshingAuraWidgets = true
        for _, entry in ipairs(dynamicWidgets) do
            if entry.widget and entry.widget.SetValue and entry.valueFunc then
                entry.widget:SetValue(entry.valueFunc())
            end
            if entry.widget and entry.widget.SetDisabled and entry.disabledFunc then
                entry.widget:SetDisabled(entry.disabledFunc())
            end
        end
        isRefreshingAuraWidgets = false
    end

    local function RefreshAuraUI()
        RefreshAuraControlStates()
        RefreshTargetFocusAuraTimers()
    end

    C:AddDescription(timerSection, LO["Show aura timers on Target and Focus independently."])

    RegisterDynamicWidget(C:AddToggle(timerSection, {
        label = LO["Enable Target Aura Timers"],
        getFunc = function()
            return GetAuraCooldownConfig().target.enabled == true
        end,
        setFunc = function(val)
            SetAuraUnitEnabled("target", val)
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
        requiresReload = false,
    }), nil, function()
        return GetAuraCooldownConfig().target.enabled == true
    end)

    RegisterDynamicWidget(C:AddToggle(timerSection, {
        label = LO["Enable Focus Aura Timers"],
        getFunc = function()
            return GetAuraCooldownConfig().focus.enabled == true
        end,
        setFunc = function(val)
            SetAuraUnitEnabled("focus", val)
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
        requiresReload = false,
    }), nil, function()
        return GetAuraCooldownConfig().focus.enabled == true
    end)

    C:AddHeading(timerSection, LO["Timer Text Settings"])

    RegisterDynamicWidget(C:AddDropdown(timerSection, {
        label = LO["Duration Text Anchor"],
        dbPath = "modules.auracooldowns.duration_anchor",
        values = AURA_ANCHORS,
        width = 220,
        disabled = function()
            return not IsTimerCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsTimerCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().duration_anchor
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Duration X Offset"],
        dbPath = "modules.auracooldowns.duration_offset_x",
        min = -50, max = 50, step = 1,
        width = 220,
        disabled = function()
            return not IsTimerCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsTimerCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().duration_offset_x
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Duration Y Offset"],
        dbPath = "modules.auracooldowns.duration_offset_y",
        min = -50, max = 50, step = 1,
        width = 220,
        disabled = function()
            return not IsTimerCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsTimerCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().duration_offset_y
    end)

    RegisterDynamicWidget(C:AddDropdown(timerSection, {
        label = LO["Duration Font"],
        dbPath = "modules.auracooldowns.duration_font",
        values = AURA_FONTS,
        width = 220,
        disabled = function()
            return not IsTimerCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsTimerCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().duration_font
    end)

    C:AddHeading(timerSection, LO["Target Aura Timer Settings"])

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Target Aura Timer Size"],
        dbPath = "modules.auracooldowns.target.font_size",
        min = 6, max = 30, step = 1,
        width = 220,
        disabled = IsTargetTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsTargetTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().target.font_size
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Target Aura Minimum Duration (Seconds)"],
        desc = LO["Only show aura timers when remaining duration is above this value (seconds)."],
        dbPath = "modules.auracooldowns.target.min_duration",
        min = 0, max = 60, step = 1,
        width = 220,
        disabled = IsTargetTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsTargetTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().target.min_duration
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Target Aura Maximum Duration (Minutes)"],
        desc = LO["Only show aura timers when remaining duration is below this value (minutes). Use 0 to disable this limit."],
        dbPath = "modules.auracooldowns.target.max_duration_minutes",
        min = 0, max = 180, step = 1,
        width = 220,
        disabled = IsTargetTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsTargetTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().target.max_duration_minutes
    end)

    C:AddHeading(timerSection, LO["Focus Aura Timer Settings"])

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Focus Aura Timer Size"],
        dbPath = "modules.auracooldowns.focus.font_size",
        min = 6, max = 30, step = 1,
        width = 220,
        disabled = IsFocusTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsFocusTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().focus.font_size
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Focus Aura Minimum Duration (Seconds)"],
        desc = LO["Only show aura timers when remaining duration is above this value (seconds)."],
        dbPath = "modules.auracooldowns.focus.min_duration",
        min = 0, max = 60, step = 1,
        width = 220,
        disabled = IsFocusTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsFocusTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().focus.min_duration
    end)

    RegisterDynamicWidget(C:AddSlider(timerSection, {
        label = LO["Focus Aura Maximum Duration (Minutes)"],
        desc = LO["Only show aura timers when remaining duration is below this value (minutes). Use 0 to disable this limit."],
        dbPath = "modules.auracooldowns.focus.max_duration_minutes",
        min = 0, max = 180, step = 1,
        width = 220,
        disabled = IsFocusTimerSettingsDisabled,
        callback = RefreshTargetFocusAuraTimers,
    }), IsFocusTimerSettingsDisabled, function()
        return GetAuraCooldownConfig().focus.max_duration_minutes
    end)

    C:AddSpacer(timerSection)

    C:AddButton(timerSection, {
        label = LO["Reset Aura Timers"],
        width = 220,
        callback = function()
            ResetAuraTimerSettings()
            RefreshAuraUI()
            addon:Print(LO["Aura timer settings reset."])
        end,
    })

    C:AddSpacer(scroll)
    iconSection = C:AddSection(scroll, LO["Aura Icon Customization"])

    C:AddDescription(iconSection, LO["Customize icon size, scale, and stack text for target/focus auras."])

    C:AddToggle(iconSection, {
        label = LO["Ignore Keeper's Aura from Target"],
        desc = LO["Hide all buffs on the target whose name starts with 'Keeper's'."],
        getFunc = function()
            return GetAuraCooldownConfig().target.ignore_keepers_aura == true
        end,
        setFunc = function(val)
            local cfg = GetAuraCooldownConfig()
            cfg.target.ignore_keepers_aura = val and true or false
        end,
        callback = function()
            if addon.RefreshTargetFocusAuraLayout then
                addon.RefreshTargetFocusAuraLayout()
            end
        end,
        requiresReload = false,
    })

    RegisterDynamicWidget(C:AddToggle(iconSection, {
        label = LO["Customize Aura Icons"],
        desc = LO["Enable custom icon styling for target/focus aura icons."],
        getFunc = IsIconCustomizationEnabled,
        setFunc = function(val)
            SetAuraFeatureEnabled("icons_enabled", val)
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
        requiresReload = false,
    }), nil, function()
        return IsIconCustomizationEnabled()
    end)

    C:AddHeading(iconSection, LO["Stack Text Settings"])

    RegisterDynamicWidget(C:AddDropdown(iconSection, {
        label = LO["Stack Text Anchor"],
        dbPath = "modules.auracooldowns.stack_anchor",
        values = AURA_ANCHORS,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().stack_anchor
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Stack X Offset"],
        dbPath = "modules.auracooldowns.stack_offset_x",
        min = -50, max = 50, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().stack_offset_x
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Stack Y Offset"],
        dbPath = "modules.auracooldowns.stack_offset_y",
        min = -50, max = 50, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().stack_offset_y
    end)

    RegisterDynamicWidget(C:AddDropdown(iconSection, {
        label = LO["Stack Font"],
        dbPath = "modules.auracooldowns.count_font",
        values = AURA_FONTS,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().count_font
    end)

    C:AddHeading(iconSection, LO["Aura Size"])

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Auras Per Row"],
        desc = LO["Discrete size steps: how many auras fit in a full-width row. 6 is the Blizzard default (17px). Your own auras render slightly larger, and rows beside a visible Target-of-Target are narrower, so fewer may fit there."],
        min = 4, max = 8, step = 1,
        width = 220,
        getFunc = function()
            return EffectivePerRow(GetAuraCooldownConfig().buffs)
        end,
        setFunc = function(value)
            local size = PerRowToSize(value)
            local cfg = GetAuraCooldownConfig()
            cfg.buffs.icon_size = size
            cfg.debuffs.icon_size = size
        end,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return EffectivePerRow(GetAuraCooldownConfig().buffs)
    end)

    C:AddHeading(iconSection, LO["Aura Buffs"])

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Buff Icon Size"],
        dbPath = "modules.auracooldowns.buffs.icon_size",
        min = 0, max = 64, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().buffs.icon_size
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Buff Icon Scale"],
        dbPath = "modules.auracooldowns.buffs.icon_scale",
        min = 0.5, max = 3, step = 0.01,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().buffs.icon_scale
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Buff Stack Font Size"],
        dbPath = "modules.auracooldowns.buffs.stack_font_size",
        min = 0, max = 30, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().buffs.stack_font_size
    end)

    C:AddHeading(iconSection, LO["Aura Debuffs"])

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Debuff Icon Size"],
        dbPath = "modules.auracooldowns.debuffs.icon_size",
        min = 0, max = 64, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().debuffs.icon_size
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Debuff Icon Scale"],
        dbPath = "modules.auracooldowns.debuffs.icon_scale",
        min = 0.5, max = 3, step = 0.01,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = function()
            if isRefreshingAuraWidgets then return end
            RefreshAuraUI()
        end,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().debuffs.icon_scale
    end)

    RegisterDynamicWidget(C:AddSlider(iconSection, {
        label = LO["Debuff Stack Font Size"],
        dbPath = "modules.auracooldowns.debuffs.stack_font_size",
        min = 0, max = 30, step = 1,
        width = 220,
        disabled = function()
            return not IsIconCustomizationEnabled()
        end,
        callback = RefreshTargetFocusAuraTimers,
    }), function()
        return not IsIconCustomizationEnabled()
    end, function()
        return GetAuraCooldownConfig().debuffs.stack_font_size
    end)

    C:AddSpacer(iconSection)

    C:AddButton(iconSection, {
        label = LO["Reset Aura Customization"],
        width = 220,
        callback = function()
            ResetAuraIconSettings()
            RefreshAuraUI()
            addon:Print(LO["Aura icon customization settings reset."])
        end,
    })

    RefreshAuraControlStates()
end

local subTabBuilders = {
    player = BuildPlayerAuras,
    targetfocus = BuildTargetFocusAuras,
}

local function BuildAurasTab(scroll)
    BuildAuraStyle(scroll)

    C:AddSubTabs(scroll, subTabs, activeSubTab, function(key)
        activeSubTab = key
        Panel:SelectTab("auras")
    end, subTabBuilders)

    if not Panel.indexing then
        local builder = subTabBuilders[activeSubTab]
        if builder then builder(scroll) end
    end
end

-- Register the tab (order 12 — after Enhancements, before Profiles)
Panel:RegisterTab("auras", LO["Auras"], BuildAurasTab, 12)
