-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.

--[[
================================================================================
DragonUI Options Panel - Action Bars Tab
================================================================================
Scales, positions, button appearance, bar size for action bars.
================================================================================
]]

local addon = DragonUI
if not addon then return end

local LO = addon.LO
local C = addon.PanelControls
local Panel = addon.OptionsPanel

-- ============================================================================
-- SUB-TAB DEFINITIONS
-- ============================================================================

local activeSubTab = "general"

-- Allow external code to set the initial sub-tab before SelectTab
function addon.SetActionBarSubTab(key)
    activeSubTab = key or "general"
end

local subTabs = {
    { key = "general", label = LO["General"] },
    { key = "layout",  label = LO["Layout"] },
    { key = "visibility", label = LO["Visibility"] },
}

-- Search navigation sub-tab setter.
Panel.subTabSetters = Panel.subTabSetters or {}
Panel.subTabSetters["actionbars"] = function(key) activeSubTab = key or "general" end

-- ============================================================================
-- REFRESH HELPER
-- ============================================================================

local function RefreshBars()
    if addon.RefreshMainbars then addon.RefreshMainbars() end
end

local function RefreshExtrabar()
    if addon.RefreshExtrabarFrame then addon.RefreshExtrabarFrame() end
end

-- Bar selected in the Layout > Button Spacing dropdown; persists across tab rebuilds.
local selectedSpacingBar = "player"

local buttonOrderValues = {
    top_left     = LO["Top Left"],
    bottom_left  = LO["Bottom Left"],
    top_right    = LO["Top Right"],
    bottom_right = LO["Bottom Right"],
}

local function RebuildLayoutTab()
    local savedScroll = Panel.scrollWidget and Panel.scrollWidget.scrollbar
        and Panel.scrollWidget.scrollbar:GetValue() or 0
    activeSubTab = "layout"
    Panel:SelectTab("actionbars")
    if savedScroll > 0 and Panel.scrollWidget and Panel.scrollWidget.scrollbar then
        Panel.scrollWidget.scrollbar:SetValue(savedScroll)
        Panel.scrollWidget:SetScroll(savedScroll)
    end
end

local function AddBarOrderControls(section, barKey)
    local dbPrefix = "mainbars." .. barKey

    C:AddToggle(section, {
        label = LO["Change Button Order"],
        dbPath = dbPrefix .. ".change_button_order",
        callback = function(value)
            if value and not C:GetDBValue(dbPrefix .. ".button_order") then
                C:SetDBValue(dbPrefix .. ".button_order", "top_left")
            end
            RefreshBars()
            RebuildLayoutTab()
        end,
    })

    if C:GetDBValue(dbPrefix .. ".change_button_order") then
        C:AddDropdown(section, {
            label = LO["Button Order"],
            dbPath = dbPrefix .. ".button_order",
            values = buttonOrderValues,
            width = 200,
            callback = RefreshBars,
        })
    end
end

local function RefreshButtons()
    if addon.RefreshButtons then addon.RefreshButtons() end
end

local function RefreshHotkeyStyle()
    if addon.RefreshHotkeyStyle then
        addon.RefreshHotkeyStyle()
    elseif addon.RefreshAllHotkeys then
        addon.RefreshAllHotkeys()
        if addon.RefreshExtrabarHotkeys then
            addon.RefreshExtrabarHotkeys()
        end
    end
end

local function SyncHotkeyFontSize()
    local hk = addon.db and addon.db.profile and addon.db.profile.buttons
        and addon.db.profile.buttons.hotkey
    if hk and hk.font then
        hk.font[2] = hk.font_size or hk.font[2] or 12
    end
end

local function RefreshCooldowns()
    if addon.RefreshCooldowns then addon.RefreshCooldowns() end
end

-- ============================================================================
-- GENERAL SUB-TAB (existing action bar settings)
-- ============================================================================

local function BuildGeneralTab(scroll)
    -- ====================================================================
    -- SCALES
    -- ====================================================================
    local scales = C:AddSection(scroll, LO["Action Bar Scales"])

    local barScales = {
        { path = "mainbars.scale_actionbar",    label = LO["Main Bar Scale"] },
        { path = "mainbars.scale_rightbar",     label = LO["Right Bar Scale"] },
        { path = "mainbars.scale_leftbar",      label = LO["Left Bar Scale"] },
        { path = "mainbars.scale_bottomleft",   label = LO["Bottom Left Bar Scale"] },
        { path = "mainbars.scale_bottomright",  label = LO["Bottom Right Bar Scale"] },
    }

    if addon:IsModuleEnabled("extrabar1") then
        table.insert(barScales, {
            path = "additional.extrabar1.scale",
            label = LO["Extra Bar Scale"],
            refresh = RefreshExtrabar,
        })
    end

    for _, bar in ipairs(barScales) do
        C:AddSlider(scales, {
            dbPath = bar.path,
            label = bar.label,
            min = 0.5, max = 2.0, step = 0.01,
            width = 250,
            callback = bar.refresh or RefreshBars,
        })
    end

    C:AddButton(scales, {
        label = LO["Reset All Scales"],
        width = 180,
        callback = function()
            for _, bar in ipairs(barScales) do
                C:SetDBValue(bar.path, 0.9)
            end
            RefreshBars()
            RefreshExtrabar()
            Panel:SelectTab("actionbars")
            addon:Print(LO["All action bar scales reset to 0.9"])
        end,
    })

    -- ====================================================================
    -- POSITIONS
    -- ====================================================================
    local positions = C:AddSection(scroll, LO["Action Bar Positions"])

    C:AddToggle(positions, {
        label = LO["Left Bar Horizontal"],
        desc = LO["Make the left secondary bar horizontal instead of vertical."],
        dbPath = "mainbars.left.horizontal",
        callback = function(value)
            addon.db.profile.mainbars.left.columns = value and 12 or 1
            RefreshBars()
        end,
    })

    C:AddToggle(positions, {
        label = LO["Right Bar Horizontal"],
        desc = LO["Make the right secondary bar horizontal instead of vertical."],
        dbPath = "mainbars.right.horizontal",
        callback = function(value)
            addon.db.profile.mainbars.right.columns = value and 12 or 1
            RefreshBars()
        end,
    })

    -- ====================================================================
    -- BUTTON APPEARANCE
    -- ====================================================================
    local buttons = C:AddSection(scroll, LO["Button Appearance"])

    C:AddToggle(buttons, {
        label = LO["Hide Main Bar Art"],
        desc = LO["Hide the main bar's art and gryphons, leaving only the buttons."],
        dbPath = "buttons.hide_main_bar_background",
        callback = function()
            if addon.RefreshMainBarArt then addon.RefreshMainBarArt() end
        end,
    })

    C:AddToggle(buttons, {
        label = LO["Hide Button Backgrounds"],
        desc = LO["Hide the slot background of every action bar button, leaving only the frames."],
        dbPath = "buttons.hide_slot_backgrounds",
        callback = function()
            RefreshButtons()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddToggle(buttons, {
        label = LO["Main Bar Only Background"],
        desc = LO["Only the main action bar buttons will have a background."],
        dbPath = "buttons.only_actionbackground",
        disabled = function() return C:GetDBValue("buttons.hide_slot_backgrounds") end,
        callback = RefreshButtons,
    })

    C:AddToggle(buttons, {
        label = LO["Hide Main Bar Button Background"],
        desc = LO["Hide the background of main action bar buttons."],
        dbPath = "buttons.hide_main_bar_button_background",
        disabled = function() return C:GetDBValue("buttons.hide_slot_backgrounds") end,
        callback = RefreshButtons,
    })

    -- ====================================================================
    -- BEHAVIOR
    -- ====================================================================
    local behavior = C:AddSection(scroll, LO["Behavior"])

    C:AddToggle(behavior, {
        label = LO["Disable Form Page Switching"],
        desc = LO["When enabled, the main action bar stays on the same page regardless of stance/form changes. Useful for druids, warriors, and CoA Classes who prefer manual page management."],
        dbPath = "modules.mainbars.disable_form_page_switching",
        requiresReload = true,
    })

    C:AddDropdown(buttons, {
        label = LO["Button Tooltips"],
        desc = LO["When to show tooltips on action, pet and stance buttons."],
        dbPath = "buttons.tooltips",
        values = {
            always = LO["Always"],
            combat = LO["Hide in Combat"],
            never  = LO["Never"],
        },
        width = 200,
    })

    -- Text visibility sub-section
    local textVis = C:AddSection(scroll, LO["Text Visibility"])

    C:AddToggle(textVis, {
        label = LO["Show Count Text"],
        dbPath = "buttons.count.show",
        callback = RefreshButtons,
    })

    C:AddToggle(textVis, {
        label = LO["Show Hotkey Text"],
        dbPath = "buttons.hotkey.show",
        callback = RefreshButtons,
    })

    C:AddToggle(textVis, {
        label = LO["Range Indicator"],
        desc = LO["Show range indicator dot on buttons."],
        dbPath = "buttons.hotkey.range",
        callback = RefreshButtons,
        requiresReload = true,
    })

    C:AddToggle(textVis, {
        label = LO["Show Macro Names"],
        dbPath = "buttons.macros.show",
        callback = RefreshButtons,
    })

    C:AddToggle(textVis, {
        label = LO["Show Page Numbers"],
        dbPath = "buttons.pages.show",
        requiresReload = true,
    })

    -- Cooldown text
    local cdSection = C:AddSection(scroll, LO["Cooldown Text"])

    C:AddSlider(cdSection, {
        label = LO["Min Duration"],
        desc = LO["Minimum duration for cooldown text to appear."],
        dbPath = "buttons.cooldown.min_duration",
        min = 1, max = 10, step = 1,
        width = 200,
        callback = RefreshCooldowns,
    })

    C:AddToggle(cdSection, {
        label = LO["Whole Seconds"],
        tooltip = LO["Show cooldown text in whole seconds, without the tenths under 5 seconds."],
        dbPath = "buttons.cooldown.whole_seconds",
    })

    C:AddSlider(cdSection, {
        label = LO["Font Size"],
        desc = LO["Size of cooldown text."],
        dbPath = "buttons.cooldown.font_size",
        min = 8, max = 24, step = 1,
        width = 200,
        callback = RefreshCooldowns,
    })

    C:AddColorPicker(cdSection, {
        label = LO["Cooldown Text Color"],
        getFunc = function()
            local c = addon.db.profile.buttons.cooldown.color
            if c then return c[1], c[2], c[3], c[4] end
            return 1, 1, 1, 1
        end,
        setFunc = function(r, g, b, a)
            addon.db.profile.buttons.cooldown.color = { r, g, b, a }
            RefreshCooldowns()
        end,
        hasAlpha = true,
    })

    -- Colors
    local colorSection = C:AddSection(scroll, LO["Colors"])

    C:AddColorPicker(colorSection, {
        label = LO["Macro Text Color"],
        getFunc = function()
            local c = addon.db.profile.buttons.macros.color
            if c then return c[1], c[2], c[3], c[4] end
            return 1, 1, 0, 1
        end,
        setFunc = function(r, g, b, a)
            addon.db.profile.buttons.macros.color = { r, g, b, a }
            RefreshButtons()
        end,
        hasAlpha = true,
    })

    C:AddColorPicker(colorSection, {
        label = LO["Hotkey Text Color"],
        getFunc = function()
            local c = addon.db.profile.buttons.hotkey.color
            if c then return c[1], c[2], c[3], c[4] end
            return 0.6, 0.6, 0.6, 1
        end,
        setFunc = function(r, g, b, a)
            addon.db.profile.buttons.hotkey.color = { r, g, b, a }
            RefreshHotkeyStyle()
        end,
        hasAlpha = true,
    })

    C:AddColorPicker(colorSection, {
        label = LO["Hotkey Shadow Color"],
        getFunc = function()
            local c = addon.db.profile.buttons.hotkey.shadow
            if c then return c[1], c[2], c[3], c[4] end
            return 0, 0, 0, 1
        end,
        setFunc = function(r, g, b, a)
            addon.db.profile.buttons.hotkey.shadow = { r, g, b, a }
            RefreshHotkeyStyle()
        end,
        hasAlpha = true,
    })

    C:AddSlider(colorSection, {
        label = LO["Hotkey Font Size"],
        dbPath = "buttons.hotkey.font_size",
        min = 8, max = 24, step = 1,
        width = 200,
        callback = function()
            SyncHotkeyFontSize()
            RefreshHotkeyStyle()
        end,
    })

    C:AddColorPicker(colorSection, {
        label = LO["Border Color"],
        getFunc = function()
            local c = addon.db.profile.buttons.border_color
            if c then return c[1], c[2], c[3], c[4] end
            return 1, 1, 1, 1
        end,
        setFunc = function(r, g, b, a)
            addon.db.profile.buttons.border_color = { r, g, b, a }
            RefreshButtons()
        end,
        hasAlpha = true,
    })

    -- ====================================================================
    -- GRYPHONS
    -- ====================================================================
    local gryphons = C:AddSection(scroll, LO["Gryphons"])

    C:AddDescription(gryphons, LO["End-cap ornaments flanking the main action bar."])

    C:AddDropdown(gryphons, {
        label = LO["Style"],
        dbPath = "style.gryphons",
        values = {
            old     = LO["Classic"],
            new     = LO["Dragonflight"],
            flying  = LO["Flying"],
            forever = LO["Forever"],
            none    = LO["Hidden"],
        },
        width = 200,
        callback = function()
            if addon.RefreshMainbars then addon.RefreshMainbars() end
        end,
    })

    C:AddSlider(gryphons, {
        label = LO["Gryphon Scale"],
        dbPath = "style.gryphonScale",
        min = 0.5, max = 2, step = 0.01,
        width = 200,
        callback = function()
            if addon.RefreshMainbars then addon.RefreshMainbars() end
        end,
    })

    C:AddSlider(gryphons, {
        label = LO["Gryphon Offset X"],
        desc = LO["Moves both gryphons inward or outward, mirrored left/right."],
        dbPath = "style.gryphonOffsetX",
        min = -200, max = 200, step = 1,
        width = 200,
        callback = function()
            if addon.RefreshMainbars then addon.RefreshMainbars() end
        end,
    })

    C:AddSlider(gryphons, {
        label = LO["Gryphon Offset Y"],
        dbPath = "style.gryphonOffsetY",
        min = -200, max = 200, step = 1,
        width = 200,
        callback = function()
            if addon.RefreshMainbars then addon.RefreshMainbars() end
        end,
    })

    -- Texture previews row
    local previewRow = C:AddRow(gryphons)
    local assets = addon._dir or "Interface\\AddOns\\DragonUI\\Textures\\"
    local faction = UnitFactionGroup and UnitFactionGroup("player") or "Alliance"

    -- Classic gryphon preview
    C:AddTexturePreview(previewRow, {
        label = LO["Classic"],
        texture = assets .. "ActionBars\\uiactionbar2x_",
        texCoord = { 1/512, 357/512, 209/1024, 543/1024 },
        width = 80,
        height = 80,
    })

    -- Dragonflight gryphon preview (faction-aware: gryphon=Alliance, wyvern=Horde)
    local dfTexture, dfTexCoord
    if faction == "Horde" then
        dfTexture, dfTexCoord = "ActionBars\\uiactionbar2x_new2", { 1/512, 357/512, 1/1024, 335/1024 } -- wyvern-thick-left
    else
        dfTexture, dfTexCoord = "ActionBars\\uiactionbar2x_new", { 1/512, 357/512, 209/1024, 543/1024 } -- gryphon-thick-left
    end
    C:AddTexturePreview(previewRow, {
        label = faction == "Horde" and LO["Dragonflight (Wyvern)"] or LO["Dragonflight (Gryphon)"],
        texture = assets .. dfTexture,
        texCoord = dfTexCoord,
        width = 80,
        height = 80,
    })

    -- Flying gryphon preview
    C:AddTexturePreview(previewRow, {
        label = LO["Flying"],
        texture = assets .. "ActionBars\\uiactionbar2x_flying",
        texCoord = { 1/256, 158/256, 149/1024, 342/1024 },
        width = 70,
        height = 90,
    })

    -- WoW Forever preview (faction-aware like Dragonflight: gryphon=Alliance, wyvern=Horde)
    C:AddTexturePreview(previewRow, {
        label = LO["Forever"],
        texture = assets .. "ActionBars\\uiactionbar2x_forever",
        texCoord = faction == "Horde" and { 1/1024, 481/1024, 283/1024, 563/1024 }
            or { 1/1024, 481/1024, 1/1024, 281/1024 },
        width = 96,
        height = 56,
    })
end

-- ============================================================================
-- LAYOUT SUB-TAB (grid layout: rows/columns/buttons per bar)
-- ============================================================================

local function BuildLayoutTab(scroll)
    -- ---- Button Spacing (per bar) ----
    local spacingSection = C:AddSection(scroll, LO["Button Spacing"])

    local spacingBars = {
        player = LO["Main Bar"],
        bottom_left = LO["Bottom Left Bar"],
        bottom_right = LO["Bottom Right Bar"],
        right = LO["Right Bar"],
        left = LO["Left Bar"],
    }
    if addon:IsModuleEnabled("extrabar1") then
        spacingBars.extrabar1 = LO["Extra Bar"]
    end
    if not spacingBars[selectedSpacingBar] then selectedSpacingBar = "player" end

    C:AddDropdown(spacingSection, {
        label = LO["Bar"],
        values = spacingBars,
        width = 200,
        getFunc = function() return selectedSpacingBar end,
        setFunc = function(value) selectedSpacingBar = value end,
        -- Rebuild so the slider re-reads the newly selected bar's value.
        callback = RebuildLayoutTab,
    })

    C:AddSlider(spacingSection, {
        label = LO["Button Spacing"],
        min = 0, max = 20, step = 1,
        width = 250,
        getFunc = function()
            if selectedSpacingBar == "extrabar1" then
                local cfg = addon.db.profile.additional.extrabar1
                local v = cfg and cfg.spacing
                if v == nil then v = 7 end
                return v
            end
            local mb = addon.db.profile.mainbars
            local cfg = mb and mb[selectedSpacingBar]
            return (cfg and cfg.button_spacing) or (mb and mb.button_spacing) or 7
        end,
        setFunc = function(val)
            if selectedSpacingBar == "extrabar1" then
                addon.db.profile.additional.extrabar1.spacing = val
                RefreshExtrabar()
            else
                local mb = addon.db.profile.mainbars
                if mb and mb[selectedSpacingBar] then
                    mb[selectedSpacingBar].button_spacing = val
                end
                RefreshBars()
            end
        end,
    })

    -- ---- Main Bar ----
    local mainSection = C:AddSection(scroll, LO["Main Bar Layout"])

    C:AddDescription(mainSection,
        LO["Configure the main action bar grid layout. Rows are determined automatically from columns and buttons shown."])

    C:AddSlider(mainSection, {
        dbPath = "mainbars.player.columns",
        label = LO["Columns"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    C:AddSlider(mainSection, {
        dbPath = "mainbars.player.buttons_shown",
        label = LO["Buttons Shown"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    AddBarOrderControls(mainSection, "player")

    local mainPresetRow = C:AddRow(mainSection)

    C:AddButton(mainPresetRow, {
        label = "1x12",
        width = 60,
        callback = function()
            C:SetDBValue("mainbars.player.columns", 12)
            C:SetDBValue("mainbars.player.buttons_shown", 12)
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddButton(mainPresetRow, {
        label = "2x6",
        width = 60,
        callback = function()
            C:SetDBValue("mainbars.player.columns", 6)
            C:SetDBValue("mainbars.player.buttons_shown", 12)
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddButton(mainPresetRow, {
        label = "3x4",
        width = 60,
        callback = function()
            C:SetDBValue("mainbars.player.columns", 4)
            C:SetDBValue("mainbars.player.buttons_shown", 12)
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddButton(mainPresetRow, {
        label = "4x3",
        width = 60,
        callback = function()
            C:SetDBValue("mainbars.player.columns", 3)
            C:SetDBValue("mainbars.player.buttons_shown", 12)
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddToggle(mainSection, {
        label = LO["Page by Form (Classless Servers)"],
        desc = LO["The main bar changes page with your stance or form, whatever your class. Only for classless servers."],
        dbPath = "mainbars.page_by_form",
        callback = function()
            if addon.RefreshMainBarPaging then addon.RefreshMainBarPaging() end
        end,
    })

    -- ---- Bottom Left Bar ----
    local blSection = C:AddSection(scroll, LO["Bottom Left Bar Layout"])

    C:AddSlider(blSection, {
        dbPath = "mainbars.bottom_left.columns",
        label = LO["Columns"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    C:AddSlider(blSection, {
        dbPath = "mainbars.bottom_left.buttons_shown",
        label = LO["Buttons Shown"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    AddBarOrderControls(blSection, "bottom_left")

    -- ---- Bottom Right Bar ----
    local brSection = C:AddSection(scroll, LO["Bottom Right Bar Layout"])

    C:AddSlider(brSection, {
        dbPath = "mainbars.bottom_right.columns",
        label = LO["Columns"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    C:AddSlider(brSection, {
        dbPath = "mainbars.bottom_right.buttons_shown",
        label = LO["Buttons Shown"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    AddBarOrderControls(brSection, "bottom_right")

    -- ---- Right Bar ----
    local rightSection = C:AddSection(scroll, LO["Right Bar Layout"])

    C:AddSlider(rightSection, {
        dbPath = "mainbars.right.columns",
        label = LO["Columns"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    C:AddSlider(rightSection, {
        dbPath = "mainbars.right.buttons_shown",
        label = LO["Buttons Shown"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    AddBarOrderControls(rightSection, "right")

    -- ---- Left Bar (Blizzard: MultiBarLeft = "Right 2") ----
    local leftSection = C:AddSection(scroll, LO["Left Bar Layout"])

    C:AddSlider(leftSection, {
        dbPath = "mainbars.left.columns",
        label = LO["Columns"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    C:AddSlider(leftSection, {
        dbPath = "mainbars.left.buttons_shown",
        label = LO["Buttons Shown"],
        min = 1, max = 12, step = 1,
        width = 200,
        callback = RefreshBars,
    })

    AddBarOrderControls(leftSection, "left")

    -- ---- Quick Presets ----
    local presetSection = C:AddSection(scroll, LO["Quick Presets"])

    C:AddDescription(presetSection, LO["Apply layout presets to multiple bars at once."])

    local presetRow = C:AddRow(presetSection)

    C:AddButton(presetRow, {
        label = LO["Both 1x12"],
        width = 90,
        callback = function()
            for _, key in ipairs({"bottom_left", "bottom_right"}) do
                C:SetDBValue("mainbars." .. key .. ".columns", 12)
                C:SetDBValue("mainbars." .. key .. ".buttons_shown", 12)
            end
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddButton(presetRow, {
        label = LO["Both 2x6"],
        width = 90,
        callback = function()
            for _, key in ipairs({"bottom_left", "bottom_right"}) do
                C:SetDBValue("mainbars." .. key .. ".columns", 6)
                C:SetDBValue("mainbars." .. key .. ".buttons_shown", 12)
            end
            RefreshBars()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddButton(presetRow, {
        label = LO["Reset All"],
        width = 90,
        callback = function()
            C:SetDBValue("mainbars.player.columns", 12)
            C:SetDBValue("mainbars.player.buttons_shown", 12)
            C:SetDBValue("mainbars.player.change_button_order", false)
            C:SetDBValue("mainbars.player.button_order", "top_left")
            for _, key in ipairs({"bottom_left", "bottom_right"}) do
                C:SetDBValue("mainbars." .. key .. ".columns", 12)
                C:SetDBValue("mainbars." .. key .. ".buttons_shown", 12)
                C:SetDBValue("mainbars." .. key .. ".change_button_order", false)
                C:SetDBValue("mainbars." .. key .. ".button_order", "top_left")
            end
            C:SetDBValue("mainbars.right.columns", 1)
            C:SetDBValue("mainbars.right.buttons_shown", 12)
            C:SetDBValue("mainbars.right.change_button_order", false)
            C:SetDBValue("mainbars.right.button_order", "top_left")
            C:SetDBValue("mainbars.left.columns", 1)
            C:SetDBValue("mainbars.left.buttons_shown", 12)
            C:SetDBValue("mainbars.left.change_button_order", false)
            C:SetDBValue("mainbars.left.button_order", "top_left")
            RefreshBars()
            Panel:SelectTab("actionbars")
            addon:Print(LO["All bar layouts reset to defaults."])
        end,
    })

    -- Extra Bar: position via Editor Mode, scale in General > Scales; hidden while the module is off.
    if addon:IsModuleEnabled("extrabar1") then
        local extrabarLayout = C:AddSection(scroll, LO["Extra Bar"])

        C:AddSlider(extrabarLayout, {
            label = LO["Columns"],
            dbPath = "additional.extrabar1.columns",
            min = 1, max = 12, step = 1,
            width = 200,
            callback = RefreshExtrabar,
        })

        C:AddSlider(extrabarLayout, {
            label = LO["Buttons Shown"],
            dbPath = "additional.extrabar1.buttons_shown",
            min = 1, max = 12, step = 1,
            width = 200,
            callback = RefreshExtrabar,
        })

        C:AddToggle(extrabarLayout, {
            label = LO["Change Button Order"],
            dbPath = "additional.extrabar1.change_button_order",
            callback = function()
                RefreshExtrabar()
                RebuildLayoutTab()
            end,
        })

        if C:GetDBValue("additional.extrabar1.change_button_order") then
            C:AddDropdown(extrabarLayout, {
                label = LO["Button Order"],
                dbPath = "additional.extrabar1.button_order",
                values = buttonOrderValues,
                width = 200,
                callback = RefreshExtrabar,
            })
        end
    end
end

-- ============================================================================
-- VISIBILITY SUB-TAB (hover/combat show/hide per bar)
-- ============================================================================

local function RefreshVisibility()
    if addon.RefreshActionBarVisibility then addon.RefreshActionBarVisibility() end
    -- Keep Blizzard Interface Options in sync with our toggles
    if addon.SyncBarCVarsFromProfile then addon.SyncBarCVarsFromProfile() end
end

local function BuildVisibilityTab(scroll)
    local desc = C:AddSection(scroll, LO["Bar Visibility"])
    C:AddDescription(desc,
        LO["Control when action bars are visible. Bars can show only on hover, only in combat, or both. When no option is checked the bar is always visible."])

    local logicValues = {
        ["and"] = LO["AND (both required)"],
        ["or"] = LO["OR (either condition)"],
    }

    local function AddVisibilityModeOptions(section, barKey)
        C:AddDropdown(section, {
            label = LO["Hover/Combat Logic"],
            desc = LO["When both hover and combat are enabled, choose whether both are required (AND) or either condition is enough (OR)."],
            dbPath = "actionbars." .. barKey .. "_visibility_logic",
            values = logicValues,
            callback = RefreshVisibility,
        })
    end

    -- Show in Combat / Hide in Combat are mutually exclusive — enabling one clears the other.
    local function AddCombatToggle(section, barKey, dbSuffix, otherSuffix, label, desc)
        C:AddToggle(section, {
            label = label,
            desc = desc,
            dbPath = "actionbars." .. barKey .. "_" .. dbSuffix,
            callback = function()
                local conflicted = C:GetDBValue("actionbars." .. barKey .. "_" .. dbSuffix)
                    and C:GetDBValue("actionbars." .. barKey .. "_" .. otherSuffix)
                if conflicted then
                    C:SetDBValue("actionbars." .. barKey .. "_" .. otherSuffix, false)
                end
                RefreshVisibility()
                if conflicted and Panel.currentTab then Panel:SelectTab(Panel.currentTab) end
            end,
        })
    end

    -- Builds the standard 4-control Show on Hover / Show in Combat / Hide in Combat / AND-OR block
    -- used by every bar migrated to the shared addon.VisibilityFade engine (everything but Main Bar).
    local function BuildMigratedBarVisibilitySection(barKey, title, hoverDesc, combatDesc)
        local section = C:AddSection(scroll, title)

        C:AddToggle(section, {
            label = LO["Show on Hover Only"],
            desc = hoverDesc,
            dbPath = "actionbars." .. barKey .. "_show_on_hover",
            callback = RefreshVisibility,
        })

        AddCombatToggle(section, barKey, "show_in_combat", "hide_in_combat",
            LO["Show in Combat Only"], combatDesc)
        AddCombatToggle(section, barKey, "hide_in_combat", "show_in_combat",
            LO["Hide in Combat"], nil)

        AddVisibilityModeOptions(section, barKey)
        return section
    end

    -- Enable/disable secondary bars
    local enableSection = C:AddSection(scroll, LO["Enable / Disable Bars"])

    C:AddToggle(enableSection, {
        label = LO["Bottom Left Bar"],
        dbPath = "actionbars.bottom_left_enabled",
        callback = RefreshVisibility,
    })

    C:AddToggle(enableSection, {
        label = LO["Bottom Right Bar"],
        dbPath = "actionbars.bottom_right_enabled",
        callback = RefreshVisibility,
    })

    C:AddToggle(enableSection, {
        label = LO["Right Bar"],
        dbPath = "actionbars.right_enabled",
        callback = function(value)
            -- Blizzard greys the left bar out and turns it off with the right one.
            if not value then C:SetDBValue("actionbars.left_enabled", false) end
            RefreshVisibility()
            Panel:SelectTab("actionbars")
        end,
    })

    C:AddToggle(enableSection, {
        label = LO["Left Bar"],
        dbPath = "actionbars.left_enabled",
        disabled = function() return C:GetDBValue("actionbars.right_enabled") == false end,
        callback = RefreshVisibility,
    })

    C:AddToggle(enableSection, {
        label = LO["Extra Bar"],
        desc = LO["A 12-button action bar independent of every class's bonus bar (stance/stealth/vehicle)."],
        dbPath = "modules.extrabar1.enabled",
        callback = function()
            if addon.RefreshExtrabarSystem then addon.RefreshExtrabarSystem() end
            -- Scales/Layout sections are gated on the module; rebuild so they appear/disappear.
            Panel:SelectTab("actionbars")
        end,
    })

    -- Extra Bar hover/combat
    local extrabarVis = C:AddSection(scroll, LO["Extra Bar"])

    C:AddToggle(extrabarVis, {
        label = LO["Show Hotkey Text"],
        dbPath = "additional.extrabar1.show_hotkey",
        callback = function()
            if addon.RefreshExtrabarHotkeys then addon.RefreshExtrabarHotkeys() end
        end,
    })

    C:AddVisibilityFadeToggles(extrabarVis, {
        dbPrefix = "additional.extrabar1",
        hoverDesc = LO["Fade the extra bar until you hover over it."],
        combatDesc = LO["Fade the extra bar until you enter combat."],
        callback = function()
            if addon.VisibilityFade then
                addon.VisibilityFade.Update("extrabar1")
            end
        end,
    })

    -- Main bar hover/combat
    local mainVis = C:AddSection(scroll, LO["Main Bar"])

    C:AddToggle(mainVis, {
        label = LO["Show on Hover Only"],
        desc = LO["Hide the main bar until you hover over it."],
        dbPath = "actionbars.main_show_on_hover",
        callback = RefreshVisibility,
    })

    AddCombatToggle(mainVis, "main", "show_in_combat", "hide_in_combat",
        LO["Show in Combat Only"], LO["Hide the main bar until you enter combat."])
    AddCombatToggle(mainVis, "main", "hide_in_combat", "show_in_combat",
        LO["Hide in Combat"], LO["Hide the main bar while in combat."])
    AddVisibilityModeOptions(mainVis, "main")

    -- All secondary bars get the full Show on Hover / Show in Combat / Hide in Combat / AND-OR block.
    BuildMigratedBarVisibilitySection("bottom_left", LO["Bottom Left Bar"])
    BuildMigratedBarVisibilitySection("bottom_right", LO["Bottom Right Bar"])
    BuildMigratedBarVisibilitySection("right", LO["Right Bar"])
    BuildMigratedBarVisibilitySection("left", LO["Left Bar"])
    BuildMigratedBarVisibilitySection("micro", LO["Micro Menu"])
    BuildMigratedBarVisibilitySection("bag", LO["Bag Bar"])
end

-- ============================================================================
-- SUB-TAB DISPATCH
-- ============================================================================

local subTabBuilders = {
    general    = BuildGeneralTab,
    layout     = BuildLayoutTab,
    visibility = BuildVisibilityTab,
}

-- ============================================================================
-- MAIN TAB BUILDER
-- ============================================================================

local function BuildActionbarsTab(scroll)
    C:AddSubTabs(scroll, subTabs, activeSubTab, function(key)
        activeSubTab = key
        Panel:SelectTab("actionbars")
    end, subTabBuilders)

    if not Panel.indexing then
        local builder = subTabBuilders[activeSubTab]
        if builder then builder(scroll) end
    end
end

-- Register the tab
Panel:RegisterTab("actionbars", LO["Action Bars"], BuildActionbarsTab, 3)
