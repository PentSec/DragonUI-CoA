-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.

--[[
================================================================================
DragonUI Options Panel - Nameplates Tab
================================================================================
Nameplate styling split into sub-tabs for easier navigation.
================================================================================
]]

local addon = DragonUI
if not addon then return end

local LO = addon.LO
local C = addon.PanelControls
local Panel = addon.OptionsPanel

local DB = "modules.nameplates"
local AceGUI = LibStub("AceGUI-3.0")

-- Blizzard nameplate visibility CVars (Interface → Names → Unit Nameplates).
local function CVarBool(cvar)
    if not GetCVar then
        return false
    end
    local ok, val = pcall(GetCVar, cvar)
    return ok and val == "1"
end

local function SetCVarBool(cvar, on)
    if SetCVar then
        SetCVar(cvar, on and "1" or "0")
    end
end

-- Prefer the client's localized global; fall back to DragonUI LO.
local function ClientStr(globalName, loKey)
    local s = _G[globalName]
    if type(s) == "string" and s ~= "" then
        return s
    end
    return LO[loKey]
end

local function AddNameplateCVarToggle(parent, opts)
    return C:AddToggle(parent, {
        label = ClientStr(opts.labelGlobal, opts.labelKey),
        disabled = opts.disabled,
        getFunc = function()
            return CVarBool(opts.cvar)
        end,
        setFunc = function(val)
            SetCVarBool(opts.cvar, val)
            if opts.onChanged then
                opts.onChanged(val)
            end
        end,
    })
end

local function AddNameplateCVarColumn(parent, titleKey, masterCvar, subCvars, refreshSubDisabled)
    local col = AceGUI:Create("SimpleGroup")
    col:SetLayout("List")
    col:SetWidth(290)
    parent:AddChild(col)

    AddNameplateCVarToggle(col, {
        cvar = masterCvar,
        labelGlobal = masterCvar == "nameplateShowFriends"
            and "UNIT_NAMEPLATES_SHOW_FRIENDS" or "UNIT_NAMEPLATES_SHOW_ENEMIES",
        labelKey = titleKey,
        onChanged = refreshSubDisabled,
    })

    for _, sub in ipairs(subCvars) do
        local w = AddNameplateCVarToggle(col, {
            cvar = sub.cvar,
            labelGlobal = sub.labelGlobal,
            labelKey = sub.labelKey,
            disabled = function()
                return not CVarBool(masterCvar)
            end,
        })
        sub._widget = w
    end
    refreshSubDisabled()
    return col
end

-- ============================================================================
-- REFRESH
-- ============================================================================

local function RefreshNameplates()
    if not addon.db or not addon.db.profile then
        return
    end
    local cfg = addon.db.profile.modules and addon.db.profile.modules.nameplates
    if cfg and cfg.enabled == false then
        return
    end
    if addon.RefreshNameplates then
        addon:RefreshNameplates()
    elseif addon.ApplyNameplatesSystem then
        addon:ApplyNameplatesSystem()
    end
end

local function RefreshAndRebuildNameplates()
    RefreshNameplates()
    if Panel and Panel.SelectTab then
        Panel:SelectTab("nameplates")
    end
end

-- Force the quest name/loot indexes to rebuild (provider or name-mode toggle changed).
local function RefreshQuestNameResolution()
    local np = addon.Nameplates
    if np and np.quest then
        if np.quest.ClearIndex then np.quest.ClearIndex() end
        if np.quest.OnQuestLogChanged then np.quest.OnQuestLogChanged() end
    end
    RefreshNameplates()
end

local function IsBattleGroundHealersLoaded()
    return IsAddOnLoaded and IsAddOnLoaded("BattleGroundHealers") or false
end

local bghTestMarkedNames = {}

local function GetBGHTestLayout()
    local np = addon.Nameplates
    return np and np.layout
end

local function ClearBGHTestMarks()
    local layout = GetBGHTestLayout()
    if layout and layout.ClearBGHTestMarks then
        layout.ClearBGHTestMarks()
    end
    bghTestMarkedNames = {}
end

local function ToggleBGHTestMarkTarget()
    local layout = GetBGHTestLayout()
    if not (layout and layout.SetBGHTestMark) then
        return
    end
    local name = UnitName("target")
    if not name or name == "" then
        return
    end

    local index = nil
    for i = 1, #bghTestMarkedNames do
        if bghTestMarkedNames[i] == name then
            index = i
            break
        end
    end

    if index then
        layout.SetBGHTestMark(name, nil)
        table.remove(bghTestMarkedNames, index)
        return
    end

    layout.SetBGHTestMark(name, UnitCanAttack("player", "target") and "ENEMY" or "FRIEND")
    bghTestMarkedNames[#bghTestMarkedNames + 1] = name
end

local function DisableBGHTestMode()
    local np = addon.db and addon.db.profile and addon.db.profile.modules and addon.db.profile.modules.nameplates
    if not np then
        return
    end
    if np.bghTestMode then
        np.bghTestMode = false
    end
    ClearBGHTestMarks()
end

local function EnsureOptionsPanelHideHook()
    if not Panel or not Panel.frame or Panel._bghTestHideHooked then
        return
    end
    Panel._bghTestHideHooked = true
    Panel.frame:HookScript("OnHide", function()
        DisableBGHTestMode()
    end)
end

-- ============================================================================
-- ACTIVE SUB-TAB STATE
-- ============================================================================

local activeSubTab = "general"

local subTabs = {
    { key = "general",  label = LO["General"] },
    { key = "layout",   label = LO["Layout"] },
    { key = "behavior", label = LO["Behavior"] },
    { key = "health",   label = LO["Name & Health"] },
    { key = "target",   label = LO["Target & Threat"] },
    { key = "bars",     label = LO["Bars"] },
    { key = "icons",    label = LO["Icons"] },
    { key = "quest",    label = LO["Quest"] },
    { key = "debuffs",  label = LO["Auras"] },
}

function addon.SetNameplateSubTab(key)
    activeSubTab = key or "general"
end

-- Search navigation sub-tab setter.
Panel.subTabSetters = Panel.subTabSetters or {}
Panel.subTabSetters["nameplates"] = function(key) activeSubTab = key or "general" end

-- ============================================================================
-- SUB-TAB BUILDERS
-- ============================================================================

-- The modern capsule paints its own background, so the two background pickers have nothing to set.
local function RetailChromeOwnsBackground()
    local style = C:GetDBValue(DB .. ".plateStyle")
    return style ~= "legacy" and style ~= "classic"
end

-- Modern draws every plate text with the retail font recipe, so the font pickers only reach Heritage.
local ModernOwnsText = RetailChromeOwnsBackground

-- Tank and DPS mode return before the retail branch in ResolveAggroColor, so only
-- the default palette changes: orange for tanking, yellow for gaining or losing.
local function UsesRetailThreatColors()
    local style = C:GetDBValue(DB .. ".plateStyle")
    if style == "legacy" or style == "classic" then
        return false
    end
    if C:GetDBValue(DB .. ".retailThreatColors") == false then
        return false
    end
    return C:GetDBValue(DB .. ".tankMode") ~= true and C:GetDBValue(DB .. ".dpsMode") ~= true
end

local function BuildGeneralSubTab(scroll)
    C:AddSpacer(scroll)

    local general = C:AddSection(scroll, LO["General"])

    C:AddModuleToggle(general, {
        label = LO["Enable Nameplates Module"],
        desc = LO["Apply DragonUI nameplate styling."],
        moduleName = "nameplates",
    })

    C:AddToggle(general, {
        label = LO["Allow Nameplate Overlap"],
        desc = LO["Allow native nameplates to overlap. Retail-like Stacking enables this automatically because its custom stacking algorithm requires overlap."],
        getFunc = function()
            return GetCVar("nameplateAllowOverlap") == "1"
        end,
        setFunc = function(val)
            SetCVar("nameplateAllowOverlap", val and "1" or "0")
        end,
    })

    local styleSection = C:AddSection(scroll, LO["Plate Style"])
    local seededStyle = C:GetDBValue(DB .. ".plateStyle")
    local function IsLegacyStyle()
        local style = C:GetDBValue(DB .. ".plateStyle")
        return style == "legacy" or style == "classic"
    end

    C:AddDropdown(styleSection, {
        label = LO["Nameplate Art"],
        desc = LO["Heritage is the DragonUI art. Modern draws the current World of Warcraft nameplate chrome."],
        dbPath = DB .. ".plateStyle",
        values = {
            modern = LO["Modern"],
            legacy = LO["Heritage"],
        },
        width = 200,
        -- Each style is authored against its own bar size, so seed it on the switch;
        -- the Layout sliders stay editable afterwards.
        callback = function()
            local style = C:GetDBValue(DB .. ".plateStyle")
            -- Re-picking the value already selected fires this too, and would wipe tuned sliders.
            if style ~= seededStyle then
                seededStyle = style
                local modern = style == "modern"
                C:SetDBValue(DB .. ".barWidth", modern and 148 or 150)
                C:SetDBValue(DB .. ".barHeight", modern and 16 or 9)
                C:SetDBValue(DB .. ".castBarHeight", modern and 8 or 9)
                -- Modern starts from the retail font and text sizes; all stay editable afterwards.
                C:SetDBValue(DB .. ".fontSize", 2)
                C:SetDBValue(DB .. ".castBarSpellNameFontSize", modern and 8 or 9)
                -- The retail timer is 0.55 of the icon; Modern scales it up again on enlarged icons.
                local iconSize = C:GetDBValue(DB .. ".debuffIconSize") or 24
                C:SetDBValue(DB .. ".debuffCooldownFontSize",
                    modern and math.min(16, math.max(8, math.floor(iconSize * 0.55 + 0.5))) or 10)
                if modern then
                    C:SetDBValue(DB .. ".nameFont", "primary")
                    -- The modern cast bar is drawn around its spell name, so the skin needs it on.
                    C:SetDBValue(DB .. ".showCastBarSpellName", true)
                end
                -- Retail plates show no aggro flare, while the legacy glow is part of that art.
                C:SetDBValue(DB .. ".threatGlow", not modern)
            end
            RefreshNameplates()
            if Panel and Panel.SelectTab then
                Panel:SelectTab("nameplates")
            end
        end,
    })

    C:AddToggle(styleSection, {
        label = LO["Target Selection Border"],
        desc = LO["Draw the white glowing border around the current target's health bar."],
        dbPath = DB .. ".retailSelectionBorder",
        disabled = IsLegacyStyle,
        callback = RefreshNameplates,
    })

    C:AddToggle(styleSection, {
        label = LO["Dim Non-Target Plates"],
        desc = LO["Lay the retail dim overlay over every nameplate that is not your target."],
        dbPath = DB .. ".retailDeselectedOverlay",
        disabled = IsLegacyStyle,
        callback = RefreshNameplates,
    })

    C:AddToggle(styleSection, {
        label = LO["Mouseover Highlight"],
        desc = LO["Wash the health bar with a bright overlay while the cursor is over the nameplate."],
        dbPath = DB .. ".retailMouseoverHighlight",
        disabled = IsLegacyStyle,
        callback = RefreshNameplates,
    })

    C:AddToggle(styleSection, {
        label = LO["Retail Threat Colors"],
        desc = LO["Use retail's yellow and orange threat steps instead of the yellow, orange and red set."],
        dbPath = DB .. ".retailThreatColors",
        disabled = IsLegacyStyle,
        callback = function()
            RefreshNameplates()
            if Panel and Panel.SelectTab then
                Panel:SelectTab("nameplates")
            end
        end,
    })

    local unitPlates = C:AddSection(scroll, LO["Unit Nameplates"])
    local unitCols = C:AddRow(unitPlates, { layout = "Flow" })

    local friendlySubCvars = {
        {
            cvar = "nameplateShowFriendlyPets",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_FRIENDLY_PETS",
            labelKey = "Pets",
        },
        {
            cvar = "nameplateShowFriendlyGuardians",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_FRIENDLY_GUARDIANS",
            labelKey = "Guardians",
        },
        {
            cvar = "nameplateShowFriendlyTotems",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_FRIENDLY_TOTEMS",
            labelKey = "Totems",
        },
    }
    local enemySubCvars = {
        {
            cvar = "nameplateShowEnemyPets",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_ENEMY_PETS",
            labelKey = "Pets",
        },
        {
            cvar = "nameplateShowEnemyGuardians",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_ENEMY_GUARDIANS",
            labelKey = "Guardians",
        },
        {
            cvar = "nameplateShowEnemyTotems",
            labelGlobal = "UNIT_NAMEPLATES_SHOW_ENEMY_TOTEMS",
            labelKey = "Totems",
        },
    }

    local function RefreshFriendlySubDisabled()
        local on = CVarBool("nameplateShowFriends")
        for _, sub in ipairs(friendlySubCvars) do
            if sub._widget then
                sub._widget:SetDisabled(not on)
            end
        end
    end
    local function RefreshEnemySubDisabled()
        local on = CVarBool("nameplateShowEnemies")
        for _, sub in ipairs(enemySubCvars) do
            if sub._widget then
                sub._widget:SetDisabled(not on)
            end
        end
    end

    AddNameplateCVarColumn(unitCols, "Friendly Units", "nameplateShowFriends",
        friendlySubCvars, RefreshFriendlySubDisabled)
    AddNameplateCVarColumn(unitCols, "Enemy Units", "nameplateShowEnemies",
        enemySubCvars, RefreshEnemySubDisabled)

    local opacity = C:AddSection(scroll, LO["Opacity"])

    C:AddToggle(opacity, {
        label = LO["Disable Non-Target Fade"],
        desc = LO["Keep all nameplates fully opaque when you have a target."],
        dbPath = DB .. ".disableNonTargetFade",
        callback = RefreshNameplates,
    })

    C:AddSlider(opacity, {
        label = LO["Background Plates Opacity"],
        desc = LO["Controls the opacity of non-target nameplates while fade is active (0.0 - 1.0)."],
        dbPath = DB .. ".opacityNonTarget",
        min = 0.0, max = 1.0, step = 0.01,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddToggle(opacity, {
        label = LO["No Target: Full Opacity"],
        desc = LO["When you have no target, show all nameplates at full opacity."],
        dbPath = DB .. ".opacityFullNoTarget",
        callback = RefreshNameplates,
    })

    C:AddToggle(opacity, {
        label = LO["Party/Raid: Full Opacity"],
        desc = LO["Always show party and raid member nameplates at full opacity, regardless of target or fade settings. Does not affect pets or NPCs."],
        dbPath = DB .. ".opacityFullParty",
        callback = RefreshNameplates,
    })

    local addonCompat = C:AddSection(scroll, LO["Addon Compatibility"])
    C:AddDescription(addonCompat, LO["Enable this if you use an external nameplate addon (PlateBuffs, Crosshairs, ...) that isn't detecting DragonUI's nameplates correctly."])
    C:AddToggle(addonCompat, {
        label = LO["Nameplate Addon Compatibility"],
        desc = LO["Stops overriding the nameplate's native transparency/visibility, which some external addons rely on to find their target. Non-target nameplates will dim like vanilla."],
        dbPath = DB .. ".nameplateAlphaCompat",
        requiresReload = true,
    })
    C:AddDescription(addonCompat, LO["Enable this if you use an addon (Icicle, ...) that attaches its own widgets to DragonUI's nameplate health bar."])
    C:AddToggle(addonCompat, {
        label = LO["Nameplate Health Bar Compatibility"],
        desc = LO["Hides the native health bar by fading its individual textures instead of the whole bar, for addons that attach widgets directly to it."],
        dbPath = DB .. ".nameplateBarAlphaCompat",
        callback = RefreshNameplates,
    })

end

local function BuildBehaviorSubTab(scroll)
    C:AddSpacer(scroll)

    local behavior = C:AddSection(scroll, LO["Behavior"])
    local function IsRetailStackingDisabled()
        local m = addon.db.profile.modules and addon.db.profile.modules.nameplates
        if not m then
            return true
        end
        return m.retailStackingEnabled ~= true
    end

    C:AddToggle(behavior, {
        label = LO["Depth Ordering"],
        desc = LO["Order overlapping nameplates by depth."]
            .. " " .. (LO["(Requires Allow Nameplate Overlap.)"] or ""),
        dbPath = DB .. ".depthSortingEnabled",
        callback = RefreshNameplates,
    })

    C:AddToggle(behavior, {
        label = LO["Retail-like Stacking"],
        desc = (LO["Simulates Retail's nameplate stacking for enemies."] or "")
            .. " "
            .. (LO["May increase CPU use with many visible nameplates."] or ""),
        dbPath = DB .. ".retailStackingEnabled",
        callback = function(val)
            RefreshNameplates()
            if Panel and Panel.SelectTab then
                Panel:SelectTab("nameplates")
            end
        end,
    })

    C:AddSlider(behavior, {
        label = LO["Collider Width"],
        desc = LO["Sets the width of the virtual collider centered on each nameplate used to detect overlaps."],
        dbPath = DB .. ".retailStackingXSpace",
        min = 0, max = 200, step = 1,
        width = 200,
        disabled = IsRetailStackingDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(behavior, {
        label = LO["Collider Height"],
        desc = LO["Sets the height of the virtual collider centered on each nameplate used to detect overlaps."],
        dbPath = DB .. ".retailStackingYSpace",
        min = 5, max = 50, step = 1,
        width = 200,
        disabled = IsRetailStackingDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(behavior, {
        label = LO["Vertical Offset"],
        desc = LO["Vertical offset baseline for Retail-like stacking."],
        dbPath = DB .. ".retailStackingOriginY",
        min = 0, max = 100, step = 1,
        width = 200,
        disabled = IsRetailStackingDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(behavior, {
        label = LO["Freeze Mouseover"],
        desc = LO["Keeps the hovered nameplate fixed while stacking updates around it."],
        dbPath = DB .. ".retailStackingFreezeMouseover",
        disabled = IsRetailStackingDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(behavior, {
        label = LO["Disable in Open World"],
        desc = LO["Only apply Retail-like stacking inside party and raid instances. It remains disabled in the open world, battlegrounds, and arenas."],
        dbPath = DB .. ".retailStackingInInstance",
        disabled = IsRetailStackingDisabled,
        callback = RefreshNameplates,
    })
end

local function BuildLayoutSubTab(scroll)
    C:AddSpacer(scroll)

    local sizePos = C:AddSection(scroll, LO["Size & Position"])

    C:AddSlider(sizePos, {
        label = LO["Bar Width"],
        dbPath = DB .. ".barWidth",
        min = 80, max = 240, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddSlider(sizePos, {
        label = LO["Bar Height"],
        dbPath = DB .. ".barHeight",
        min = 3, max = 20, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddSlider(sizePos, {
        label = LO["Bar Stack Gap"],
        desc = LO["Vertical spacing between health, power, and cast bars (pixels)."],
        dbPath = DB .. ".castBarGap",
        min = 0, max = 15, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddSlider(sizePos, {
        label = LO["Offset X"],
        dbPath = DB .. ".offsetX",
        min = -50, max = 50, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddSlider(sizePos, {
        label = LO["Offset Y"],
        dbPath = DB .. ".offsetY",
        min = -50, max = 50, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    local clampControls = {}
    local function SetClampControlsDisabled(disabled)
        for _, w in ipairs(clampControls) do
            if w and w.SetDisabled then
                w:SetDisabled(disabled)
            end
        end
    end
    local function UpdateClampControlStates()
        local cfg = addon.db.profile.modules and addon.db.profile.modules.nameplates
        local anyClamp = cfg and (cfg.clampTarget == true or cfg.clampBoss == true)
        SetClampControlsDisabled(not anyClamp)
    end

    C:AddToggle(sizePos, {
        label = LO["Clamp Target to Screen"],
        desc = LO["Keep the target nameplate visible at the top of the screen. Extends WorldFrame height when enabled."],
        dbPath = DB .. ".clampTarget",
        callback = function()
            RefreshNameplates()
            UpdateClampControlStates()
        end,
    })

    C:AddToggle(sizePos, {
        label = LO["Clamp Bosses to Screen"],
        desc = LO["Keep hostile boss and world-boss nameplates visible at the top of the screen wherever they appear."],
        dbPath = DB .. ".clampBoss",
        callback = function()
            RefreshNameplates()
            UpdateClampControlStates()
        end,
    })

    clampControls[#clampControls + 1] = C:AddSlider(sizePos, {
        label = LO["Clamp Top Inset"],
        desc = LO["Distance below the top edge where clamped nameplates stop."],
        dbPath = DB .. ".clampTopInset",
        min = 0, max = 200, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    UpdateClampControlStates()

    local clickboxSection = C:AddSection(scroll, LO["Clickbox"])

    local CLICKBOX_AUTO_SHOW_IDLE = 3
    local showClickboxToggle

    local function RefreshShowClickboxWidget(value)
        local panel = addon.OptionsPanel
        if not (panel and panel.IsOpen and panel:IsOpen()) then return end
        if showClickboxToggle and showClickboxToggle.SetValue then
            showClickboxToggle:SetValue(value and true or false)
        end
    end

    local function OnClickboxSliderChanged()
        RefreshNameplates()
        local NP = addon.Nameplates
        if not (NP and NP.clickbox and NP.module) then return end
        if not C:GetDBValue(DB .. ".showClickbox") then
            C:SetDBValue(DB .. ".showClickbox", true)
            -- Flags the Show as ours, so only an auto-enable is auto-disabled when the sliders go idle.
            NP.module._clickboxSliderAutoShow = true
            RefreshShowClickboxWidget(true)
        end
        NP.module._clickboxSliderIdleUntil = GetTime() + CLICKBOX_AUTO_SHOW_IDLE
        NP.clickbox.RefreshAllOverlays()
    end

    C:AddSlider(clickboxSection, {
        label = LO["Clickbox Width Factor"],
        desc = LO["Scales the nameplate clickbox relative to its original size. Changes made during combat are applied when combat ends."],
        dbPath = DB .. ".clickboxWidthFactor",
        min = 0.25, max = 1.5, step = 0.01,
        width = 200,
        callback = OnClickboxSliderChanged,
    })

    C:AddSlider(clickboxSection, {
        label = LO["Clickbox Height Factor"],
        desc = LO["Scales the nameplate clickbox relative to its original size. Changes made during combat are applied when combat ends."],
        dbPath = DB .. ".clickboxHeightFactor",
        min = 0.25, max = 2.5, step = 0.01,
        width = 200,
        callback = OnClickboxSliderChanged,
    })

    C:AddSlider(clickboxSection, {
        label = LO["Totem Click Padding"],
        desc = LO["Extra clickable padding on totem nameplates (easier to click)."],
        dbPath = DB .. ".totemClickPadding",
        min = 0, max = 24, step = 1,
        width = 200,
        callback = OnClickboxSliderChanged,
    })

    showClickboxToggle = C:AddToggle(clickboxSection, {
        label = LO["Show Clickbox"],
        desc = LO["Displays the box selection space (clickbox) of nameplates."],
        dbPath = DB .. ".showClickbox",
        callback = function()
            local NP = addon.Nameplates
            if NP and NP.clickbox and NP.module then
                -- Toggling by hand takes ownership of the setting; drop any pending auto-off.
                NP.module._clickboxSliderAutoShow = nil
                NP.module._clickboxSliderIdleUntil = nil
                NP.clickbox.RefreshAll()
                NP.clickbox.RefreshAllOverlays()
            end
        end,
    })

    if addon.Nameplates and addon.Nameplates.module then
        addon.Nameplates.module._clickboxToggleRefresh = RefreshShowClickboxWidget
    end
end

local function BuildHealthSubTab(scroll)
    C:AddSpacer(scroll)

    local function GetNP()
        return addon.db.profile.modules and addon.db.profile.modules.nameplates or {}
    end

    -- Controls that grey out with another setting, refreshed in place so the panel keeps its scroll.
    local dependents = {}
    local function Depends(widget, isDisabled)
        dependents[widget] = isDisabled
        return widget
    end
    local function RefreshDependents()
        for widget, isDisabled in pairs(dependents) do
            if widget.SetDisabled then
                widget:SetDisabled(isDisabled())
            end
        end
        RefreshNameplates()
    end
    -- For changes that add or remove controls.
    local function RebuildKeepingScroll()
        RefreshNameplates()
        if not Panel or not Panel.SelectTab then return end
        local savedScroll = Panel.scrollWidget and Panel.scrollWidget.scrollbar
            and Panel.scrollWidget.scrollbar:GetValue() or 0
        Panel:SelectTab("nameplates")
        if savedScroll > 0 and Panel.scrollWidget and Panel.scrollWidget.scrollbar then
            Panel.scrollWidget.scrollbar:SetValue(savedScroll)
            Panel.scrollWidget:SetScroll(savedScroll)
        end
    end

    local function IsNameInsideBar()
        return GetNP().nameOverlayHealthBar == true
    end
    local function IsNameAboveBar()
        return not IsNameInsideBar()
    end
    local function IsLevelAlwaysShown()
        return GetNP().showLevelAlways == true
    end
    local function IsHealthTextOff()
        return GetNP().healthTextFormat == "none"
    end
    -- A name inside the bar pins the text to the bar's right end, so there is nothing to choose.
    local function IsHealthTextPositionLocked()
        return IsHealthTextOff() or IsNameInsideBar()
    end
    local function IsHealthTextFontSizeUnused()
        return ModernOwnsText() or IsHealthTextPositionLocked()
            or (GetNP().healthTextPosition or "afterName") == "afterName"
    end
    local function HasNoFriendlyClassBars()
        local np = GetNP()
        return not (np.friendlyClassColors or np.partyClassColors)
    end
    local function HasNoEnemyClassBars()
        return GetNP().enemyPlayerClassColors == false
    end

    local nameSection = C:AddSection(scroll, LO["Name"])

    local placeRow = C:AddRow(nameSection)
    C:AddDropdown(placeRow, {
        label = LO["Name Position"],
        values = {
            above = LO["Above the Health Bar"],
            inside = LO["Inside the Health Bar"],
        },
        width = 220,
        getFunc = function()
            return IsNameInsideBar() and "inside" or "above"
        end,
        setFunc = function(value)
            C:SetDBValue(DB .. ".nameOverlayHealthBar", value == "inside")
        end,
        -- The health text section explains a different layout for each position.
        callback = RebuildKeepingScroll,
    })
    C:AddSlider(placeRow, {
        label = LO["Vertical Offset"],
        desc = LO["Moves the name up or down while it sits inside the health bar."],
        dbPath = DB .. ".nameOverlayOffsetY",
        min = -20, max = 20, step = 1,
        width = 200,
        disabled = IsNameAboveBar,
        callback = RefreshNameplates,
    })

    C:AddSlider(nameSection, {
        label = LO["Horizontal Padding"],
        desc = LO["Inset the name, level, and health text from the left and right edges of the health bar. Does not affect the elite icon."],
        dbPath = DB .. ".nameRowPaddingX",
        min = 0, max = 40, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })

    C:AddToggle(nameSection, {
        label = LO["Center Name"],
        desc = LO["Center the name in the space the health text leaves free."],
        dbPath = DB .. ".centerNameOnly",
        callback = RefreshNameplates,
    })

    local fontRow = C:AddRow(nameSection)
    C:AddDropdown(fontRow, {
        label = LO["Font"],
        dbPath = DB .. ".nameFont",
        values = {
            primary = LO["Primary Font"],
            actionbar = LO["Actionbar Font"],
            narrow = LO["Narrow Font"],
            arial = LO["Arial Font"],
        },
        width = 220,
        callback = RefreshNameplates,
    })
    C:AddSlider(fontRow, {
        label = LO["Font Size"],
        desc = LO["Font size of the name, and of the health text when it follows the name (1-10, default 2)."],
        dbPath = DB .. ".fontSize",
        min = 1, max = 10, step = 1,
        width = 200,
        callback = RefreshNameplates,
    })
    if ModernOwnsText() then
        -- One setting per name position, so inside and above keep their own choice.
        local function OutlineKey()
            return DB .. (IsNameInsideBar() and ".retailTextOutlineInside" or ".retailTextOutlineAbove")
        end
        C:AddToggle(nameSection, {
            label = LO["Text Outline"],
            desc = LO["Black outline on the name and health text."],
            getFunc = function()
                local value = C:GetDBValue(OutlineKey())
                if IsNameInsideBar() then
                    return value ~= false
                end
                return value == true
            end,
            setFunc = function(value)
                C:SetDBValue(OutlineKey(), value and true or false)
            end,
            callback = RefreshNameplates,
        })
    end

    local levelSection = C:AddSection(scroll, LO["Level"])

    C:AddToggle(levelSection, {
        label = LO["Show Level Always"],
        desc = LO["Always show the unit level next to the name."],
        dbPath = DB .. ".showLevelAlways",
        callback = RefreshDependents,
    })
    Depends(C:AddToggle(levelSection, {
        label = LO["Show Level In Name When Targeted"],
        dbPath = DB .. ".showLevelInName",
        disabled = IsLevelAlwaysShown,
        callback = RefreshNameplates,
    }), IsLevelAlwaysShown)
    Depends(C:AddToggle(levelSection, {
        label = LO["Show Level on Hover"],
        dbPath = DB .. ".showLevelOnHover",
        disabled = IsLevelAlwaysShown,
        callback = RefreshNameplates,
    }), IsLevelAlwaysShown)
    C:AddDropdown(levelSection, {
        label = LO["Level Format"],
        dbPath = DB .. ".levelTextFormat",
        values = {
            brackets = "[LVL]",
            parentheses = "(LVL)",
            plain = "LVL",
        },
        width = 220,
        callback = RefreshNameplates,
    })

    local healthTextSection = C:AddSection(scroll, LO["Health Text"])

    local textRow = C:AddRow(healthTextSection)
    C:AddDropdown(textRow, {
        label = LO["Show"],
        desc = LO["What the health text shows. With both, the value comes first."],
        dbPath = DB .. ".healthTextFormat",
        values = {
            none = LO["None"],
            percent = LO["Percent"],
            value = LO["Value"],
            valuePercent = LO["Value and Percent"],
        },
        width = 200,
        callback = RefreshDependents,
    })
    Depends(C:AddDropdown(textRow, {
        label = LO["Position"],
        desc = LO["After the name, the name is shortened so the two never overlap. With the name inside the health bar, the text always sits at the bar's right end."],
        dbPath = DB .. ".healthTextPosition",
        -- Show what the plate draws: a name inside the bar forces the text after it.
        getFunc = function()
            return IsNameInsideBar() and "afterName" or (GetNP().healthTextPosition or "afterName")
        end,
        values = {
            afterName = LO["After the Name"],
            barCenter = LO["Inside the Bar, Centered"],
            barRight = LO["Inside the Bar, Right"],
            barSplit = LO["Inside the Bar, Value Left and Percent Right"],
        },
        width = 260,
        disabled = IsHealthTextPositionLocked,
        callback = RefreshDependents,
    }), IsHealthTextPositionLocked)
    Depends(C:AddSlider(textRow, {
        label = LO["Font Size"],
        desc = LO["Font size of the health text inside the bar (1-10). After the name, or in the Modern style, it matches the name."],
        dbPath = DB .. ".healthNumberFontSize",
        min = 1, max = 10, step = 1,
        width = 200,
        disabled = IsHealthTextFontSizeUnused,
        callback = RefreshNameplates,
    }), IsHealthTextFontSizeUnused)

    if IsNameInsideBar() then
        C:AddDescription(healthTextSection, LO["The name is inside the health bar, so the health text sits at the bar's right end, after the name."])
    end

    local barSection = C:AddSection(scroll, LO["Health Bar"])

    if RetailChromeOwnsBackground() then
        C:AddDescription(barSection, LO["The Modern style draws its own bar background."])
    end
    C:AddDropdown(barSection, {
        label = LO["Health Bar Background"],
        desc = LO["Choose the background texture used behind the health bar fill."],
        dbPath = DB .. ".healthBarBackground",
        disabled = RetailChromeOwnsBackground,
        values = {
            black = LO["Black"],
            castbar = LO["Same as Castbar"],
        },
        width = 200,
        callback = RefreshNameplates,
    })
    C:AddToggle(barSection, {
        label = LO["Gray Tapped Units"],
        desc = LO["Grays the health bar when a unit is tapped by another player or group."],
        dbPath = DB .. ".tapDeniedGray",
        callback = function()
            if addon.Nameplates and addon.Nameplates.tap then
                local np = addon.db.profile.modules and addon.db.profile.modules.nameplates
                if np and np.tapDeniedGray == false then
                    addon.Nameplates.tap.WipeCache()
                end
            end
            RefreshNameplates()
        end,
    })

    local colorSection = C:AddSection(scroll, LO["Colors"])

    C:AddHeading(colorSection, LO["Friendly Units"])
    local friendlyColorRow = C:AddRow(colorSection)
    C:AddColorPicker(friendlyColorRow, {
        label = LO["Friendly Player Color"],
        dbPath = DB .. ".friendlyPlayerColor",
        callback = RefreshNameplates,
    })
    C:AddColorPicker(friendlyColorRow, {
        label = LO["Friendly NPC Color"],
        dbPath = DB .. ".friendlyNPCColor",
        callback = RefreshNameplates,
    })
    C:AddToggle(colorSection, {
        label = LO["Party Class Colors"],
        desc = LO["Use class colors for party member nameplates instead of the friendly player color."],
        dbPath = DB .. ".partyClassColors",
        callback = RefreshDependents,
    })
    C:AddToggle(colorSection, {
        label = LO["Friendly Class Colors"],
        desc = LO["Class-color every friendly player, not just your group. Party and raid show automatically; others fill in when you target or mouse over them, or instantly with awesome_wotlk."],
        dbPath = DB .. ".friendlyClassColors",
        callback = RefreshDependents,
    })
    C:AddToggle(colorSection, {
        label = LO["Remember Players and NPCs"],
        desc = LO["Remember the class, guild and title of players you have seen and the titles of NPCs you have hovered, so they show at once next time. Used only by the class color, guild and title options. When off, everything learned is forgotten at logout."],
        dbPath = DB .. ".unitCacheRemember",
        callback = RefreshNameplates,
    })
    C:AddButton(colorSection, {
        label = LO["Forget Learned Players and NPCs"],
        desc = LO["Delete the players learned on this realm and every learned NPC title."],
        callback = function()
            StaticPopupDialogs["DRAGONUI_FORGET_UNIT_CACHE"] = StaticPopupDialogs["DRAGONUI_FORGET_UNIT_CACHE"] or {
                text = LO["Forget every player and NPC title that nameplates have learned?"],
                button1 = LO["Yes"],
                button2 = LO["No"],
                OnAccept = function()
                    local NP = addon.Nameplates
                    if NP and NP.unitcache then
                        NP.unitcache.Forget()
                    end
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("DRAGONUI_FORGET_UNIT_CACHE")
        end,
    })

    C:AddHeading(colorSection, LO["Enemy Units"])
    C:AddToggle(colorSection, {
        label = LO["Enemy Player Class Colors"],
        desc = LO["Use class colors for enemy player nameplates."],
        dbPath = DB .. ".enemyPlayerClassColors",
        callback = RefreshDependents,
    })

    C:AddHeading(colorSection, LO["Name Text"])
    C:AddToggle(colorSection, {
        label = LO["Name Reaction Colors"],
        desc = LO["Tint name text with the health bar reaction color (red/yellow/green/blue)."],
        dbPath = DB .. ".nameReactionColors",
        callback = RefreshNameplates,
    })
    Depends(C:AddToggle(colorSection, {
        label = LO["Class Colors on Friendly Names"],
        desc = LO["Color friendly player names by class. Needs Party Class Colors or Friendly Class Colors."],
        dbPath = DB .. ".friendlyNameClassColors",
        disabled = HasNoFriendlyClassBars,
        callback = RefreshNameplates,
    }), HasNoFriendlyClassBars)
    Depends(C:AddToggle(colorSection, {
        label = LO["Class Colors on Enemy Names"],
        desc = LO["Color enemy player names by class. Needs Enemy Player Class Colors."],
        dbPath = DB .. ".enemyNameClassColors",
        disabled = HasNoEnemyClassBars,
        callback = RefreshNameplates,
    }), HasNoEnemyClassBars)

    local headline = C:AddSection(scroll, LO["Headline Mode"])

    C:AddToggle(headline, {
        label = LO["Enable Headline Mode"],
        desc = LO["Hide health, power and cast bars on friendly nameplates, showing only the name."],
        dbPath = DB .. ".friendlyNameOnly",
        callback = RebuildKeepingScroll,
    })

    if GetNP().friendlyNameOnly == true then
        C:AddColorPicker(headline, {
            label = LO["Name Text Color"],
            dbPath = DB .. ".friendlyNameOnlyColor",
            callback = RefreshNameplates,
        })

        C:AddLabel(headline, LO["Friendly Players"])
        C:AddDescription(headline, LO["Class colors, title, guild and AFK read from the unit: party/raid show automatically; others fill in when you target or mouse over them, or instantly with awesome_wotlk."])

        C:AddToggle(headline, {
            label = LO["Party / Raid Members"],
            desc = LO["Apply headline mode to your party and raid members."],
            dbPath = DB .. ".friendlyNameOnlyParty",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["All Friendly Players"],
            desc = LO["Apply headline mode to all friendly players, not just your group."],
            dbPath = DB .. ".friendlyNameOnlyAll",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show Class Colors"],
            desc = LO["Show friendly player names in their class color."],
            dbPath = DB .. ".friendlyNameOnlyClassColor",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show Player Title"],
            desc = LO["Show the player's title with their name (e.g. \"Arthas Jenkins\")."],
            dbPath = DB .. ".friendlyNameOnlyTitle",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show Guild Name"],
            desc = LO["Show the player's guild name below their name."],
            dbPath = DB .. ".friendlyNameOnlyGuild",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show AFK Status"],
            desc = LO["Show an <AFK> tag for away players."],
            dbPath = DB .. ".friendlyNameOnlyAFK",
            callback = RefreshNameplates,
        })

        C:AddLabel(headline, LO["Friendly NPCs"])
        C:AddDescription(headline, LO["NPC titles fill in when you target or mouse over the NPC, or instantly with awesome_wotlk."])

        C:AddToggle(headline, {
            label = LO["Headline Mode for NPCs"],
            desc = LO["Apply headline mode to friendly NPCs."],
            dbPath = DB .. ".friendlyNPCNameOnly",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show NPC Title"],
            desc = LO["Show the NPC's title or occupation below its name (e.g. <General Supplies>)."],
            dbPath = DB .. ".friendlyNPCNameOnlyTitle",
            callback = RefreshNameplates,
        })
        C:AddToggle(headline, {
            label = LO["Show Full Plate on Target"],
            desc = LO["When headline mode is active, show health, power and cast bars on your current target."],
            dbPath = DB .. ".headlineExcludeTarget",
            callback = RefreshNameplates,
        })
    end
end

local function BuildTargetSubTab(scroll)
    C:AddSpacer(scroll)

    local targetThreat = C:AddSection(scroll, LO["Target & Threat"])

    C:AddToggle(targetThreat, {
        label = LO["Show Target Highlight"],
        desc = LO["White border glow on the current target nameplate."],
        dbPath = DB .. ".showTargetHighlight",
        callback = RefreshNameplates,
    })

    C:AddToggle(targetThreat, {
        label = LO["Show Target Arrows"],
        desc = LO["Left/right arrows on the targeted nameplate."],
        dbPath = DB .. ".showTargetArrows",
        callback = RefreshNameplates,
    })

    C:AddToggle(targetThreat, {
        label = LO["Only Show Target Nameplate"],
        desc = LO["Show only your target's hostile nameplate. In combat, also show hostile NPCs attacking you. Friendly plates are never hidden by this."],
        dbPath = DB .. ".onlyTargetPlates",
        callback = RefreshNameplates,
    })

    C:AddToggle(targetThreat, {
        label = LO["Show Threat Glow"],
        desc = UsesRetailThreatColors()
            and LO["Color the glow and health bar by threat status (orange = tanking, yellow = gaining or losing)."]
            or LO["Color the glow and health bar by threat status (red = tanking, orange = losing, yellow = gaining)."],
        dbPath = DB .. ".threatGlow",
        callback = RefreshNameplates,
    })

    -- Tank Mode / DPS Mode are mutually exclusive — enabling one clears the other.
    local function AddThreatRoleToggle(roleKey, otherKey, label, desc)
        C:AddToggle(targetThreat, {
            label = label,
            desc = desc,
            dbPath = DB .. "." .. roleKey,
            callback = function()
                local conflicted = C:GetDBValue(DB .. "." .. roleKey)
                    and C:GetDBValue(DB .. "." .. otherKey)
                if conflicted then
                    C:SetDBValue(DB .. "." .. otherKey, false)
                end
                RefreshNameplates()
                -- Always redraw: the threat-glow description depends on this role too.
                if Panel.currentTab then
                    Panel:SelectTab(Panel.currentTab)
                end
            end,
        })
    end

    AddThreatRoleToggle(
        "tankMode", "dpsMode",
        LO["Tank Mode"],
        LO["Inverts threat colors for a tank: green means you hold aggro, red means you lost it."]
    )
    AddThreatRoleToggle(
        "dpsMode", "tankMode",
        LO["DPS Mode"],
        LO["In combat, colors by threat for DPS: green = no aggro, yellow = transition, red = you have aggro."]
    )
end

local function BuildBarsSubTab(scroll)
    C:AddSpacer(scroll)

    local powerSection = C:AddSection(scroll, LO["Power Bar"])
    local function IsPowerBarDisabled()
        return not C:GetDBValue(DB .. ".showPowerBar")
    end

    C:AddToggle(powerSection, {
        label = LO["Show Power Bar"],
        dbPath = DB .. ".showPowerBar",
        callback = RefreshAndRebuildNameplates,
    })

    C:AddToggle(powerSection, {
        label = LO["Power Bar — Players Only"],
        dbPath = DB .. ".powerPlayersOnly",
        disabled = IsPowerBarDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(powerSection, {
        label = LO["Show Power Bar Text"],
        desc = LO["Show numeric values (current / percent) on the power bar."],
        dbPath = DB .. ".showPowerBarText",
        disabled = IsPowerBarDisabled,
        callback = RefreshNameplates,
    })

    C:AddDropdown(powerSection, {
        label = LO["Power Bar Background"],
        desc = LO["Choose the background texture used behind the power bar fill."],
        dbPath = DB .. ".powerBarBackground",
        values = {
            black = LO["Black"],
            castbar = LO["Same as Castbar"],
        },
        width = 200,
        disabled = function()
            return IsPowerBarDisabled() or RetailChromeOwnsBackground()
        end,
        callback = RefreshNameplates,
    })

    local castSection = C:AddSection(scroll, LO["Cast Bar"])
    local function IsCastBarDisabled()
        return not C:GetDBValue(DB .. ".showCastBar")
    end

    C:AddToggle(castSection, {
        label = LO["Show Cast Bars"],
        desc = LO["Show cast bars when the unit is known for sure: your target, focus, mouseover, arena enemies, or a group member's target."],
        dbPath = DB .. ".showCastBar",
        callback = RefreshAndRebuildNameplates,
    })

    C:AddSlider(castSection, {
        label = LO["Cast Bar Height"],
        dbPath = DB .. ".castBarHeight",
        min = 3, max = 20, step = 1,
        width = 200,
        disabled = IsCastBarDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(castSection, {
        label = LO["Show Spell Name"],
        desc = LO["Show the spell name text on the cast bar."],
        dbPath = DB .. ".showCastBarSpellName",
        disabled = IsCastBarDisabled,
        callback = RefreshAndRebuildNameplates,
    })

    local function IsSpellNameDisabled()
        return IsCastBarDisabled() or not C:GetDBValue(DB .. ".showCastBarSpellName")
    end

    C:AddSlider(castSection, {
        label = LO["Spell Name Font Size"],
        dbPath = DB .. ".castBarSpellNameFontSize",
        min = 6, max = 16, step = 1,
        width = 200,
        disabled = IsSpellNameDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(castSection, {
        label = LO["Spell Name Offset X"],
        dbPath = DB .. ".castBarSpellNameOffsetX",
        min = -50, max = 50, step = 1,
        width = 200,
        disabled = IsSpellNameDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(castSection, {
        label = LO["Spell Name Offset Y"],
        dbPath = DB .. ".castBarSpellNameOffsetY",
        min = -20, max = 20, step = 1,
        width = 200,
        disabled = IsSpellNameDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(castSection, {
        label = LO["Modern Icon Border"],
        desc = LO["Modern Icon Border Desc"],
        dbPath = DB .. ".castBarModernIconBorder",
        disabled = IsCastBarDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(castSection, {
        label = LO["Spell Icon Left of Bar"],
        desc = LO["Modern style: show the spell icon to the left of the cast bar instead of under it."],
        dbPath = DB .. ".castBarModernIconLeft",
        disabled = function()
            local style = C:GetDBValue(DB .. ".plateStyle")
            return IsCastBarDisabled() or style == "legacy" or style == "classic"
        end,
        callback = RefreshNameplates,
    })

    C:AddToggle(castSection, {
        label = LO["Show Party/Raid Cast Bars"],
        desc = LO["Also show cast bars on party and raid allies, even when you are not targeting them."],
        dbPath = DB .. ".showPartyRaidCastBars",
        disabled = IsCastBarDisabled,
        callback = RefreshNameplates,
    })

    C:AddToggle(castSection, {
        label = LO["Hide Pet Casts"],
        desc = LO["Hide Pet Casts Desc"],
        dbPath = DB .. ".castBarHidePetCasts",
        disabled = IsCastBarDisabled,
        callback = RefreshNameplates,
    })

    local offTargetSection = C:AddSection(scroll, LO["Off-Target Cast Bars"])

    local function GetOffTargetCastMode()
        local mode = C:GetDBValue(DB .. ".castBarOffTargetMode")
        if mode == "off" or mode == "aggressive" or mode == "safe" or mode == "hybrid" then
            return mode
        end
        if C:GetDBValue(DB .. ".castBarOffTargetSafeOnly") then
            return "safe"
        end
        if C:GetDBValue(DB .. ".castBarOffTarget") then
            return "aggressive"
        end
        return "safe"
    end

    -- The three nested checkboxes (enable / aggressive / players-only) collapse to
    -- one of the four engine modes. Reaction filters (hostile/enemy-player only) are
    -- intentionally gone: 3.3.5a only ever shows enemy OR ally plates (CVar), so they
    -- were redundant; we clear their legacy DB values so they never affect this UI.
    local function ApplyOffTargetState(enabled, aggressive, playersOnly)
        local mode
        if not enabled then
            mode = "off"
        elseif not aggressive then
            mode = "safe"
        elseif playersOnly then
            mode = "hybrid"
        else
            mode = "aggressive"
        end
        C:SetDBValue(DB .. ".castBarOffTargetMode", mode)
        C:SetDBValue(DB .. ".castBarOffTarget", mode == "aggressive")
        C:SetDBValue(DB .. ".castBarOffTargetSafeOnly", mode == "safe")
        C:SetDBValue(DB .. ".castBarPvPAggressive", false)
        C:SetDBValue(DB .. ".castBarOffTargetHostileOnly", false)
    end

    local function RebuildNameplatesTab()
        RefreshNameplates()
        if Panel and Panel.SelectTab then
            Panel:SelectTab("nameplates")
        end
    end

    local offTargetMode = GetOffTargetCastMode()
    local offTargetEnabled = offTargetMode ~= "off"
    local offTargetAggressive = offTargetMode == "aggressive" or offTargetMode == "hybrid"
    local offTargetPlayersOnly = offTargetMode == "hybrid"

    C:AddToggle(offTargetSection, {
        label = LO["Enable Off-Target Detection"],
        desc = LO["Enable Off-Target Detection Desc"],
        getFunc = function() return GetOffTargetCastMode() ~= "off" end,
        setFunc = function(value)
            ApplyOffTargetState(value, offTargetAggressive, offTargetPlayersOnly)
        end,
        disabled = IsCastBarDisabled,
        callback = RebuildNameplatesTab,
    })

    if offTargetEnabled then
        local aggressiveDesc = LO["Off-Target Aggressive Mode Desc"] .. "\n\n" .. LO["Off-Target Aggressive Warning"]
            .. "\n\n" .. LO["Off-Target Aggressive Ignored"]

        C:AddToggle(offTargetSection, {
            label = LO["Off-Target Aggressive Mode"],
            desc = aggressiveDesc,
            getFunc = function()
                local m = GetOffTargetCastMode()
                return m == "aggressive" or m == "hybrid"
            end,
            setFunc = function(value)
                ApplyOffTargetState(true, value, offTargetPlayersOnly)
            end,
            disabled = IsCastBarDisabled,
            callback = RebuildNameplatesTab,
        })

        if offTargetAggressive then
            local playersOnlyDesc = LO["Off-Target Players Only Desc"] .. "\n\n" .. LO["Off-Target Players Only Warning"]
                .. "\n\n" .. LO["Off-Target Aggressive Ignored"]

            C:AddToggle(offTargetSection, {
                label = LO["Off-Target Players Only"],
                desc = playersOnlyDesc,
                getFunc = function() return GetOffTargetCastMode() == "hybrid" end,
                setFunc = function(value)
                    ApplyOffTargetState(true, true, value)
                end,
                disabled = IsCastBarDisabled,
                callback = RebuildNameplatesTab,
            })
        end
    end
end

local function BuildIconsSubTab(scroll)
    EnsureOptionsPanelHideHook()
    C:AddSpacer(scroll)

    local iconSection = C:AddSection(scroll, LO["Icons & Markers"])

    local function RebuildIconsSubTab()
        RefreshNameplates()
        if Panel and Panel.SelectTab then
            Panel:SelectTab("nameplates")
        end
    end

    C:AddToggle(iconSection, {
        label = LO["Show Raid Markers"],
        desc = LO["Show raid target markers (skull, cross, star, etc.) on nameplates."],
        dbPath = DB .. ".showRaidMarkers",
        callback = RebuildIconsSubTab,
    })

    -- Nested under Show Raid Markers (same pattern as off-target cast options).
    if (Panel and Panel.indexing) or C:GetDBValue(DB .. ".showRaidMarkers") then
        C:AddToggle(iconSection, {
            label = LO["Beside Bar Layout"],
            desc = LO["Place the raid marker beside the bar (as with DragonUI debuffs). Useful with other aura addons."],
            dbPath = DB .. ".raidMarkerDebuffLayout",
            indent = 18,
            callback = RefreshNameplates,
        })
    end

    C:AddToggle(iconSection, {
        label = LO["Color Health Bar by Raid Marker"],
        desc = LO["Colors the health bar with the raid marker's color, on both allies and enemies."],
        dbPath = DB .. ".raidMarkHealthColor",
        callback = RefreshNameplates,
    })

    C:AddToggle(iconSection, {
        label = LO["Show Elite Icon"],
        desc = LO["Show elite/rare dragon icon on nameplates."],
        dbPath = DB .. ".showEliteIcon",
        callback = RefreshAndRebuildNameplates,
    })

    C:AddDropdown(iconSection, {
        label = LO["Elite Icon Style"],
        desc = LO["Choose dragon or star style for elite and rare nameplate icons."],
        dbPath = DB .. ".eliteIconStyle",
        values = {
            dragon = LO["Dragon"],
            star = LO["Star"],
        },
        width = 220,
        disabled = function()
            return not C:GetDBValue(DB .. ".showEliteIcon")
        end,
        callback = RefreshNameplates,
    })

    C:AddSlider(iconSection, {
        label = LO["Elite Icon Vertical Offset"],
        desc = LO["Fine-tune the elite/rare icon's vertical position."],
        dbPath = DB .. ".eliteIconOffsetY",
        min = -20, max = 20, step = 1,
        width = 200,
        disabled = function()
            return not C:GetDBValue(DB .. ".showEliteIcon")
        end,
        callback = RefreshNameplates,
    })

    C:AddToggle(iconSection, {
        label = LO["Show Combo Points"],
        desc = LO["Show combo points on the current target nameplate."],
        dbPath = DB .. ".showComboPoints",
        callback = RebuildIconsSubTab,
    })

    -- Combo Points sub-section: appears only when Show Combo Points is enabled,
    -- so its controls are gated by IsComboDisabled below. Native (Rogue/Druid)
    -- path keeps its single combo-<points> icon; the per-row slider only affects
    -- custom-class stack resources (Reaper/Demonhunter/Ranger/...).
    local function IsComboDisabled()
        return not C:GetDBValue(DB .. ".showComboPoints")
    end

    -- Fixed upper bound covers every class stack resource (maxStacks <= 5 today);
    -- the engine clamps perRow to the active class's count at render time, so a
    -- value above the class max simply renders as a single row.
    local COMBO_PER_ROW_MAX = 10

    if (Panel and Panel.indexing) or C:GetDBValue(DB .. ".showComboPoints") then
        local comboSection = C:AddSection(scroll, LO["Combo Points"])

        C:AddDropdown(comboSection, {
            label = LO["Anchor Position"],
            desc = LO["Choose where the combo widget is anchored on the target nameplate health bar."],
            dbPath = DB .. ".comboAnchor",
            values = {
                TOP = LO["Top"],
                BOTTOM = LO["Bottom"],
                LEFT = LO["Left"],
                RIGHT = LO["Right"],
            },
            width = 220,
            disabled = IsComboDisabled,
            callback = RefreshNameplates,
        })

        C:AddSlider(comboSection, {
            label = LO["Scale"],
            desc = LO["Scale of the combo widget (0.5 - 2.0)."],
            dbPath = DB .. ".comboScale",
            min = 0.5, max = 2.0, step = 0.05,
            width = 200,
            disabled = IsComboDisabled,
            callback = RefreshNameplates,
        })

        C:AddSlider(comboSection, {
            label = LO["Offset X"],
            desc = LO["Horizontal offset from the chosen anchor point. Negative moves left, positive moves right."],
            dbPath = DB .. ".comboOffsetX",
            min = -200, max = 200, step = 1,
            width = 200,
            disabled = IsComboDisabled,
            callback = RefreshNameplates,
        })

        C:AddSlider(comboSection, {
            label = LO["Offset Y"],
            desc = LO["Vertical offset from the chosen anchor point. Negative moves down, positive moves up."],
            dbPath = DB .. ".comboOffsetY",
            min = -200, max = 200, step = 1,
            width = 200,
            disabled = IsComboDisabled,
            callback = RefreshNameplates,
        })

        C:AddSlider(comboSection, {
            label = LO["Combos Per Row"],
            desc = LO["Maximum combo segments per row on custom-class resources (Reaper, Demonhunter, Ranger, ...). Rogue and Druid use a single combined icon and are not affected. Wrap to a second row when exceeded."],
            -- DB 0 means "auto": as many as the class needs, all in one row.
            -- Map it to the slider max so the widget displays that state; the
            -- engine clamps perRow to the active class's count at render time.
            getFunc = function()
                local v = C:GetDBValue(DB .. ".comboPerRow")
                if not v or v <= 0 then return COMBO_PER_ROW_MAX end
                return v
            end,
            setFunc = function(v)
                C:SetDBValue(DB .. ".comboPerRow", v)
            end,
            min = 1, max = COMBO_PER_ROW_MAX, step = 1,
            width = 200,
            disabled = IsComboDisabled,
            callback = RefreshNameplates,
        })
    end

    local function IsTotemIconsDisabled()
        return not C:GetDBValue(DB .. ".showTotemIcons")
    end
    local totemIconOnlyToggle, totemTimerToggle, totemNormalModeBox, totemPositionDropdown

    local function RefreshTotemControlStates(val)
        local disabled = not val
        if totemIconOnlyToggle and totemIconOnlyToggle.SetDisabled then
            totemIconOnlyToggle:SetDisabled(disabled)
        end
        if totemTimerToggle and totemTimerToggle.SetDisabled then
            totemTimerToggle:SetDisabled(disabled)
        end
        if totemNormalModeBox and totemNormalModeBox.SetDisabled then
            totemNormalModeBox:SetDisabled(disabled)
        end
        if totemPositionDropdown and totemPositionDropdown.SetDisabled then
            totemPositionDropdown:SetDisabled(disabled)
        end
    end

    C:AddToggle(iconSection, {
        label = LO["Show Totem Icons"],
        desc = LO["Show icons for recognized shaman totems. DragonUI uses localized spell names and automatically learns your own active totems."],
        dbPath = DB .. ".showTotemIcons",
        callback = RefreshAndRebuildNameplates,
    })

    totemIconOnlyToggle = C:AddToggle(iconSection, {
        label = LO["Totem Icon Only"],
        desc = LO["Hide the totem's nameplate entirely and show only its icon."],
        dbPath = DB .. ".totemIconOnly",
        disabled = IsTotemIconsDisabled,
        callback = RefreshNameplates,
    })

    totemTimerToggle = C:AddToggle(iconSection, {
        label = LO["Show Totem Life Timer"],
        desc = LO["Show remaining life on your own totems (requires their icon to be known)."],
        dbPath = DB .. ".showTotemTimer",
        disabled = IsTotemIconsDisabled,
        callback = RefreshNameplates,
    })

    totemNormalModeBox = C:AddEditBox(iconSection, {
        label = LO["Totems Without Icon"],
        desc = LO["Comma-separated, exact totem names (as shown in-game) that should never get a totem icon and render as a normal nameplate instead."],
        dbPath = DB .. ".totemNormalModeList",
        disabled = IsTotemIconsDisabled,
        callback = RefreshNameplates,
    })

    totemPositionDropdown = C:AddDropdown(iconSection, {
        label = LO["Totem Icon Position"],
        desc = LO["Choose where the totem icon is anchored around the nameplate."],
        dbPath = DB .. ".totemIconPosition",
        values = {
            top = LO["Top"],
            left = LO["Left"],
            right = LO["Right"],
        },
        width = 220,
        disabled = IsTotemIconsDisabled,
        callback = RefreshNameplates,
    })

    RefreshTotemControlStates(not IsTotemIconsDisabled())

    local bghCompat = C:AddSection(scroll, LO["BG Healer Icon"])
    if IsBattleGroundHealersLoaded() then
        C:AddDescription(bghCompat, LO["Override BattleGroundHealers icon position on DragonUI nameplates."])
    else
        C:AddDescription(bghCompat, LO["This feature is available only when BattleGroundHealers is loaded."])
    end

    local function IsBGHCompatConfigDisabled()
        local np = addon.db.profile.modules and addon.db.profile.modules.nameplates
        return (not IsBattleGroundHealersLoaded()) or (np and np.bghCompatEnabled == false)
    end

    C:AddToggle(bghCompat, {
        label = LO["BattleGroundHealers Compatibility"],
        desc = LO["Keep BG healer marks attached to DragonUI nameplates."],
        dbPath = DB .. ".bghCompatEnabled",
        disabled = function()
            return not IsBattleGroundHealersLoaded()
        end,
        callback = function(val)
            if not val then
                ClearBGHTestMarks()
            end
            RefreshNameplates()
            if Panel and Panel.SelectTab then
                Panel:SelectTab("nameplates")
            end
        end,
    })

    C:AddDropdown(bghCompat, {
        label = LO["Anchor"],
        dbPath = DB .. ".bghIconAnchor",
        values = {
            left = LO["Left"],
            top = LO["Top"],
            right = LO["Right"],
            bottom = LO["Bottom"],
        },
        disabled = IsBGHCompatConfigDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(bghCompat, {
        label = LO["Offset X"],
        dbPath = DB .. ".bghIconOffsetX",
        min = -120, max = 120, step = 1,
        width = 200,
        disabled = IsBGHCompatConfigDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(bghCompat, {
        label = LO["Offset Y"],
        dbPath = DB .. ".bghIconOffsetY",
        min = -120, max = 120, step = 1,
        width = 200,
        disabled = IsBGHCompatConfigDisabled,
        callback = RefreshNameplates,
    })

    C:AddSlider(bghCompat, {
        label = LO["Icon Size"],
        dbPath = DB .. ".bghIconSize",
        min = 12, max = 60, step = 1,
        width = 200,
        disabled = IsBGHCompatConfigDisabled,
        callback = RefreshNameplates,
    })

    local markTargetButton
    C:AddToggle(bghCompat, {
        label = LO["Enable Test Mode"],
        desc = LO["Enable manual marking for BattleGroundHealers compatibility checks."],
        dbPath = DB .. ".bghTestMode",
        disabled = IsBGHCompatConfigDisabled,
        callback = function(val)
            if not val then
                ClearBGHTestMarks()
            end
            if markTargetButton and markTargetButton.SetDisabled then
                markTargetButton:SetDisabled(not val)
            end
        end,
    })

    markTargetButton = C:AddButton(bghCompat, {
        label = LO["Mark Target"],
        desc = LO["Toggle BattleGroundHealers mark on your current target while test mode is enabled."],
        disabled = function()
            local np = addon.db.profile.modules and addon.db.profile.modules.nameplates
            if IsBGHCompatConfigDisabled() then
                return true
            end
            return not (np and np.bghTestMode == true)
        end,
        callback = ToggleBGHTestMarkTarget,
    })
end

local function BuildQuestSubTab(scroll)
    C:AddSpacer(scroll)

    local function IsQuestIconsDisabled()
        return not C:GetDBValue(DB .. ".questIcons.enabled")
    end

    -- X / Y / Size sliders in one row, bound to icons[keyGetter()] (the selected texture).
    local function AddIconRow(parent, keyGetter)
        local function field(f)
            return DB .. ".questIcons.icons." .. keyGetter() .. "." .. f
        end
        local row = C:AddRow(parent)
        C:AddSlider(row, {
            label = LO["Offset X"],
            getFunc = function() return C:GetDBValue(field("x")) end,
            setFunc = function(v) C:SetDBValue(field("x"), v) end,
            min = -200, max = 200, step = 1, width = 150,
            disabled = IsQuestIconsDisabled,
            callback = RefreshNameplates,
        })
        C:AddSlider(row, {
            label = LO["Offset Y"],
            getFunc = function() return C:GetDBValue(field("y")) end,
            setFunc = function(v) C:SetDBValue(field("y"), v) end,
            min = -200, max = 200, step = 1, width = 150,
            disabled = IsQuestIconsDisabled,
            callback = RefreshNameplates,
        })
        C:AddSlider(row, {
            label = LO["Size"],
            getFunc = function() return C:GetDBValue(field("size")) end,
            setFunc = function(v) C:SetDBValue(field("size"), v) end,
            min = 8, max = 128, step = 1, width = 150,
            disabled = IsQuestIconsDisabled,
            callback = RefreshNameplates,
        })
    end

    -- General
    local general = C:AddSection(scroll, LO["Quest Icons"])
    C:AddToggle(general, {
        label = LO["Show Quest Icons"],
        desc = LO["Show kill/loot icons over your quest-objective mobs. Without awesome_wotlk, only your target, mouseover and focus show them."],
        dbPath = DB .. ".questIcons.enabled",
        callback = RefreshAndRebuildNameplates,
    })
    C:AddToggle(general, {
        label = LO["Resolve By Name"],
        desc = LO["Match plate names to your active objectives so icons show on every plate without awesome_wotlk. Kill objectives work on their own; loot needs a quest addon below."],
        dbPath = DB .. ".questIcons.nameResolution",
        disabled = IsQuestIconsDisabled,
        callback = RefreshQuestNameResolution,
    })
    C:AddDropdown(general, {
        label = LO["Loot Database"],
        desc = LO["Which quest addon supplies loot data (which mob drops a quest item). Auto picks the best loaded one."],
        dbPath = DB .. ".questIcons.lootProvider",
        values = {
            auto = LO["Auto"],
            off = LO["Off"],
            pfquest = "pfQuest",
            questie = "Questie",
            questhelper = "QuestHelper",
        },
        width = 220,
        disabled = IsQuestIconsDisabled,
        callback = RefreshQuestNameResolution,
    })
    C:AddDropdown(general, {
        label = LO["Icons With Questie"],
        desc = LO["Who draws quest icons on plates when Questie is loaded with its own nameplate icons on. DragonUI disables Questie's (needs reload); Questie hides DragonUI's."],
        dbPath = DB .. ".questIcons.questieCoexist",
        values = {
            ask = LO["Ask"],
            dragonui = "DragonUI",
            questie = "Questie",
        },
        width = 220,
        disabled = function() return IsQuestIconsDisabled() or not (_G.Questie or _G.QuestieLoader) end,
        callback = function()
            local np = addon.Nameplates
            if not (np and np.quest_coexist) then return end
            local val = C:GetDBValue(DB .. ".questIcons.questieCoexist")
            if np.quest_coexist.ApplyChoice then np.quest_coexist.ApplyChoice(val) end
            if val == "ask" and np.quest_coexist.Check then np.quest_coexist.Check() end
        end,
    })
    C:AddToggle(general, {
        label = LO["Pointer Mode"],
        desc = LO["Show a single quest marker on any objective mob instead of separate kill/loot icons."],
        dbPath = DB .. ".questIcons.pointerMode",
        disabled = IsQuestIconsDisabled,
        callback = RefreshAndRebuildNameplates,
    })
    C:AddButton(general, {
        label = LO["Reset Learned Quest Loot"],
        desc = LO["Forget which mobs nameplates learned drop your quest items. They are learned again as you play."],
        callback = function()
            StaticPopupDialogs["DRAGONUI_RESET_QUEST_LOOT"] = StaticPopupDialogs["DRAGONUI_RESET_QUEST_LOOT"] or {
                text = LO["Forget every quest item source that nameplates have learned?"],
                button1 = LO["Yes"],
                button2 = LO["No"],
                OnAccept = function()
                    local global = addon.db and addon.db.global
                    if global and type(global.questLootLearned) == "table" then
                        wipe(global.questLootLearned)
                    end
                    RefreshQuestNameResolution()
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("DRAGONUI_RESET_QUEST_LOOT")
        end,
    })

    -- Test preview (tuning aid)
    local test = C:AddSection(scroll, LO["Test Preview"])
    C:AddDescription(test, LO["Force one icon on all enemy nameplates so you can position and size it. Set to Off when done."])
    C:AddDropdown(test, {
        label = LO["Preview Icon"],
        dbPath = DB .. ".questIcons.testIcon",
        values = {
            off = LO["Off"],
            sword = LO["Sword"],
            skull = LO["Skull"],
            elite = LO["Elite"],
            bag = LO["Bag"],
            chest = LO["Chest"],
            pointer = LO["Pointer"],
        },
        width = 220,
        disabled = IsQuestIconsDisabled,
        callback = RefreshNameplates,
    })

    -- Kill icon: style + position/size of the selected texture
    local killS = C:AddSection(scroll, LO["Kill Icon"])
    C:AddDropdown(killS, {
        label = LO["Icon"],
        desc = LO["Choose the icon shown for kill objectives."],
        dbPath = DB .. ".questIcons.killIcon",
        values = {
            sword = LO["Sword"],
            skull = LO["Skull"],
        },
        width = 220,
        disabled = IsQuestIconsDisabled,
        callback = RefreshAndRebuildNameplates,
    })
    AddIconRow(killS, function() return C:GetDBValue(DB .. ".questIcons.killIcon") end)

    -- Elite kill icon (auto-override for elite/rare kill objectives)
    local eliteS = C:AddSection(scroll, LO["Elite Kill Icon"])
    C:AddToggle(eliteS, {
        label = LO["Enabled"],
        desc = LO["Show a distinct icon on elite and rare kill objectives."],
        dbPath = DB .. ".questIcons.eliteKillIcon",
        disabled = IsQuestIconsDisabled,
        callback = RefreshNameplates,
    })
    AddIconRow(eliteS, function() return "elite" end)

    -- Loot icon
    local lootS = C:AddSection(scroll, LO["Loot Icon"])
    C:AddDropdown(lootS, {
        label = LO["Icon"],
        desc = LO["Choose the icon shown for loot/collect objectives."],
        dbPath = DB .. ".questIcons.lootIcon",
        values = {
            bag = LO["Bag"],
            chest = LO["Chest"],
        },
        width = 220,
        disabled = IsQuestIconsDisabled,
        callback = RefreshAndRebuildNameplates,
    })
    AddIconRow(lootS, function() return C:GetDBValue(DB .. ".questIcons.lootIcon") end)

    -- Pointer icon
    local ptrS = C:AddSection(scroll, LO["Pointer Icon"])
    AddIconRow(ptrS, function() return "pointer" end)
end

local function BuildDebuffsSubTab(scroll)
    C:AddSpacer(scroll)

    local function IsDebuffsDisabled()
        return not C:GetDBValue(DB .. ".showDebuffs")
    end
    local function IsCooldownTextDisabled()
        return IsDebuffsDisabled() or not C:GetDBValue(DB .. ".showDebuffCooldown")
    end
    local function IsCooldownSwipeDisabled()
        return IsDebuffsDisabled() or not C:GetDBValue(DB .. ".debuffCooldownSwipe")
    end
    local function IsBuffsDisabled()
        return IsDebuffsDisabled() or not C:GetDBValue(DB .. ".showBuffs")
    end
    local function IsColorDisabled()
        return IsDebuffsDisabled() or not C:GetDBValue(DB .. ".debuffHighlightCC")
    end
    local function IsFriendlyAurasDisabled()
        return not C:GetDBValue(DB .. ".showFriendlyAuras")
    end

    local dynamicWidgets = {}
    local function RegisterDynamicWidget(widget, disabledFunc)
        table.insert(dynamicWidgets, { widget = widget, disabledFunc = disabledFunc })
        return widget
    end
    -- Rebuilding is only needed when a control appears or disappears, not when it greys out.
    local function RefreshDisabledStates()
        for _, entry in ipairs(dynamicWidgets) do
            if entry.widget and entry.widget.SetDisabled and entry.disabledFunc then
                entry.widget:SetDisabled(entry.disabledFunc())
            end
        end
        RefreshNameplates()
    end
    local function RebuildAuraUI()
        RefreshNameplates()
        if Panel and Panel.SelectTab then
            Panel:SelectTab("nameplates")
        end
    end
    local function OnPositionSliderChanged()
        RefreshNameplates()
        if addon.Nameplates and addon.Nameplates.auras then
            addon.Nameplates.auras.EnablePreview(10)
        end
    end
    -- Registers a control so RefreshDisabledStates can grey it out without a rebuild.
    local function Track(widget, disabledFunc)
        if widget and disabledFunc then RegisterDynamicWidget(widget, disabledFunc) end
        return widget
    end

    local rowSection = C:AddSection(scroll, LO["Aura Row"])

    C:AddToggle(rowSection, {
        label = LO["Show Auras"],
        desc = LO["Show buffs and debuffs above nameplates."],
        dbPath = DB .. ".showDebuffs",
        callback = RebuildAuraUI,
    })

    Track(C:AddSlider(rowSection, {
        label = LO["Max Aura Icons"],
        desc = LO["Buffs and debuffs share these slots."],
        dbPath = DB .. ".maxDebuffs",
        min = 1, max = 9, step = 1,
        width = 200,
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
    }), IsDebuffsDisabled)

    Track(C:AddSlider(rowSection, {
        label = LO["Aura Icon Size"],
        dbPath = DB .. ".debuffIconSize",
        min = 10, max = 42, step = 1,
        width = 200,
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
    }), IsDebuffsDisabled)

    Track(C:AddToggle(rowSection, {
        label = LO["Modern Icon Border"],
        desc = LO["Modern Icon Border Debuff Desc"],
        dbPath = DB .. ".debuffModernIconBorder",
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
    }), IsDebuffsDisabled)

    Track(C:AddSlider(rowSection, {
        label = LO["Aura Horizontal Offset"],
        dbPath = DB .. ".debuffOffsetX",
        min = -240, max = 240, step = 1,
        width = 200,
        disabled = IsDebuffsDisabled,
        callback = OnPositionSliderChanged,
    }), IsDebuffsDisabled)

    Track(C:AddSlider(rowSection, {
        label = LO["Aura Vertical Offset"],
        dbPath = DB .. ".debuffOffsetY",
        min = -240, max = 240, step = 1,
        width = 200,
        disabled = IsDebuffsDisabled,
        callback = OnPositionSliderChanged,
    }), IsDebuffsDisabled)

    Track(C:AddToggle(rowSection, {
        label = LO["Show Debuff Position Debug Box"],
        desc = LO["Displays a box showing where the debuff icon row starts and ends, even when no debuffs are active."],
        dbPath = DB .. ".showDebuffPositionDebug",
        disabled = IsDebuffsDisabled,
        callback = function()
            if addon.Nameplates and addon.Nameplates.auras then
                addon.Nameplates.module._debuffPreviewUntil = nil
                addon.Nameplates.auras.RefreshAllPreviewOverlays()
            end
        end,
    }), IsDebuffsDisabled)

    C:AddSpacer(scroll)

    local timerSection = C:AddSection(scroll, LO["Timers"])

    Track(C:AddToggle(timerSection, {
        label = LO["Show Cooldown Text"],
        desc = LO["Time left on each icon."],
        dbPath = DB .. ".showDebuffCooldown",
        disabled = IsDebuffsDisabled,
        callback = RefreshDisabledStates,
    }), IsDebuffsDisabled)

    Track(C:AddSlider(timerSection, {
        label = LO["Cooldown Font Size"],
        dbPath = DB .. ".debuffCooldownFontSize",
        min = 6, max = 16, step = 1,
        width = 200,
        disabled = IsCooldownTextDisabled,
        callback = RefreshNameplates,
    }), IsCooldownTextDisabled)

    Track(C:AddDropdown(timerSection, {
        label = LO["Cooldown Text Position"],
        dbPath = DB .. ".debuffCooldownTextAnchor",
        values = {
            center = LO["Center"],
            topleft = LO["Top Left"],
            topright = LO["Top Right"],
            bottomleft = LO["Bottom Left"],
            bottomright = LO["Bottom Right"],
        },
        width = 220,
        disabled = IsCooldownTextDisabled,
        callback = RefreshNameplates,
    }), IsCooldownTextDisabled)

    Track(C:AddToggle(timerSection, {
        label = LO["Show Cooldown Swipe"],
        desc = LO["Radial sweep over the icon as it runs out."],
        dbPath = DB .. ".debuffCooldownSwipe",
        disabled = IsDebuffsDisabled,
        callback = RefreshDisabledStates,
    }), IsDebuffsDisabled)

    Track(C:AddDropdown(timerSection, {
        label = LO["Cooldown Swipe Style"],
        dbPath = DB .. ".debuffCooldownSwipeStyle",
        values = {
            vertical = LO["Shade Fill"],
            pie = LO["Quadrant Sweep"],
            squareSwirl = LO["Square Radial Sweep"],
        },
        width = 220,
        disabled = IsCooldownSwipeDisabled,
        callback = RefreshNameplates,
    }), IsCooldownSwipeDisabled)

    C:AddSpacer(scroll)

    local orderSection = C:AddSection(scroll, LO["Icon Order"])

    C:AddLabel(orderSection, LO["Importance: crowd control first, then enemy defensives, then your own debuffs."])
    C:AddLabel(orderSection, LO["Time Remaining: whatever expires soonest goes first."])

    Track(C:AddDropdown(orderSection, {
        label = LO["Order Icons By"],
        dbPath = DB .. ".auraSortMode",
        values = {
            priority = LO["Importance"],
            chronological = LO["Time Remaining"],
        },
        width = 220,
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
    }), IsDebuffsDisabled)

    C:AddSpacer(scroll)

    local sizeSection = C:AddSection(scroll, LO["Highlighted Auras"])

    C:AddLabel(sizeSection, LO["Highlighted auras draw larger than the rest."])

    local function IsHighlightListDisabled()
        local mode = C:GetDBValue(DB .. ".auraHighlightMode")
        return IsDebuffsDisabled() or (mode ~= "list" and mode ~= "ccAndList")
    end
    local function IsHighlightScaleDisabled()
        return IsDebuffsDisabled() or C:GetDBValue(DB .. ".auraHighlightMode") == "none"
    end

    Track(C:AddDropdown(sizeSection, {
        label = LO["What Gets Highlighted"],
        dbPath = DB .. ".auraHighlightMode",
        values = {
            cc = LO["Crowd Control"],
            list = LO["Spell List Only"],
            ccAndList = LO["Crowd Control + List"],
            none = LO["Nothing"],
        },
        width = 220,
        disabled = IsDebuffsDisabled,
        callback = RefreshDisabledStates,
    }), IsDebuffsDisabled)

    Track(C:AddSlider(sizeSection, {
        label = LO["Highlight Size"],
        desc = LO["Multiplier over the base icon size."],
        dbPath = DB .. ".auraHighlightScale",
        min = 1, max = 2, step = 0.05,
        width = 200,
        disabled = IsHighlightScaleDisabled,
        callback = RefreshNameplates,
    }), IsHighlightScaleDisabled)

    C:AddHeading(sizeSection, LO["Always Highlight These Spells"])
    C:AddSpellFilterList(sizeSection, {
        dbPath = DB .. ".auraHighlightList",
        disabled = IsHighlightListDisabled,
        callback = RefreshNameplates,
        rebuildUI = RebuildAuraUI,
        registerDynamic = RegisterDynamicWidget,
    })

    C:AddSpacer(scroll)

    local colorSection = C:AddSection(scroll, LO["Border Colors"])

    C:AddLabel(colorSection, LO["Blizzard's dispel colors, editable below."])

    C:AddToggle(colorSection, {
        label = LO["Colored Aura Borders"],
        dbPath = DB .. ".debuffHighlightCC",
        disabled = IsDebuffsDisabled,
        callback = RefreshDisabledStates,
    })

    local dispelRow = C:AddRow(colorSection, { layout = "Flow" })
    local dispelColors = {
        { key = "Magic", label = LO["Magic"] },
        { key = "Curse", label = LO["Curse"] },
        { key = "Disease", label = LO["Disease"] },
        { key = "Poison", label = LO["Poison"] },
        { key = "Enrage", label = LO["Enrage"] },
        { key = "none", label = LO["No Dispel Type"] },
        { key = "Buff", label = LO["Buffs"] },
    }
    for _, entry in ipairs(dispelColors) do
        Track(C:AddColorPicker(dispelRow, {
            label = entry.label,
            dbPath = DB .. ".auraColors." .. entry.key,
            disabled = IsColorDisabled,
            callback = RefreshNameplates,
        }), IsColorDisabled)
    end

    local function IsCCColorDisabled()
        return IsColorDisabled() or not C:GetDBValue(DB .. ".auraColorCCEnabled")
    end

    Track(C:AddToggle(colorSection, {
        label = LO["Separate Color for Crowd Control"],
        dbPath = DB .. ".auraColorCCEnabled",
        disabled = IsColorDisabled,
        callback = RefreshDisabledStates,
    }), IsColorDisabled)

    Track(C:AddColorPicker(colorSection, {
        label = LO["Crowd Control"],
        dbPath = DB .. ".auraColors.CrowdControl",
        disabled = IsCCColorDisabled,
        callback = RefreshNameplates,
    }), IsCCColorDisabled)

    C:AddSpacer(scroll)

    local debuffSection = C:AddSection(scroll, LO["Debuffs"])

    Track(C:AddToggle(debuffSection, {
        label = LO["Only Show on Target & Focus"],
        desc = LO["Hide auras on every nameplate except your target and focus."],
        dbPath = DB .. ".debuffOnlyTargetFocus",
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
    }), IsDebuffsDisabled)

    local function IsOtherCCDisabled()
        return IsDebuffsDisabled() or not C:GetDBValue(DB .. ".debuffOnlyMine")
    end

    Track(C:AddToggle(debuffSection, {
        label = LO["Only My Debuffs"],
        desc = LO["Only show debuffs you applied yourself."],
        dbPath = DB .. ".debuffOnlyMine",
        disabled = IsDebuffsDisabled,
        callback = RefreshDisabledStates,
    }), IsDebuffsDisabled)

    Track(C:AddToggle(debuffSection, {
        label = LO["Always Show Others' Crowd Control"],
        desc = LO["Enemy crowd control matters no matter who cast it."],
        dbPath = DB .. ".debuffIncludeOtherCC",
        disabled = IsOtherCCDisabled,
        callback = RefreshNameplates,
    }), IsOtherCCDisabled)

    local function IsDebuffListDisabled()
        local mode = C:GetDBValue(DB .. ".debuffFilterMode")
        return IsDebuffsDisabled() or (mode ~= "whitelist" and mode ~= "blacklist")
    end

    Track(C:AddDropdown(debuffSection, {
        label = LO["Debuff List Mode"],
        dbPath = DB .. ".debuffFilterMode",
        values = {
            all = LO["All"],
            whitelist = LO["Whitelist"],
            blacklist = LO["Blacklist"],
        },
        width = 220,
        disabled = IsDebuffsDisabled,
        callback = RebuildAuraUI,
    }), IsDebuffsDisabled)

    local debuffListMode = C:GetDBValue(DB .. ".debuffFilterMode")
    if debuffListMode ~= "all" then
        C:AddHeading(debuffSection, LO["Debuff List"])
        -- Shared debuffs such as Sunder Armor carry one caster, so "Only My Debuffs" can hide yours.
        local rules = {
            dbPath = DB .. ".debuffFilterRules",
            editable = debuffListMode == "whitelist",
            label = LO["Show"],
            values = {
                any = LO["Always (anyone's)"],
                default = LO["Follow 'Only My Debuffs'"],
                mine = LO["Only Mine"],
            },
        }
        if rules.editable then
            C:AddLabel(debuffSection, LO["Each listed spell can decide whose casts it shows, whatever 'Only My Debuffs' says."])
        end
        C:AddSpellFilterList(debuffSection, {
            dbPath = DB .. ".debuffFilterList",
            disabled = IsDebuffListDisabled,
            callback = RefreshNameplates,
            rebuildUI = RebuildAuraUI,
            registerDynamic = RegisterDynamicWidget,
            rules = rules,
        })
    end

    C:AddSpacer(scroll)

    local buffSection = C:AddSection(scroll, LO["Enemy Buffs"])

    C:AddToggle(buffSection, {
        label = LO["Show Enemy Buffs"],
        desc = LO["Buffs share the row with debuffs, ordered by priority."],
        dbPath = DB .. ".showBuffs",
        disabled = IsDebuffsDisabled,
        callback = RebuildAuraUI,
    })

    Track(C:AddDropdown(buffSection, {
        label = LO["Which Buffs"],
        dbPath = DB .. ".buffFilterMode",
        values = {
            purgeable = LO["Purgeable & Defensive"],
            all = LO["All"],
            whitelist = LO["Whitelist"],
            blacklist = LO["Blacklist"],
        },
        width = 220,
        disabled = IsBuffsDisabled,
        callback = RebuildAuraUI,
    }), IsBuffsDisabled)

    -- Only one buff list is ever relevant, so only one is ever shown.
    local buffMode = C:GetDBValue(DB .. ".buffFilterMode") or "purgeable"
    if buffMode == "purgeable" then
        C:AddLabel(buffSection, LO["Shows buffs you can dispel or steal, plus the defensive cooldowns listed here."])
        C:AddHeading(buffSection, LO["Defensive Buff List"])
        C:AddSpellFilterList(buffSection, {
            dbPath = DB .. ".defensiveBuffList",
            disabled = IsBuffsDisabled,
            callback = RefreshNameplates,
            rebuildUI = RebuildAuraUI,
            registerDynamic = RegisterDynamicWidget,
        })
    elseif buffMode == "whitelist" or buffMode == "blacklist" then
        C:AddHeading(buffSection, LO["Buff List"])
        C:AddSpellFilterList(buffSection, {
            dbPath = DB .. ".buffFilterList",
            disabled = IsBuffsDisabled,
            callback = RefreshNameplates,
            rebuildUI = RebuildAuraUI,
            registerDynamic = RegisterDynamicWidget,
        })
    end

    C:AddSpacer(scroll)

    local friendlySection = C:AddSection(scroll, LO["Friendly Plates"])

    C:AddToggle(friendlySection, {
        label = LO["Show Auras on Allies"],
        desc = LO["An ally carries dozens of auras, so you pick below what earns a slot."],
        dbPath = DB .. ".showFriendlyAuras",
        callback = RebuildAuraUI,
    })

    C:AddHeading(friendlySection, LO["Debuffs on the Ally"])

    Track(C:AddToggle(friendlySection, {
        label = LO["Always Show Crowd Control"],
        desc = LO["Stuns, fears and polymorphs on an ally, listed or not."],
        dbPath = DB .. ".friendlyIncludeCC",
        disabled = IsFriendlyAurasDisabled,
        callback = RefreshNameplates,
    }), IsFriendlyAurasDisabled)

    Track(C:AddToggle(friendlySection, {
        label = LO["Show All Debuffs"],
        desc = LO["Every debuff, not just crowd control. Useful for spotting what to dispel."],
        dbPath = DB .. ".friendlyIncludeAllDebuffs",
        disabled = IsFriendlyAurasDisabled,
        callback = RefreshNameplates,
    }), IsFriendlyAurasDisabled)

    C:AddHeading(friendlySection, LO["Buffs the Ally Carries"])

    Track(C:AddToggle(friendlySection, {
        label = LO["Always Show Defensive Cooldowns"],
        desc = LO["Uses the defensive buff list from the Enemy Buffs section."],
        dbPath = DB .. ".friendlyIncludeDefensive",
        disabled = IsFriendlyAurasDisabled,
        callback = RefreshNameplates,
    }), IsFriendlyAurasDisabled)

    C:AddHeading(friendlySection, LO["Also Show These Spells"])

    C:AddLabel(friendlySection, LO["Listed spells always show, buff or debuff, on top of everything above."])
    C:AddSpellFilterList(friendlySection, {
        dbPath = DB .. ".friendlyAuraFilterList",
        disabled = IsFriendlyAurasDisabled,
        callback = RefreshNameplates,
        rebuildUI = RebuildAuraUI,
        registerDynamic = RegisterDynamicWidget,
    })

    C:AddSpacer(scroll)

    local ccSection = C:AddSection(scroll, LO["Crowd Control"])

    C:AddLabel(ccSection, LO["Stuns, fears, roots and polymorphs are detected automatically. Add anything the game does not flag."])

    C:AddSpellFilterList(ccSection, {
        dbPath = DB .. ".ccExtraList",
        disabled = IsDebuffsDisabled,
        callback = RefreshNameplates,
        rebuildUI = RebuildAuraUI,
        registerDynamic = RegisterDynamicWidget,
    })
end
-- ============================================================================
-- SUB-TAB DISPATCH
-- ============================================================================

local subTabBuilders = {
    general  = BuildGeneralSubTab,
    layout   = BuildLayoutSubTab,
    behavior = BuildBehaviorSubTab,
    health   = BuildHealthSubTab,
    target   = BuildTargetSubTab,
    bars     = BuildBarsSubTab,
    icons    = BuildIconsSubTab,
    quest    = BuildQuestSubTab,
    debuffs  = BuildDebuffsSubTab,
}

-- ============================================================================
-- MAIN TAB BUILDER
-- ============================================================================

local function BuildNameplatesTab(scroll)
    C:AddSubTabs(scroll, subTabs, activeSubTab, function(key)
        activeSubTab = key
        Panel:SelectTab("nameplates")
    end, subTabBuilders)

    if not Panel.indexing then
        local builder = subTabBuilders[activeSubTab]
        if builder then builder(scroll) end
    end
end

Panel:RegisterTab("nameplates", LO["Nameplates"], BuildNameplatesTab, 6.5)
