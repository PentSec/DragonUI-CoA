-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.
-- Portions adapted from RetailUI and DragonflightUI (both MIT); see THIRD_PARTY_NOTICES.

--[[
================================================================================
DragonUI - API Functions
================================================================================
This file contains utility functions used throughout DragonUI.
These are general-purpose functions that can be used by any module.
================================================================================
]]

local addon = select(2, ...)
local L = addon.L

addon.DB_SCHEMA_VERSION = 3
addon.RELEASE_VERSION = GetAddOnMetadata("DragonUI", "Version")

-- ============================================================================
-- TABLE UTILITIES
-- ============================================================================

-- Recursively copy tables
function addon.DeepCopy(source, target)
    target = target or {}
    for key, value in pairs(source) do
        if type(value) == "table" then
            if not target[key] then
                target[key] = {}
            end
            addon.DeepCopy(value, target[key])
        else
            target[key] = value
        end
    end
    return target
end

-- Count elements in a table (works with non-sequential tables)
function addon:tcount(tbl)
    local count = 0
    for _ in pairs(tbl) do count = count + 1 end
    return count
end

-- "^" only anchors as the first char of the whole pattern; inside a capture it matches a literal caret.
local function UpperCamelCase(name)
    return (name:gsub("^%l", string.upper):gsub("_(%l)", string.upper))
end

local function ApplyMissingDefaults(source, target)
    if type(source) ~= "table" or type(target) ~= "table" then
        return
    end

    for key, value in pairs(source) do
        if type(value) == "table" then
            if type(target[key]) ~= "table" then
                target[key] = {}
            end
            ApplyMissingDefaults(value, target[key])
        elseif target[key] == nil then
            target[key] = value
        end
    end
end

-- Register unit-filtered events when supported by the client; otherwise fall
-- back to RegisterEvent for compatibility across 3.3.5a variants.
function addon.RegisterUnitEventSafe(frame, eventName, ...)
    if not frame or not eventName then
        return false
    end

    local hasUnitToken = false
    for i = 1, select("#", ...) do
        if select(i, ...) ~= nil then
            hasUnitToken = true
            break
        end
    end

    if type(frame.RegisterUnitEvent) == "function" and hasUnitToken then
        return frame:RegisterUnitEvent(eventName, ...)
    end

    frame:RegisterEvent(eventName)
    return true
end

-- ============================================================================
-- FRAME CREATION AND MANAGEMENT
-- ============================================================================

-- Frames registry for editor mode
addon.frames = addon.frames or {}

-- Editor mode texture base path
local EDITMODE_TEXTURE_BASE = 'Interface\\AddOns\\DragonUI\\Textures\\Editmode\\'

-- Nineslice texture coordinates
local NINESLICE_COORDS = {
    highlight = {
        corner = {0.03125, 0.53125, 0.285156, 0.347656},
        topEdge = {0, 0.5, 0.0742188, 0.136719},
        bottomEdge = {0, 0.5, 0.00390625, 0.0664062},
        leftEdge = {0.0078125, 0.132812, 0, 1},
        rightEdge = {0.148438, 0.273438, 0, 1}
    },
    selected = {
        corner = {0.03125, 0.53125, 0.355469, 0.417969},
        topEdge = {0, 0.5, 0.214844, 0.277344},
        bottomEdge = {0, 0.5, 0.144531, 0.207031},
        leftEdge = {0.289062, 0.414062, 0, 1},
        rightEdge = {0.429688, 0.554688, 0, 1}
    }
}

-- Add nineslice border to a frame
local function AddNineslice(frame)
    frame.NineSlice = {}
    local slice = frame.NineSlice

    -- Top left corner (no rotation needed)
    slice.TopLeftCorner = frame:CreateTexture(nil, 'OVERLAY')
    slice.TopLeftCorner:SetSize(16, 16)
    slice.TopLeftCorner:SetPoint('TOPLEFT', -8, 8)

    -- Top right corner (will be rotated via SetTexCoord)
    slice.TopRightCorner = frame:CreateTexture(nil, 'OVERLAY')
    slice.TopRightCorner:SetSize(16, 16)
    slice.TopRightCorner:SetPoint('TOPRIGHT', 8, 8)

    -- Bottom left corner (will be rotated via SetTexCoord)
    slice.BottomLeftCorner = frame:CreateTexture(nil, 'OVERLAY')
    slice.BottomLeftCorner:SetSize(16, 16)
    slice.BottomLeftCorner:SetPoint('BOTTOMLEFT', -8, -8)

    -- Bottom right corner (will be rotated via SetTexCoord)
    slice.BottomRightCorner = frame:CreateTexture(nil, 'OVERLAY')
    slice.BottomRightCorner:SetSize(16, 16)
    slice.BottomRightCorner:SetPoint('BOTTOMRIGHT', 8, -8)

    -- Top edge (connects corners)
    slice.TopEdge = frame:CreateTexture(nil, 'OVERLAY')
    slice.TopEdge:SetPoint('TOPLEFT', slice.TopLeftCorner, 'TOPRIGHT')
    slice.TopEdge:SetPoint('BOTTOMRIGHT', slice.TopRightCorner, 'BOTTOMLEFT')

    -- Bottom edge
    slice.BottomEdge = frame:CreateTexture(nil, 'OVERLAY')
    slice.BottomEdge:SetPoint('TOPLEFT', slice.BottomLeftCorner, 'TOPRIGHT')
    slice.BottomEdge:SetPoint('BOTTOMRIGHT', slice.BottomRightCorner, 'BOTTOMLEFT')

    -- Left edge
    slice.LeftEdge = frame:CreateTexture(nil, 'OVERLAY')
    slice.LeftEdge:SetPoint('TOPLEFT', slice.TopLeftCorner, 'BOTTOMLEFT')
    slice.LeftEdge:SetPoint('BOTTOMRIGHT', slice.BottomLeftCorner, 'TOPRIGHT')

    -- Right edge
    slice.RightEdge = frame:CreateTexture(nil, 'OVERLAY')
    slice.RightEdge:SetPoint('TOPLEFT', slice.TopRightCorner, 'BOTTOMLEFT')
    slice.RightEdge:SetPoint('BOTTOMRIGHT', slice.BottomRightCorner, 'TOPRIGHT')

    -- Center (background)
    slice.Center = frame:CreateTexture(nil, 'BACKGROUND')
    slice.Center:SetPoint('TOPLEFT', 0, 0)
    slice.Center:SetPoint('BOTTOMRIGHT', 0, 0)
end

-- Helper function to apply rotated tex coords using 8-value SetTexCoord
-- SetTexCoord(ULx, ULy, LLx, LLy, URx, URy, LRx, LRy)
local function SetTexCoordRotated(texture, coords, rotation)
    local l, r, t, b = coords[1], coords[2], coords[3], coords[4]

    if rotation == 0 then
        -- Normal (0°): TopLeft corner
        texture:SetTexCoord(l, t, l, b, r, t, r, b)
    elseif rotation == 90 then
        -- 90° CW: BottomLeft corner
        texture:SetTexCoord(l, b, r, b, l, t, r, t)
    elseif rotation == 180 then
        -- 180°: BottomRight corner
        texture:SetTexCoord(r, b, r, t, l, b, l, t)
    elseif rotation == 270 then
        -- 270° CW (-90°): TopRight corner
        texture:SetTexCoord(r, t, l, t, r, b, l, b)
    end
end

-- Apply highlight or selected state to nineslice
local function SetNinesliceState(frame, selected)
    local slice = frame.NineSlice
    if not slice then return end

    local coords = selected and NINESLICE_COORDS.selected or NINESLICE_COORDS.highlight

    -- Corners use same texture with different coords and rotations
    local cornerTexture = EDITMODE_TEXTURE_BASE .. 'EditModeUI'

    -- TopLeft (0° - normal)
    slice.TopLeftCorner:SetTexture(cornerTexture)
    SetTexCoordRotated(slice.TopLeftCorner, coords.corner, 0)

    -- TopRight (90° CW)
    slice.TopRightCorner:SetTexture(cornerTexture)
    SetTexCoordRotated(slice.TopRightCorner, coords.corner, 90)

    -- BottomLeft (270° CW / -90°)
    slice.BottomLeftCorner:SetTexture(cornerTexture)
    SetTexCoordRotated(slice.BottomLeftCorner, coords.corner, 270)

    -- BottomRight (180°)
    slice.BottomRightCorner:SetTexture(cornerTexture)
    SetTexCoordRotated(slice.BottomRightCorner, coords.corner, 180)

    -- Edges
    slice.TopEdge:SetTexture(cornerTexture)
    slice.TopEdge:SetTexCoord(unpack(coords.topEdge))
    slice.BottomEdge:SetTexture(cornerTexture)
    slice.BottomEdge:SetTexCoord(unpack(coords.bottomEdge))

    local verticalTexture = EDITMODE_TEXTURE_BASE .. 'EditModeUIVertical'
    slice.LeftEdge:SetTexture(verticalTexture)
    slice.LeftEdge:SetTexCoord(unpack(coords.leftEdge))
    slice.RightEdge:SetTexture(verticalTexture)
    slice.RightEdge:SetTexCoord(unpack(coords.rightEdge))

    -- Center background
    local centerTexture = selected and 'EditModeUISelectedBackground' or 'EditModeUIHighlightBackground'
    slice.Center:SetTexture(EDITMODE_TEXTURE_BASE .. centerTexture)
    slice.Center:SetTexCoord(0, 1, 0, 1)
end

-- Show nineslice overlay
local function ShowNineslice(frame)
    local slice = frame.NineSlice
    if not slice then return end

    for _, part in pairs(slice) do
        part:Show()
    end
end

-- Hide nineslice overlay
local function HideNineslice(frame)
    local slice = frame.NineSlice
    if not slice then return end

    for _, part in pairs(slice) do
        part:Hide()
    end
end

-- Create a UI frame with editor mode support
function addon.CreateUIFrame(width, height, frameName)
    local frame = CreateFrame("Frame", 'DragonUI_' .. frameName, UIParent)
    frame:SetSize(width, height)

    -- Local guard: only behave as an editable/movable frame while editor mode is active.
    -- Outside editor mode, all CreateUIFrame widgets must be click-through.
    local function EditorActive()
        return addon.EditorMode and addon.EditorMode.IsActive and addon.EditorMode:IsActive()
    end

    frame:RegisterForDrag("LeftButton")
    frame:EnableMouse(false)
    frame:SetMovable(false)

     frame:SetScript("OnDragStart", function(self, button)
         if not EditorActive() then return end
         self.DragonUI_LayoutOffset = nil
         self:StartMoving()
        -- Ensure this frame is the selected one
        if addon.selectedEditorFrame ~= self then
            addon.SelectEditorFrame(self)
        end
        -- While dragging: remove green tint, show default drag nineslice
        addon.ClearSelectionTint(self)
    end)

    frame:SetScript("OnDragStop", function(self)
        if not EditorActive() then return end
        self:StopMovingOrSizing()

        -- AUTO-SAVE: Find this frame in EditableFrames and save position automatically
        for name, frameData in pairs(addon.EditableFrames) do
            if frameData.frame == self then
                -- Save position automatically
                if frameData.configPath and #frameData.configPath == 2 then
                    addon.SaveUIFramePosition(frameData.frame, frameData.configPath[1], frameData.configPath[2])
                elseif frameData.configPath then
                    addon.SaveUIFramePosition(frameData.frame, frameData.configPath[1])
                end
                break
            end
        end
        -- Re-apply green tint now that drag is done (frame stays selected)
        addon.ApplySelectionTint(self)
    end)

    -- Click without drag also selects the frame — only meaningful inside editor mode.
    frame:SetScript("OnMouseDown", function(self, button)
        if not EditorActive() then return end
        if button == "LeftButton" then
            addon.SelectEditorFrame(self)
        end
    end)

    frame:SetFrameLevel(100)
    frame:SetFrameStrata('FULLSCREEN')

    -- Create nineslice overlay (DragonflightUI style)
    AddNineslice(frame)
    SetNinesliceState(frame, false) -- Default to highlight state
    HideNineslice(frame) -- Start hidden

    -- Legacy editorTexture reference (for backwards compatibility)
    frame.editorTexture = frame.NineSlice.Center

    -- Text label for editor mode (auto-translate via locale)
    do
        local L = addon.L
        local fontString = frame:CreateFontString(nil, "OVERLAY", 'GameFontNormal')
        fontString:SetPoint("CENTER", frame, "CENTER", 0, 0)
        local ok, translated = pcall(function() return L and L[frameName] end)
        fontString:SetText((ok and translated) or frameName)
        fontString:Hide()
        frame.editorText = fontString
    end

    return frame
end

-- Export nineslice functions for modules with custom behavior
addon.AddNineslice = AddNineslice
addon.SetNinesliceState = SetNinesliceState
addon.ShowNineslice = ShowNineslice
addon.HideNineslice = HideNineslice

-- Grows the editor box (outline + click area) about the point the real frame hangs from; the widget itself stays put.
-- frame.DragonUI_BoxInsets { left, right, top, bottom } first fits the outline to a smaller (or larger) widget.
function addon.SetEditorBoxScale(frame, scale, pivot)
    local slice = frame and frame.NineSlice
    if not slice or (InCombatLockdown() and frame:IsProtected()) then return end
    scale, pivot = scale or 1, pivot or "CENTER"
    local w, h = frame:GetWidth(), frame:GetHeight()
    local fromLeft = pivot:find("LEFT") and 0 or (pivot:find("RIGHT") and 1 or 0.5)
    local fromTop = pivot:find("TOP") and 0 or (pivot:find("BOTTOM") and 1 or 0.5)
    local insets = frame.DragonUI_BoxInsets or { 0, 0, 0, 0 }
    local px, py = w * fromLeft, h * fromTop
    -- How far each outline edge reaches past the box: the inset rect scaled about the pivot.
    local left = -(px + (insets[1] - px) * scale)
    local right = px + (w - insets[2] - px) * scale - w
    local top = -(py + (insets[3] - py) * scale)
    local bottom = py + (h - insets[4] - py) * scale - h
    local shift = (frame.DragonUI_BoxShiftY or 0) * scale
    slice.TopLeftCorner:SetPoint("TOPLEFT", -8 - left, 8 + top + shift)
    slice.TopRightCorner:SetPoint("TOPRIGHT", 8 + right, 8 + top + shift)
    slice.BottomLeftCorner:SetPoint("BOTTOMLEFT", -8 - left, -8 - bottom + shift)
    slice.BottomRightCorner:SetPoint("BOTTOMRIGHT", 8 + right, -8 - bottom + shift)
    slice.Center:SetPoint("TOPLEFT", -left, top + shift)
    slice.Center:SetPoint("BOTTOMRIGHT", right, -bottom + shift)
    frame:SetHitRectInsets(-left, -right, -(top + shift), -(bottom - shift))
end

-- ============================================================================
-- FRAME VISIBILITY FUNCTIONS (Editor Mode Support)
-- ============================================================================

-- Show a UI frame (disable editor mode for this frame)
function addon.ShowUIFrame(frame)
    frame:SetMovable(false)
    frame:EnableMouse(false)

    -- Hide nineslice overlay (new system)
    if frame.NineSlice then
        HideNineslice(frame)
    elseif frame.editorTexture then
        -- Legacy fallback for frames not using CreateUIFrame
        frame.editorTexture:Hide()
    end

    if frame.editorText then
        frame.editorText:Hide()
    end

    if addon.frames[frame] then
        for _, target in pairs(addon.frames[frame]) do
            target:SetAlpha(1)
        end
        addon.frames[frame] = nil
    end
end

-- Hide a UI frame (enable editor mode for this frame)
function addon.HideUIFrame(frame, exclude)
    frame:SetMovable(true)
    frame:EnableMouse(true)

    -- Show nineslice overlay (new system)
    if frame.NineSlice then
        SetNinesliceState(frame, false) -- Highlight state
        ShowNineslice(frame)
    elseif frame.editorTexture then
        -- Legacy fallback for frames not using CreateUIFrame
        frame.editorTexture:Show()
    end

    if frame.editorText then
        frame.editorText:Show()
    end

    addon.frames[frame] = {}
    exclude = exclude or {}

    for _, target in pairs(exclude) do
        target:SetAlpha(0)
        table.insert(addon.frames[frame], target)
    end
end

-- ============================================================================
-- FADED SHOW / HIDE
-- ============================================================================

local FADE_IN_TIME, FADE_OUT_TIME = 0.25, 0.5

local function SetFadeValue(fader, value)
    fader.value = value
    fader.apply(value)
end

local function FaderOnUpdate(fader, elapsed)
    local frame = fader.frame
    if not frame:IsShown() then
        fader.value = 0
        fader:Hide()
        return
    end
    local target = fader.target
    local value
    if target == 1 then
        value = math.min(1, fader.value + elapsed / FADE_IN_TIME)
    else
        value = math.max(0, fader.value - elapsed / FADE_OUT_TIME)
    end
    SetFadeValue(fader, value)
    if value == target then
        fader:Hide()
        if target == 0 then frame:Hide() end
    end
end

-- Shows or hides frame, fading when animate; apply(value) folds the 0-1 fade into the frame's own alpha.
function addon.SetShownFaded(frame, shown, animate, apply)
    local fader = frame.DragonUI_Fader
    if not fader then
        fader = CreateFrame("Frame")
        fader:Hide()
        fader:SetScript("OnUpdate", FaderOnUpdate)
        fader.frame, fader.value = frame, frame:IsShown() and 1 or 0
        frame.DragonUI_Fader = fader
    end
    fader.apply, fader.target = apply, shown and 1 or 0

    if not animate then
        fader:Hide()
        SetFadeValue(fader, fader.target)
        if shown then frame:Show() else frame:Hide() end
        return
    end
    if not frame:IsShown() then
        if not shown then return end
        SetFadeValue(fader, 0)
        frame:Show()
    end
    if fader.value ~= fader.target then fader:Show() else fader:Hide() end
end

-- ============================================================================
-- POSITION SAVE/LOAD FUNCTIONS
-- ============================================================================

-- Save frame position to database
function addon.SaveUIFramePosition(frame, configPath1, configPath2)
    if not frame then
        return
    end

    local anchor, _, _, posX, posY = frame:GetPoint(1)

    -- A module's automatic shift from the default spot (e.g. the pet bar stacked over stances) is not a move.
    local layoutOffset = frame.DragonUI_LayoutOffset
    if layoutOffset and posX and posY then
        posX = posX - layoutOffset[1]
        posY = posY - layoutOffset[2]
    end

    -- Strip dual-bar offset from positions of affected widgets so the
    -- database always stores the *base* position.  Without this, closing
    -- editor mode while both XP+Rep bars are visible would bake the
    -- offset into the saved Y, breaking IsWidgetAtDefaultPosition.
    -- IMPORTANT: Only strip when the widget is still at its default spot
    -- (i.e.the offset was actually added).  For user-moved frames the
    -- offset was never applied, so subtracting it would cause drift.
    if configPath1 == "widgets" and configPath2
       and addon._dualBarOffsetWidgets and addon._dualBarOffsetWidgets[configPath2]
       and addon.GetDualBarVerticalOffset and addon.IsWidgetAtDefaultPosition
       and addon.IsWidgetAtDefaultPosition(configPath2) then
        local offset = addon.GetDualBarVerticalOffset()
        if offset ~= 0 and posY then
            posY = posY - offset
        end
    end

    -- Handle nested paths (widgets.player)
    if configPath2 then
        -- Case: SaveUIFramePosition(frame, "widgets", "player")
        if not addon.db.profile[configPath1] then
            addon.db.profile[configPath1] = {}
        end

        if not addon.db.profile[configPath1][configPath2] then
            addon.db.profile[configPath1][configPath2] = {}
        end

        addon.db.profile[configPath1][configPath2].anchor = anchor or "CENTER"
        addon.db.profile[configPath1][configPath2].posX = posX or 0
        addon.db.profile[configPath1][configPath2].posY = posY or 0
    else
        -- Case: SaveUIFramePosition(frame, "minimap") - backwards compatibility
        local widgetName = configPath1

        if not addon.db.profile.widgets then
            addon.db.profile.widgets = {}
        end

        if not addon.db.profile.widgets[widgetName] then
            addon.db.profile.widgets[widgetName] = {}
        end

        addon.db.profile.widgets[widgetName].anchor = anchor or "CENTER"
        addon.db.profile.widgets[widgetName].posX = posX or 0
        addon.db.profile.widgets[widgetName].posY = posY or 0
    end
end

-- Raw coords on purpose: both callers anchor scale-1 children of UIParent.
function addon.GetQuadrantAnchor(frame)
    if not frame then
        return nil
    end

    local centerX, centerY = frame:GetCenter()
    local screenWidth, screenHeight = UIParent:GetRight(), UIParent:GetTop()
    local screenMidX = UIParent:GetCenter()
    if not (centerX and centerY and screenWidth and screenHeight and screenMidX) then
        return nil
    end

    local vertical, offsetY = "BOTTOM", frame:GetBottom()
    if centerY >= screenHeight / 2 then
        vertical, offsetY = "TOP", frame:GetTop() - screenHeight
    end

    local third = screenWidth / 3
    local horizontal, offsetX = "", centerX - screenMidX
    if centerX >= third * 2 then
        horizontal, offsetX = "RIGHT", frame:GetRight() - screenWidth
    elseif centerX <= third then
        horizontal, offsetX = "LEFT", frame:GetLeft()
    end

    return vertical .. horizontal, math.floor(offsetX + 0.5), math.floor(offsetY + 0.5)
end

-- Apply a saved widgets.* position to a frame (position presets / reload helpers)
function addon.ApplyWidgetPositionFromDB(widgetKey, frame)
    if not widgetKey or not frame or not addon.db or not addon.db.profile or not addon.db.profile.widgets then
        return
    end

    local cfg = addon.db.profile.widgets[widgetKey]
    if not cfg or (cfg.posX == nil and cfg.posY == nil) then
        return
    end

    local anchor = cfg.anchor or "CENTER"
    local posX = cfg.posX or 0
    local posY = cfg.posY or 0

    if addon.ResolveWidgetDefaultY then
        posY = addon.ResolveWidgetDefaultY(widgetKey, posY)
    end

    if addon._dualBarOffsetWidgets and addon._dualBarOffsetWidgets[widgetKey]
       and addon.GetDualBarVerticalOffset and addon.IsWidgetAtDefaultPosition
       and addon.IsWidgetAtDefaultPosition(widgetKey) then
        posY = posY + addon.GetDualBarVerticalOffset()
    end

    if InCombatLockdown() then
        return
    end

    frame:ClearAllPoints()
    frame:SetPoint(anchor, UIParent, anchor, posX, posY)
end

local function PointCoords(frame, point)
    local left, right, top, bottom = frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom()
    if not (left and right and top and bottom) then return nil end
    local x = point:find("LEFT") and left or (point:find("RIGHT") and right or (left + right) / 2)
    local y = point:find("TOP") and top or (point:find("BOTTOM") and bottom or (top + bottom) / 2)
    return x, y
end

-- SetPoint(point, UIParent, relativePoint, x, y) offsets that keep `frame` in place, read off its edges (GetPoint skews).
function addon.GetAnchorOffset(frame, point, relativePoint)
    local fx, fy = PointCoords(frame, point)
    local ux, uy = PointCoords(UIParent, relativePoint or point)
    if not (fx and ux) then return nil end
    local ratio = UIParent:GetEffectiveScale() / frame:GetEffectiveScale()
    return fx - ux * ratio, fy - uy * ratio
end

-- Apply frame position from database
function addon.ApplyUIFramePosition(frame, configPath)
    if not frame or not configPath then
        return
    end

    local section, key = configPath:match("([^%.]+)%.([^%.]+)")
    if not section or not key then
        return
    end

    local config = addon.db.profile[section] and addon.db.profile[section][key]
    if not config or not config.override then
        return
    end

    frame:ClearAllPoints()
    frame:SetPoint(config.anchor or "CENTER", UIParent, config.anchorParent or "CENTER", config.x or 0, config.y or 0)
end

-- ============================================================================
-- SETTINGS VALIDATION
-- ============================================================================

-- Check if settings exist and load defaults if needed
function addon.CheckSettingsExists(moduleTable, configPaths)
    local needsDefaults = false

    for _, configPath in pairs(configPaths) do
        local section, key = configPath:match("([^%.]+)%.([^%.]+)")
        if section and key then
            if not addon.db.profile[section] or not addon.db.profile[section][key] then
                needsDefaults = true
                break
            end
        end
    end

    if needsDefaults and moduleTable.LoadDefaultSettings then
        moduleTable:LoadDefaultSettings()
    end

    if moduleTable.UpdateWidgets then
        moduleTable:UpdateWidgets()
    end
end

-- ============================================================================
-- EDITABLE FRAMES REGISTRY
-- Centralized system for managing moveable UI elements
-- ============================================================================

addon.EditableFrames = addon.EditableFrames or {}

-- Register a frame as editable
function addon:RegisterEditableFrame(frameInfo)
    local frameData = {
        name = frameInfo.name,                    -- "player", "minimap", "target"
        frame = frameInfo.frame,                  -- The auxiliary frame
        blizzardFrame = frameInfo.blizzardFrame,  -- Real Blizzard frame (optional)
        configPath = frameInfo.configPath,        -- {"widgets", "player"} or {"unitframe", "target"}
        onShow = frameInfo.onShow,                -- Optional function when showing editor
        onHide = frameInfo.onHide,                -- Optional function when hiding editor
        onNudge = frameInfo.onNudge,               -- Optional function after arrow-key/typed coordinate edits
        showTest = frameInfo.showTest,            -- Function to show with fake data
        hideTest = frameInfo.hideTest,            -- Function to hide fake frame
        hasTarget = frameInfo.hasTarget,          -- Function to check if should be visible
        editorVisible = frameInfo.editorVisible,  -- Function to check if frame should appear in editor mode
        resetPosition = frameInfo.resetPosition,  -- Optional: the module's own way back to its default spot
        applyPosition = frameInfo.applyPosition,  -- Optional: re-places the frame from the DB with the module's own shifts
        isDefaultPosition = frameInfo.isDefaultPosition, -- Optional: true when resetPosition would change nothing
        module = frameInfo.module                 -- Reference to the module
    }

    self.EditableFrames[frameInfo.name] = frameData
end

-- MODULE REGISTRY SYSTEM
-- ============================================================================
-- Central registry for all DragonUI modules.
-- Provides: auto-discovery, status reporting, batch enable/disable operations.
-- Modules self-register during load, making the system extensible.

addon.ModuleRegistry = addon.ModuleRegistry or {
    -- Registered modules: { [name] = { module, displayName, description, order } }
    modules = {},
    -- Load order for enable/disable operations
    loadOrder = {},
    -- Counter for auto-ordering
    orderCounter = 0,
    legacyRefreshTargets = {},
    -- Hooks for third-party compatibility: { [targetName] = { { phase = "pre"|"post", cb = function }, ... } }
    hooks = {},
}

local MR = addon.ModuleRegistry

local MODULE_LIFECYCLE_OVERRIDES = {
    boss = {
        refresh = "RefreshBossFrames",
        loadOnce = true,
        isEnabled = function()
            return addon.UF and addon.UF.IsEnabled and addon.UF.IsEnabled("boss")
        end,
    },
    buffs = {
        refresh = "RefreshBuffFrame",
        loadOnce = true,
        isEnabled = function()
            return addon.db and addon.db.profile and addon.db.profile.buffs and addon.db.profile.buffs.enabled
        end,
        enabledPaths = { "buffs.enabled", "modules.buffs.enabled" },
    },
    buttons = { refresh = "RefreshButtons", loadOnce = true },
    chatmods = {
        apply = "ApplyChatModsSystem",
        restore = "RestoreChatModsSystem",
        loadOnce = true,
    },
    bagster = {
        apply = "ApplyBagsterSystem",
        restore = "RestoreBagsterSystem",
        loadOnce = true,
    },
    cooldowns = { refresh = "RefreshCooldowns", restore = "RefreshCooldowns", loadOnce = true },
    compactframes = { loadOnce = true },
    darkmode = { apply = "ApplyDarkMode", restore = "RestoreDarkMode", loadOnce = true },
    itemquality = {
        apply = "ApplyItemQualitySystem",
        restore = "RestoreItemQualitySystem",
        loadOnce = true,
    },
    mainbars = { refresh = "RefreshMainbarsSystem", loadOnce = true },
    micromenu = { refresh = "RefreshMicromenuSystem", loadOnce = true },
    minimap = { refresh = "RefreshMinimapSystem", loadOnce = true },
    nameplates = {
        apply = "ApplyNameplatesSystem",
        restore = "RestoreNameplatesSystem",
        refresh = "RefreshNameplates",
        loadOnce = true,
    },
    multicast = { refresh = "RefreshMulticast", loadOnce = true },
    noop = { refresh = "RefreshNoopSystem", loadOnce = true },
    petbar = { refresh = "RefreshPetbarSystem", loadOnce = true },
    player = {
        refresh = function()
            if addon.PlayerFrame and addon.PlayerFrame.RefreshPlayerFrame then
                addon.PlayerFrame.RefreshPlayerFrame()
            end
        end,
        loadOnce = true,
        isEnabled = function()
            return addon.UF and addon.UF.IsEnabled and addon.UF.IsEnabled("player")
        end,
    },
    questtracker = { refresh = "RefreshQuestTracker", restore = "RefreshQuestTracker", loadOnce = true },
    stance = { refresh = "RefreshStanceSystem", loadOnce = true },
    tooltip = {
        apply = "ApplyTooltipSystem",
        restore = "RestoreTooltipSystem",
        loadOnce = true,
    },
    unitframe_layers = { refresh = "RefreshUnitFrameLayers", restore = "RefreshUnitFrameLayers", loadOnce = true },
    vehicle = { refresh = "RefreshVehicleSystem", loadOnce = true },
}

-- "both" = applies and fully undoes mid-session, "enable" = only turning on is live; unlisted = live unless loadOnce.
local MODULE_LIVE_TOGGLE = {
    cooldowns = "both",
    darkmode = "both",
    itemownership = "both",
    itemquality = "both",
    loot_skin = "both",
    spellbook = "both",
    tooltip = "both",
    unitframe_layers = "both",
    -- Blizzard's tracker gets its item buttons back only on its next update.
    questtracker = "enable",
    keybinding = "none",
    bagsort = "none",
}

local DEFAULT_LEGACY_REFRESH_TARGETS = {
    { name = "targetframe", funcName = "RefreshTargetFrame", order = 900 },
    { name = "focusframe", funcName = "RefreshFocusFrame", order = 910 },
    { name = "partyframes", funcName = "RefreshPartyFrames", order = 920 },
    { name = "totframe", funcName = "RefreshToTFrame", order = 930 },
    { name = "tofframe", funcName = "RefreshToFFrame", order = 940 },
    { name = "petframe", funcName = "RefreshPetFrame", order = 950 },
}

local function ResolveRegistryFunction(info, phase)
    local mod = info and info.module
    local override = info and info.lifecycle or nil
    local prefix = info and info.lifecyclePrefix or nil
    local candidates = {}

    if override and override[phase] then
        table.insert(candidates, override[phase])
    end

    if phase == "refresh" then
        table.insert(candidates, "Refresh" .. prefix .. "System")
        table.insert(candidates, "Refresh" .. prefix)
        table.insert(candidates, "Refresh")
        table.insert(candidates, "OnProfileChanged")
        table.insert(candidates, "Enable")
    elseif phase == "apply" then
        table.insert(candidates, "Apply" .. prefix .. "System")
        table.insert(candidates, "Apply" .. prefix)
        table.insert(candidates, "Apply")
        table.insert(candidates, "Enable")
        table.insert(candidates, "OnEnable")
    elseif phase == "restore" then
        table.insert(candidates, "Restore" .. prefix .. "System")
        table.insert(candidates, "Restore" .. prefix)
        table.insert(candidates, "Restore")
        table.insert(candidates, "Disable")
        table.insert(candidates, "OnDisable")
    end

    for _, candidate in ipairs(candidates) do
        if type(candidate) == "function" then
            return candidate, false
        end
        if type(candidate) == "string" then
            if mod and type(mod[candidate]) == "function" then
                return mod[candidate], true
            end
            if type(addon[candidate]) == "function" then
                return addon[candidate], false
            end
        end
    end

    return nil, false
end

-- Register a module with the registry
-- @param name: Unique module identifier (matches database key in profile.modules)
-- @param moduleTable: The module state table (e.g., StanceModule)
-- @param displayName: Human-readable name for UI display
-- @param description: Description for tooltips (optional)
-- @param order: Load order number (optional, auto-assigned if nil)
function MR:Register(name, moduleTable, displayName, description, orderOrOptions)
    local L = addon.L

    if not name or not moduleTable then
        addon:Error(L["ModuleRegistry:Register requires name and moduleTable"])
        return false
    end

    -- Prevent duplicate registration
    if self.modules[name] then
        addon:Debug(L["ModuleRegistry: Module already registered -"], name)
        return false
    end

    -- Auto-assign order if not provided
    local options = nil
    if type(orderOrOptions) == "table" then
        options = orderOrOptions
    elseif type(orderOrOptions) == "number" then
        options = { order = orderOrOptions }
    else
        options = {}
    end

    self.orderCounter = self.orderCounter + 1
    local assignedOrder = options.order or self.orderCounter
    local lifecycle = options.lifecycle or MODULE_LIFECYCLE_OVERRIDES[name] or {}
    local loadOnce = options.loadOnce or lifecycle.loadOnce or false
    local liveMode = MODULE_LIVE_TOGGLE[name]
    local live = liveMode == "both" or (liveMode == nil and not loadOnce)

    -- Store module info
    self.modules[name] = {
        module = moduleTable,
        displayName = displayName or name,
        description = description or "",
        order = assignedOrder,
        lifecyclePrefix = options.lifecyclePrefix or lifecycle.lifecyclePrefix or UpperCamelCase(name),
        lifecycle = lifecycle,
        loadOnce = loadOnce,
        liveEnable = live or liveMode == "enable",
        liveDisable = live,
        isEnabled = options.isEnabled or lifecycle.isEnabled,
        enabledPaths = options.enabledPaths or lifecycle.enabledPaths,
    }

    -- Add to load order
    table.insert(self.loadOrder, name)

    addon:Debug(L["ModuleRegistry: Registered module -"], name, L["order:"], assignedOrder)
    return true
end

-- Register a hook that runs before ("pre") or after ("post") a module's lifecycle
-- @param targetName: Module name to hook into (e.g., "player")
-- @param phase: "pre" (before Apply) or "post" (after Apply)
-- @param callback: function(moduleInfo) — receives the target module's info table
function MR:RegisterHook(targetName, phase, callback)
    if not targetName or not phase or not callback then
        return false
    end
    if phase ~= "pre" and phase ~= "post" then
        return false
    end

    self.hooks[targetName] = self.hooks[targetName] or {}
    table.insert(self.hooks[targetName], {phase = phase, cb = callback})
    return true
end

function MR:RegisterLegacyRefreshTarget(name, funcName, order)
    if not name or not funcName then
        return false
    end

    self.legacyRefreshTargets[name] = {
        funcName = funcName,
        order = order or 1000,
    }

    return true
end

function MR:EnsureLegacyRefreshTargets()
    if next(self.legacyRefreshTargets) then
        return
    end

    for _, target in ipairs(DEFAULT_LEGACY_REFRESH_TARGETS) do
        self:RegisterLegacyRefreshTarget(target.name, target.funcName, target.order)
    end
end

-- Get a registered module by name
-- @param name: Module identifier
-- @return moduleTable or nil
function MR:Get(name)
    local info = self.modules[name]
    return info and info.module or nil
end

-- Get module info (name, description, order)
-- @param name: Module identifier
-- @return table { module, displayName, description, order } or nil
function MR:GetInfo(name)
    return self.modules[name]
end

-- Get all registered module names
-- @return table (array) of module names in load order
function MR:GetAll()
    return self.loadOrder
end

-- Get count of registered modules
-- @return number
function MR:Count()
    return #self.loadOrder
end

-- Check if a module is enabled in database
-- @param name: Module identifier
-- @return boolean
function MR:IsEnabled(name)
    local info = self.modules[name]
    if info and info.isEnabled then
        return info.isEnabled()
    end

    if not addon.db or not addon.db.profile or not addon.db.profile.modules then
        return false
    end

    local cfg = addon.db.profile.modules[name]
    return cfg and cfg.enabled
end

function MR:IsLoadOnce(name)
    local info = self.modules[name]
    return info and info.loadOnce or false
end

function addon:IsModuleLoadOnce(name)
    return MR:IsLoadOnce(name)
end

-- Live only when the module is allowed to and the registry finds the function that does it.
function MR:CanToggleLive(name, enable)
    local info = self.modules[name]
    if not info then return false end
    if enable then
        return info.liveEnable
            and (ResolveRegistryFunction(info, "refresh") or ResolveRegistryFunction(info, "apply")) and true or false
    end
    return info.liveDisable and ResolveRegistryFunction(info, "restore") and true or false
end

function MR:GetEnabledPaths(name)
    local info = self.modules[name]
    return info and info.enabledPaths or { "modules." .. name .. ".enabled" }
end

local function WriteProfilePath(path, value)
    local node = addon.db and addon.db.profile
    if not node then return end
    local keys = { strsplit(".", path) }
    for i = 1, #keys - 1 do
        if type(node[keys[i]]) ~= "table" then node[keys[i]] = {} end
        node = node[keys[i]]
    end
    node[keys[#keys]] = value
end

-- Module toggles: a live-capable direction runs now (true) or after combat (false); any other is staged.
function addon:SetModuleEnabled(name, enable)
    enable = enable and true or false
    local running = MR:IsEnabled(name) and true or false
    if enable == running or not MR:CanToggleLive(name, enable) then
        -- Toggling back during combat must not leave the first click queued.
        self.CombatQueue:Remove(name .. "_toggle")
        self.Reload.StageModule(name, enable)
        return false
    end
    -- Flag and refresh land together, so hooks gated on the flag never see it ahead of the module.
    return self:SafeExecute(name, "toggle", function()
        for _, path in ipairs(MR:GetEnabledPaths(name)) do WriteProfilePath(path, enable) end
        MR:Refresh(name)
    end)
end

addon._pendingReloadModules = addon._pendingReloadModules or {}

function addon:ShouldDeferModuleDisable(name, moduleState)
    local L = addon.L

    if not self:IsModuleLoadOnce(name) then
        return false
    end

    if not moduleState or not (moduleState.initialized or moduleState.applied) then
        return false
    end

    if not self._pendingReloadModules[name] then
        self._pendingReloadModules[name] = true
    end

    return true
end

function MR:Refresh(name)
    local L = addon.L

    local info = self.modules[name]
    if not info then
        return false
    end

    -- Run pre-hooks before module lifecycle
    local hooks = self.hooks[name]
    if hooks then
        for _, hook in ipairs(hooks) do
            if hook.phase == "pre" then
                local ok, err = pcall(hook.cb, info)
                if not ok then
                    addon:Error((L and L["ModuleRegistry: pre-hook failed for"]) or "ModuleRegistry: pre-hook failed for", name, "-", err)
                end
            end
        end
    end

    local enabled = self:IsEnabled(name)
    local fn, useModuleSelf = ResolveRegistryFunction(info, enabled and "refresh" or "restore")

    -- Modules that install secure hooks cannot be cleanly unhooked during a live
    -- WoW session. Treat them as load-once: honor future config on reload, but do
    -- not run unsafe in-session teardown paths.
    if not enabled and not info.liveDisable and info.module and (info.module.initialized or info.module.applied) then
        return true
    end

    if not fn then
        fn, useModuleSelf = ResolveRegistryFunction(info, enabled and "apply" or "restore")
    end

    if not fn then
        return false
    end

    local success, err
    if useModuleSelf then
        success, err = pcall(fn, info.module)
    else
        success, err = pcall(fn, addon)
    end

    if not success then
        addon:Error(L["ModuleRegistry: Refresh failed for"], name, "-", err)
    end

    -- Run post-hooks after module lifecycle
    if hooks then
        for _, hook in ipairs(hooks) do
            if hook.phase == "post" then
                local ok, err = pcall(hook.cb, info)
                if not ok then
                    addon:Error((L and L["ModuleRegistry: post-hook failed for"]) or "ModuleRegistry: post-hook failed for", name, "-", err)
                end
            end
        end
    end

    return success
end

function MR:RefreshAll()
    local failed = {}
    self:EnsureLegacyRefreshTargets()

    for _, name in ipairs(self.loadOrder) do
        if not self:Refresh(name) then
            table.insert(failed, name)
        end
    end

    local legacyTargets = {}
    for name, info in pairs(self.legacyRefreshTargets) do
        table.insert(legacyTargets, { name = name, funcName = info.funcName, order = info.order })
    end
    table.sort(legacyTargets, function(a, b)
        return a.order < b.order
    end)

    for _, target in ipairs(legacyTargets) do
        local fn = addon[target.funcName]
        if type(fn) == "function" then
            local success, err = pcall(fn, addon)
            if not success then
                addon:Error(L["Legacy refresh failed for"], target.name, "-", err)
                table.insert(failed, target.name)
            end
        end
    end

    return failed
end

-- Enable a specific module
-- @param name: Module identifier
-- @return boolean success
function MR:Enable(name)
    local L = addon.L

    local info = self.modules[name]
    if not info then
        addon:Error(L["ModuleRegistry: Unknown module -"], name)
        return false
    end

    -- Update database
    if addon.db and addon.db.profile and addon.db.profile.modules then
        if not addon.db.profile.modules[name] then
            addon.db.profile.modules[name] = {}
        end
        addon.db.profile.modules[name].enabled = true
    end

    self:Refresh(name)

    addon:Debug(L["ModuleRegistry: Enabled -"], name)
    return true
end

-- Disable a specific module
-- @param name: Module identifier
-- @return boolean success
function MR:Disable(name)
    local L = addon.L

    local info = self.modules[name]
    if not info then
        addon:Error(L["ModuleRegistry: Unknown module -"], name)
        return false
    end

    -- Update database
    if addon.db and addon.db.profile and addon.db.profile.modules then
        if not addon.db.profile.modules[name] then
            addon.db.profile.modules[name] = {}
        end
        addon.db.profile.modules[name].enabled = false
    end

    -- hooksecurefunc / HookScript registrations are permanent for the session.
    -- Keep load-once modules active until reload instead of pretending we can fully disable them.
    if not info.liveDisable and info.module and (info.module.initialized or info.module.applied) then
        return true
    end

    self:Refresh(name)

    addon:Debug(L["ModuleRegistry: Disabled -"], name)
    return true
end

-- Enable all registered modules (in load order)
function MR:EnableAll()
    for _, name in ipairs(self.loadOrder) do
        self:Enable(name)
    end
end

-- Disable all registered modules (in reverse load order for proper cleanup)
function MR:DisableAll()
    for i = #self.loadOrder, 1, -1 do
        self:Disable(self.loadOrder[i])
    end
end

-- Print status of all registered modules (for /dragonui status)
function MR:PrintStatus()
    local L = addon.L

    if #self.loadOrder == 0 then
        print("  " .. (L["No modules registered in ModuleRegistry"]))
        return
    end
    print("  |cFF00FF00" .. (L["Registered Modules:"]) .. "|r")
    for _, name in ipairs(self.loadOrder) do
        local info = self.modules[name]
        local enabled = self:IsEnabled(name)
        local status = enabled and ("|cFF00FF00" .. (L["Enabled"]) .. "|r") or ("|cFFFF0000" .. (L["Disabled"]) .. "|r")
        local loaded = info.module and (info.module.initialized or info.module.applied) and ("|cFF00FF00" .. (L["Loaded"]) .. "|r") or "|cFFAAAAAA-|r"

        local mode = info.loadOnce and (" |cFFFFD200(" .. (L["load-once"]) .. ")|r") or ""
        print(string.format("    %s: %s (%s)%s", info.displayName, status, loaded, mode))
    end
end

-- Convenience function for modules to register themselves
-- @param name: Module identifier
-- @param moduleTable: Module state table
-- @param displayName: Display name (optional)
-- @param description: Description (optional)
function addon:RegisterModule(name, moduleTable, displayName, description, options)
    return MR:Register(name, moduleTable, displayName, description, options)
end

-- No external callers: DEFAULT_LEGACY_REFRESH_TARGETS covers the frames that need it. Kept as the
-- supported way to add one without editing this file.
function addon:RegisterLegacyRefreshTarget(name, funcName, order)
    return MR:RegisterLegacyRefreshTarget(name, funcName, order)
end

function addon:RefreshRegisteredSystems()
    return MR:RefreshAll()
end

-- ============================================================================
-- COMBAT QUEUE SYSTEM
-- ============================================================================
-- Central system for deferring operations that cannot run during combat lockdown.
-- Pattern: Check InCombatLockdown() -> if true, queue operation -> execute after combat
-- Reference: common PLAYER_REGEN_ENABLED deferred-execution pattern

addon.CombatQueue = addon.CombatQueue or {
    -- Pending operations table: { [id] = { func, args } }
    pending = {},
    -- Is the event frame registered?
    isRegistered = false,
    -- Event frame for PLAYER_REGEN_ENABLED
    eventFrame = nil,
}

local CQ = addon.CombatQueue

-- Initialize the combat queue event frame
local function InitializeCombatQueueFrame()
    if CQ.eventFrame then return end

    CQ.eventFrame = CreateFrame("Frame", "DragonUI_CombatQueueFrame", UIParent)
    CQ.eventFrame:Hide()
    CQ.eventFrame:SetScript("OnEvent", function(self, event)
        if event == "PLAYER_REGEN_ENABLED" then
            addon.CombatQueue:ProcessQueue()
        end
    end)
end

-- Add an operation to the combat queue
-- @param id: Unique identifier for this operation (prevents duplicates)
-- @param func: Function to call when combat ends
-- @param ...: Arguments to pass to the function
function CQ:Add(id, func, ...)
    local L = addon.L

    if not id or not func then
        addon:Error(L["CombatQueue:Add requires id and func"])
        return false
    end

    -- Initialize frame if needed
    InitializeCombatQueueFrame()

    -- Store the operation with its arguments
    self.pending[id] = { func = func, args = {...} }

    -- Register for PLAYER_REGEN_ENABLED if not already
    if not self.isRegistered then
        self.eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        self.isRegistered = true
        addon:Debug(L["CombatQueue: Registered PLAYER_REGEN_ENABLED"])
    end

    addon:Debug(L["CombatQueue: Queued operation -"], id)
    return true
end

-- Remove an operation from the queue (if no longer needed)
-- @param id: Identifier of the operation to remove
function CQ:Remove(id)
    local L = addon.L

    if self.pending[id] then
        self.pending[id] = nil
        addon:Debug(L["CombatQueue: Removed operation -"], id)
    end

    -- If queue is empty, unregister the event
    if not next(self.pending) and self.isRegistered then
        self.eventFrame:UnregisterEvent("PLAYER_REGEN_ENABLED")
        self.isRegistered = false
    end
end

-- Check if an operation is in the queue
-- @param id: Identifier to check
function CQ:HasPending(id)
    return self.pending[id] ~= nil
end

-- Process all queued operations (called on PLAYER_REGEN_ENABLED)
function CQ:ProcessQueue()
    local L = addon.L

    addon:Debug(L["CombatQueue: Processing"], addon:tcount(self.pending), L["queued operations"])
    -- Process all pending operations
    for id, operation in pairs(self.pending) do
        local success, err = pcall(function()
            operation.func(unpack(operation.args))
        end)

        if not success then
            addon:Error(L["CombatQueue: Failed to execute"], id, "-", err)
        else
            addon:Debug(L["CombatQueue: Executed -"], id)
        end
    end

    -- Clear all pending operations
    self.pending = {}

    -- Unregister the event
    if self.isRegistered then
        self.eventFrame:UnregisterEvent("PLAYER_REGEN_ENABLED")
        self.isRegistered = false
        addon:Debug(L["CombatQueue: Unregistered PLAYER_REGEN_ENABLED"])
    end
end

-- Execute immediately if out of combat, queue if in combat
-- @param id: Unique identifier for this operation
-- @param func: Function to call
-- @param ...: Arguments to pass to the function
-- @return true if executed immediately, false if queued
function CQ:ExecuteOrQueue(id, func, ...)
    local L = addon.L

    if InCombatLockdown() then
        self:Add(id, func, ...)
        return false
    else
        -- Execute immediately
        local args = {...}
        local success, err = pcall(function()
            func(unpack(args))
        end)

        if not success then
            addon:Error(L["CombatQueue: Immediate execution failed -"], id, "-", err)
        end
        return true
    end
end

-- Convenience function for modules to check and queue
-- Returns true if operation can proceed (not in combat)
-- @param moduleId: Module name for the queue ID
-- @param operationName: Name of the operation (combined with moduleId)
-- @param func: Function to call when combat ends
-- @param ...: Arguments
function addon:SafeExecute(moduleId, operationName, func, ...)
    local queueId = moduleId .. "_" .. operationName
    return CQ:ExecuteOrQueue(queueId, func, ...)
end

-- ============================================================================
-- MODULE HELPERS (centralized — replaces per-module boilerplate)
-- ============================================================================

-- No-op function reusable across all modules (avoids multiple definitions)

-- Get module config from addon.db.profile.modules[moduleName]
-- @param moduleName: string key matching database.lua modules table
-- @return table or nil
function addon:GetModuleConfig(moduleName)
    return self.db and self.db.profile and self.db.profile.modules
        and self.db.profile.modules[moduleName]
end

-- Check if a module is enabled in the database
-- @param moduleName: string key matching database.lua modules table
-- @return boolean
function addon:IsModuleEnabled(moduleName)
    local cfg = self:GetModuleConfig(moduleName)
    return cfg and cfg.enabled or false
end

-- ============================================================================
-- DELAYED EXECUTION (unified timer — replaces 3 different implementations)
-- ============================================================================

-- Frame pool for delayed execution (C_Timer replacement for 3.3.5a)
addon._timerPool = addon._timerPool or {}

-- Schedule a callback after a delay (seconds)
-- @param delay: number — seconds to wait
-- @param callback: function — called after delay
function addon:After(delay, callback)
    if type(callback) ~= "function" then
        return
    end

    delay = tonumber(delay) or 0
    if delay < 0 then
        delay = 0
    end

    local f = tremove(self._timerPool) or CreateFrame("Frame")
    f._elapsed = 0
    f._delay = delay
    f._callback = callback
    f:SetScript("OnUpdate", function(self, dt)
        self._elapsed = self._elapsed + dt
        if self._elapsed >= self._delay then
            self:SetScript("OnUpdate", nil)
            tinsert(addon._timerPool, self)
            local cb = self._callback
            self._callback = nil
            cb()
        end
    end)
end

-- ============================================================================
-- TEXTURE WARMUP
-- ============================================================================

-- The client loads a texture on the first frame that draws it; a 1024x1024 TGA stalls that frame ~75 ms.
local warmupProviders = {}

-- provider() returns a texture path, a list of paths or nil; it runs once, at the first PLAYER_ENTERING_WORLD.
function addon:RegisterTextureWarmup(provider)
    if type(provider) == "function" then
        warmupProviders[#warmupProviders + 1] = provider
    end
end

local function RunTextureWarmup()
    local holder, seen = nil, {}
    for _, provider in ipairs(warmupProviders) do
        local ok, files = pcall(provider)
        if not ok then
            addon:Debug("texture warmup:", files)
        else
            if type(files) == "string" then files = { files } end
            if type(files) == "table" then
                for _, file in ipairs(files) do
                    if type(file) == "string" and not seen[file] then
                        seen[file] = true
                        holder = holder or CreateFrame("Frame", nil, UIParent)
                        local texture = holder:CreateTexture(nil, "ARTWORK")
                        texture:SetAllPoints()
                        texture:SetAlpha(0)
                        texture:SetTexture(file)
                    end
                end
            end
        end
    end
    if not holder then return end
    holder:SetFrameStrata("BACKGROUND")
    holder:SetSize(64, 64)
    holder:SetPoint("CENTER")
    -- The first frame after PLAYER_ENTERING_WORLD renders before the world shows; hidden regions keep their textures.
    local frames = 0
    holder:SetScript("OnUpdate", function(self)
        frames = frames + 1
        if frames >= 2 then
            self:SetScript("OnUpdate", nil)
            self:Hide()
        end
    end)
end

local warmupEvents = CreateFrame("Frame")
warmupEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
warmupEvents:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")
    RunTextureWarmup()
end)

-- ============================================================================
-- INSPECT REPLY TRACKING
-- ============================================================================

-- The reply event carries no unit and the client holds one reply at a time, so whose it is lives here.
local inspectedGUID           -- player named by the latest inspect request
local inspectAnswered = false -- whether the server has replied for inspectedGUID
local everAnswered = false
local inspectCallbacks = {}

-- Only used while this server has never answered an inspect, so a silent server still gets numbers.
local SILENT_SERVER_WAIT = 2

local function FireInspectCallbacks()
    local owner = inspectAnswered and inspectedGUID or nil
    for i = 1, #inspectCallbacks do
        inspectCallbacks[i](owner)
    end
end

-- callback(ownerGUID): ownerGUID is nil while no reply is loaded
function addon:RegisterInspectDataCallback(callback)
    if type(callback) == "function" then
        tinsert(inspectCallbacks, callback)
    end
end

-- Until true, inventory queries on the unit return its visible gear: the transmog skin on such servers.
function addon:IsInspectDataFor(unit)
    return inspectAnswered and unit ~= nil and UnitGUID(unit) == inspectedGUID
end

hooksecurefunc("NotifyInspect", function(unit)
    local guid = unit and UnitGUID(unit)

    -- Re-requesting the same player keeps their reply: it is still their real gear.
    if guid ~= inspectedGUID then
        inspectedGUID = guid
        if inspectAnswered then
            inspectAnswered = false
            FireInspectCallbacks()
        end
    end

    if guid and not everAnswered then
        addon:After(SILENT_SERVER_WAIT, function()
            if not everAnswered and not inspectAnswered and inspectedGUID == guid then
                inspectAnswered = true
                FireInspectCallbacks()
            end
        end)
    end
end)

hooksecurefunc("ClearInspectPlayer", function()
    inspectedGUID = nil
    if inspectAnswered then
        inspectAnswered = false
        FireInspectCallbacks()
    end
end)

local inspectEventFrame = CreateFrame("Frame")
inspectEventFrame:RegisterEvent("INSPECT_TALENT_READY")
inspectEventFrame:SetScript("OnEvent", function()
    everAnswered = true
    if inspectedGUID then
        inspectAnswered = true
        FireInspectCallbacks()
    end
end)

function addon:SafeSetAtlas(texture, atlasName, useAtlasSize)
    if not texture or not atlasName then
        return false
    end

    if texture.SetAtlasTexture then
        local ok = pcall(texture.SetAtlasTexture, texture, atlasName, useAtlasSize)
        return ok
    end

    return false
end

function addon:SafeSetTexture(texture, path, fallback)
    if not texture then
        return false
    end

    if path and path ~= "" then
        texture:SetTexture(path)
        return true
    end

    if fallback and fallback ~= "" then
        texture:SetTexture(fallback)
        return true
    end

    texture:SetTexture(nil)
    return false
end

function addon:ApplyDatabaseMigrations()
    if not self.db or not self.db.profile then
        return
    end

    local profile = self.db.profile
    local currentVersion = tonumber(profile.version) or 0

    if currentVersion < self.DB_SCHEMA_VERSION then
        ApplyMissingDefaults(self.defaults.profile, profile)
    end

    -- Combuctor → Bagster rename. AceDB already rawset a default `bagster` table at :New, so we
    -- can't gate on it being nil; the old `combuctor` table is the source of truth when present.
    local modules = rawget(profile, "modules")
    if modules then
        local oldC = rawget(modules, "combuctor")
        if oldC ~= nil then
            if type(oldC) == "table" and type(rawget(modules, "bagster")) == "table" then
                addon.DeepCopy(oldC, modules.bagster) -- user values win, defaults fill gaps
            else
                modules.bagster = oldC
            end
            modules.combuctor = nil
        end
    end

    -- Nameplate health text: the percent and number toggles became one format plus a placement.
    local nameplates = modules and rawget(modules, "nameplates")
    if nameplates then
        if currentVersion < 3 then
            if rawget(nameplates, "showHealthNumber") == true then
                nameplates.healthTextFormat, nameplates.healthTextPosition = "valuePercent", "barSplit"
            elseif rawget(nameplates, "showHealthPercent") == false or rawget(nameplates, "centerNameOnly") == true then
                -- Centering the name used to hide the percent as well.
                nameplates.healthTextFormat = "none"
            end
        end
        nameplates.showHealthNumber, nameplates.showHealthPercent = nil, nil
    end

    -- Aura borders: the rounded/square flag became a style; only an explicit square survives the new default.
    local auraborders = modules and rawget(modules, "auraborders")
    if auraborders and rawget(auraborders, "custom_border") ~= nil then
        if auraborders.custom_border == false then
            auraborders.border_style = "square"
        end
        auraborders.custom_border = nil
    end

    -- profile.chat had no readers left; clear stored values now that the default is gone.
    if rawget(profile, "chat") ~= nil then
        profile.chat = nil
    end

    -- Extra bar slots moved to db.char; drop the profile-wide leftovers so alts stop inheriting them.
    local additional = rawget(profile, "additional")
    local extrabar1 = additional and rawget(additional, "extrabar1")
    if extrabar1 then
        extrabar1.slots = nil
    end

    -- New modules ship with new default configs. Fill any module keys that are
    -- missing from an existing profile (modules added after the profile was
    -- created) so they adopt their defaults instead of reading as disabled.
    -- ApplyMissingDefaults only fills missing keys, never overwrites user values.
    local mods = rawget(profile, "modules")
    if mods and self.defaults.profile.modules then
        ApplyMissingDefaults(self.defaults.profile.modules, mods)
    end

    -- Auto-accept: the one friends-and-guild toggle became one toggle each.
    local autoaccept = rawget(profile, "autoaccept")
    if autoaccept and rawget(autoaccept, "party") ~= nil then
        if autoaccept.party == true then
            autoaccept.friends, autoaccept.guild = true, true
        end
        autoaccept.party = nil
    end

    local global = self.db.global
    if global then
        local oldCache = rawget(global, "combuctorCache")
        if oldCache ~= nil then
            if type(oldCache) == "table" and type(rawget(global, "bagsterCache")) == "table" then
                addon.DeepCopy(oldCache, global.bagsterCache)
            else
                global.bagsterCache = oldCache
            end
            global.combuctorCache = nil
        end
    end

    profile.version = self.DB_SCHEMA_VERSION
    self.db.version = self.DB_SCHEMA_VERSION
end

-- PRINT / DEBUG UTILITIES
-- ============================================================================

-- Print a formatted message
function addon:Print(...)
    print("|cFF00FF00[DragonUI]|r", ...)
end

-- Print a debug message (only in debug mode)
function addon:Debug(...)
    if addon.debugMode then
        print("|cFFFFFF00[DragonUI Debug]|r", ...)
    end
end

-- Print an error message
function addon:Error(...)
    print("|cFFFF0000[DragonUI Error]|r", ...)
end
