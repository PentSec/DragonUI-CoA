-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.

local addon = select(2, ...)
local CP = addon.CharacterPanel

-- The Reputation tab, rendered by us instead of ReputationFrame. GetFactionInfo puts isHeader at
-- position NINE, and expanding or collapsing renumbers the list, so it is rebuilt after each.

local ROW_H = 24
-- Retail's ReputationBarTemplate to the pixel: a 99x13 bar under a 60+39 frame that overhangs it by
-- a pixel top and bottom. UI-Character-ReputationBar is a 3.3.5a path, so the art needs no shipping.
local BAR_W, BAR_H = 99, 13
local FRAME_TEX = "Interface\\PaperDollInfoFrame\\UI-Character-ReputationBar"
local FRAME_LEFT_W, FRAME_H = 60, 15
local DETAIL_FONT_SIZE = 11
local CHILD_INDENT = 12
-- Retail's own: a sub-header sits all but flush with a top-level one, because its ROW SHAPE is what
-- separates them, not how far it is pushed in.
local SUBHEADER_INDENT = 2
local TOGGLE_SIZE = 18
local FILL = "Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar"

local pane, scroll, content
local headers, entries, subheaders
local flat = {}
-- Declared here because toggleHeader hands it to the reveal driver, and it is defined further down.
local repaint

-- Filtering by standing, not sorting: Blizzard already hands the list alphabetical inside each
-- header, so a name sort changed nothing visible. Labels are the client's own globals, already
-- translated in every locale. Kept in the profile so the choice survives a reload.
local STANDINGS = 8

local function standingLabel(id)
    return _G["FACTION_STANDING_LABEL" .. id] or tostring(id)
end

local function standingFilter() return CP:Config().rep_standing or 0 end

-- Wrath's answer to retail's "Show Legacy Reputations": the factions the player has parked through
-- the detail popup's Move to Inactive. Same intent, on the only flag this client actually has.
local function hideInactive() return CP:Config().rep_hide_inactive and true or false end

local filterButton

local function updateSelection()
    if not filterButton then return end
    local id = standingFilter()
    filterButton:SetSelection(id == 0 and addon.L["All"] or standingLabel(id))
end

local function filterMenuEntries()
    local entries = {}
    local function entry(text, id)
        entries[#entries + 1] = {
            text = text,
            checked = (standingFilter() == id),
            func = function()
                CP:Config().rep_standing = id
                updateSelection()
                CP.RefreshReputationPane()
            end,
        }
    end

    entry(addon.L["All"], 0)
    -- Descending: Exalted is what a player scans for, and it reads as the ladder they climb.
    for id = STANDINGS, 1, -1 do entry(standingLabel(id), id) end

    -- Retail's shape: the radios pick one standing, then a rule and an independent checkbox below.
    entries[#entries + 1] = { divider = true }
    entries[#entries + 1] = {
        text = addon.L["Hide inactive"],
        checked = hideInactive(),
        isCheckbox = true,
        func = function()
            CP:Config().rep_hide_inactive = not hideInactive()
            CP.RefreshReputationPane()
        end,
    }
    return entries
end

local function toggleHeader(index, collapsed)
    if collapsed then
        if ExpandFactionHeader then ExpandFactionHeader(index) end
        CP.RefreshReputationPane()
        -- After the refresh, so the run being revealed is read off the rebuilt list.
        CP.RevealChildrenOf(flat, index, repaint)
    else
        -- The rows are still live here; collapsing for real is what `finish` does.
        CP.FadeOutChildrenOf(flat, index, repaint, function()
            if CollapseFactionHeader then CollapseFactionHeader(index) end
            CP.RefreshReputationPane()
        end)
    end
end

-- Filled here rather than by ReputationFrame_Update: that only populates the detail frame for a
-- faction inside Blizzard's own displayed window, so anything past a screenful opened blank.
function CP.PopulateReputationDetail(index)
    local detail = _G.ReputationDetailFrame
    if not detail or not index then return end

    local name, description, _, _, _, _, atWarWith, canToggleAtWar,
          isHeader, _, _, isWatched = GetFactionInfo(index)

    _G.ReputationDetailFactionName:SetText(name or "")

    -- Re-asserted on every open: this is the only place the description's text is written, and it
    -- has to be bigger and dark for Blizzard's light parchment.
    local body = _G.ReputationDetailFactionDescription
    body:SetFontObject(GameFontHighlight)
    -- Face from the font object, size ours: the object has no size knob to turn.
    local face = body:GetFont()
    if face then body:SetFont(face, DETAIL_FONT_SIZE) end

    local color = CP.DETAIL_TEXT_COLOR or { 1, 1, 1 }
    body:SetTextColor(color[1], color[2], color[3])
    -- After SetFontObject: a font object carries its own shadow AND justification, and
    -- GameFontHighlight is centred, so alignment set at build time was thrown away here.
    body:SetShadowColor(0, 0, 0, 1)
    body:SetShadowOffset(1, -1)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetText(description or "")
    -- The scroll child measures the string, so it can only be sized once the text is in.
    if CP.UpdateDetailScroll then CP.UpdateDetailScroll() end

    local atWar = _G.ReputationDetailAtWarCheckBox
    atWar:SetChecked(atWarWith and 1 or nil)
    local warColor = (canToggleAtWar and not isHeader) and RED_FONT_COLOR or GRAY_FONT_COLOR
    if canToggleAtWar and not isHeader then atWar:Enable() else atWar:Disable() end
    _G.ReputationDetailAtWarCheckBoxText:SetTextColor(warColor.r, warColor.g, warColor.b)

    local inactive = _G.ReputationDetailInactiveCheckBox
    if isHeader then inactive:Disable() else inactive:Enable() end
    inactive:SetChecked(IsFactionInactive(index) and 1 or nil)

    _G.ReputationDetailMainScreenCheckBox:SetChecked(isWatched and 1 or nil)
end

-- Left piece first: CP.BuildRowBar indexes its piece widths in this same order.
local BAR_FRAME_COORDS = {
    { 0.765625, 1, 0.046875, 0.28125 },
    { 0, 0.15234375, 0.390625, 0.625 },
}

-- Shared with skillspane.lua, which loads after this file and wears the very same bar.
function CP.BuildRowBar(row, relativeTo, relativePoint, offsetX, look)
    local meter = CreateFrame("StatusBar", nil, row)
    meter:SetMinMaxValues(0, 1)
    meter:SetValue(1)
    meter:SetStatusBarTexture(look.fill)
    local fillTexture = meter:GetStatusBarTexture()
    if fillTexture then fillTexture:SetDrawLayer("BORDER") end
    meter:SetSize(look.width, look.height)
    meter:SetPoint("RIGHT", relativeTo, relativePoint, offsetX, 0)

    local backing = meter:CreateTexture(nil, "BACKGROUND")
    backing:SetTexture(0, 0, 0)
    backing:SetAllPoints(meter)

    local widths = { look.capWidth, look.width - look.capWidth }
    local hangFrom, hangPoint = meter, "LEFT"
    for i, coords in ipairs(BAR_FRAME_COORDS) do
        local piece = meter:CreateTexture(nil, "OVERLAY")
        piece:SetTexture(look.frame)
        piece:SetTexCoord(unpack(coords))
        piece:SetSize(widths[i], look.frameHeight)
        piece:SetPoint("LEFT", hangFrom, hangPoint, 0, 0)
        hangFrom, hangPoint = piece, "RIGHT"
    end

    -- Created after the frame pieces so it draws over them in the shared OVERLAY layer.
    local caption = meter:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    caption:SetPoint("CENTER", meter, "CENTER", 0, 0)
    meter.Caption = caption
    return meter
end

local REP_BAR_LOOK = {
    width = BAR_W,
    height = BAR_H,
    fill = FILL,
    frame = FRAME_TEX,
    capWidth = FRAME_LEFT_W,
    frameHeight = FRAME_H,
}

local function showProgress(self)
    self.Meter.Caption:SetText(self._progress or "")
end

local function showStanding(self)
    self.Meter.Caption:SetText(self._standing or "")
end

local function openFactionDetail(self)
    local detail, faction = _G.ReputationDetailFrame, self._factionIndex
    if not (detail and faction) then return end

    if detail:IsShown() and GetSelectedFaction() == faction then
        detail:Hide()
        return
    end
    -- Selection before Show feeds the OnShow hook; the explicit fill covers an already-open frame.
    SetSelectedFaction(faction)
    detail:Show()
    CP.PopulateReputationDetail(faction)
end

local function updateEntry(row, info)
    local base = info.barMin or 0
    local span, earned = (info.barMax or 0) - base, (info.barValue or 0) - base
    if span <= 0 then span, earned = 1, 0 end
    local meter = row.Meter
    meter:SetMinMaxValues(0, span)
    meter:SetValue(earned)

    row.Title:SetText(info.name or "")
    row._factionIndex = info.index

    local standing = info.standingID or 4
    local tint = FACTION_BAR_COLORS and FACTION_BAR_COLORS[standing]
    if tint then meter:SetStatusBarColor(tint.r, tint.g, tint.b) end

    row._standing = _G["FACTION_STANDING_LABEL" .. standing] or ""
    meter.Caption:SetText(row._standing)
    row._progress = string.format("%d / %d", earned, span)
end

local function buildEntry(parent)
    local line = CreateFrame("Button", nil, parent)
    line:RegisterForClicks("LeftButtonUp")
    line:SetScript("OnClick", openFactionDetail)
    line:SetScript("OnEnter", showProgress)
    line:SetScript("OnLeave", showStanding)
    line:SetHeight(ROW_H)
    line.Meter = CP.BuildRowBar(line, line, "RIGHT", -4, REP_BAR_LOOK)

    local title = line:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    title:SetJustifyH("LEFT")
    title:SetPoint("RIGHT", line.Meter, "LEFT", -8, 0)
    title:SetPoint("LEFT", line, "LEFT", CHILD_INDENT, 0)
    line.Title = title

    local wash = line:CreateTexture(nil, "HIGHLIGHT")
    wash:SetTexture(1, 1, 1)
    wash:SetAlpha(0.1)
    wash:SetAllPoints(line)
    return line
end

-- ReputationSubHeaderTemplate inherits the ENTRY template, not the header one: a nested header is
-- an ordinary row carrying a collapse box, so it never wears the big bar its parent does.
local function buildSubHeader(parent)
    local row = CreateFrame("Button", nil, parent)
    row:SetHeight(ROW_H)

    local toggle = CreateFrame("Button", nil, row)
    toggle:SetSize(TOGGLE_SIZE, TOGGLE_SIZE)
    toggle:SetPoint("LEFT", row, "LEFT", CHILD_INDENT, 0)
    -- Seeded with any path purely so the texture objects exist; updateSubHeader atlases them.
    toggle:SetNormalTexture("Interface\\Buttons\\UI-PlusButton-Up")
    toggle:SetPushedTexture("Interface\\Buttons\\UI-PlusButton-Up")
    toggle:GetNormalTexture():SetAllPoints(toggle)
    toggle:GetPushedTexture():SetAllPoints(toggle)
    toggle:SetHighlightTexture("Interface\\Buttons\\UI-PlusButton-Hilight", "ADD")
    row.Toggle = toggle

    local name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    name:SetPoint("LEFT", toggle, "RIGHT", 4, 0)
    name:SetPoint("RIGHT", row, "RIGHT", -8, 0)
    name:SetJustifyH("LEFT")
    row.Text = name

    local hl = row:CreateTexture(nil, "HIGHLIGHT")
    hl:SetTexture(1, 1, 1)
    hl:SetAlpha(0.1)
    hl:SetAllPoints(row)

    -- The box and the row do the same thing, so the box just forwards to the row that owns it.
    local function click(self)
        local owner = self._row or self
        if owner._index then toggleHeader(owner._index, owner._collapsed) end
    end
    toggle._row = row
    toggle:SetScript("OnClick", click)
    row:RegisterForClicks("LeftButtonUp")
    row:SetScript("OnClick", click)
    return row
end

local function updateSubHeader(row, info)
    row._index, row._collapsed = info.index, info.isCollapsed
    row.Text:SetText(info.name or "")
    local state = info.isCollapsed and "closed" or "open"
    row.Toggle:GetNormalTexture():SetAtlasTexture("campaign_headericon_" .. state)
    row.Toggle:GetPushedTexture():SetAtlasTexture("campaign_headericon_" .. state .. "pressed")
end

repaint = function()
    if not (scroll and content) then return end
    CP.PaintListRows(scroll, content, flat, ROW_H, { headers, entries, subheaders }, function(data)
        if data.kind == "header" then
            if data.isChild then
                local row = subheaders:acquire()
                updateSubHeader(row, data)
                return row, SUBHEADER_INDENT
            end
            local row = headers:acquire()
            CP.UpdateListHeader(row, data.name, data.index, data.isCollapsed)
            return row, 0
        end
        local row = entries:acquire()
        updateEntry(row, data)
        return row, data.isChild and CHILD_INDENT or 0
    end)
end

local function refresh()
    if not pane or not pane:IsShown() then return end

    local wanted = standingFilter()

    flat = {}
    for i = 1, (GetNumFactions and GetNumFactions() or 0) do
        local name, _, standingID, barMin, barMax, barValue,
              _, _, isHeader, isCollapsed, hasRep, _, isChild = GetFactionInfo(i)
        -- Headers stay through the filter: dropping one strands the factions under it with no way back.
        local hidden = wanted ~= 0 and not isHeader and standingID ~= wanted
        if hideInactive() and not isHeader and IsFactionInactive and IsFactionInactive(i) then
            hidden = true
        end
        if name and not hidden then
            flat[#flat + 1] = {
                kind = isHeader and "header" or "entry",
                index = i, name = name, standingID = standingID,
                barMin = barMin, barMax = barMax, barValue = barValue,
                isCollapsed = isCollapsed, isChild = isChild, hasRep = hasRep,
            }
        end
    end

    -- Repeated because headers nest: emptying an inner one can leave its parent empty in turn.
    local pruning = wanted ~= 0 or hideInactive()
    while pruning do
        local kept = {}
        for i = 1, #flat do
            local row, nextRow = flat[i], flat[i + 1]
            -- An expanded header whose whole run got filtered out is just noise; a collapsed one
            -- may still hide matches, so it stays clickable.
            local empty = row.kind == "header" and not row.isCollapsed and not row.hasRep
                and (not nextRow or nextRow.kind == "header")
            if not empty then kept[#kept + 1] = row end
        end
        pruning = #kept < #flat
        flat = kept
    end

    repaint()
end

CP.RefreshReputationPane = refresh

-- Blizzard's faction bars are child FRAMES, so chrome.lua's texture sweep never reaches them. Show
-- is redirected the same way, because the stock code re-shows them on every tab switch.
local function suppressBlizzard(frame)
    if not frame or frame._duiSuppressed then return end
    frame._duiSuppressed = true

    for _, child in ipairs({ frame:GetChildren() }) do
        -- The detail popup stays live: it is the only way to watch a faction.
        if child ~= _G.ReputationDetailFrame then
            child:Hide()
            child.Show = child.Hide
        end
    end
    for _, region in ipairs({ frame:GetRegions() }) do
        if region.GetObjectType and region:GetObjectType() == "FontString" then
            region:Hide()
            region.Show = region.Hide
        end
    end
end

local function build()
    local cf = _G.CharacterFrame
    if pane or not cf or not cf.Inset then return end

    pane = CreateFrame("Frame", "DragonUIReputationPane", cf.Inset)
    pane:SetAllPoints(cf.Inset)
    pane:SetFrameLevel(cf:GetFrameLevel() + CP.SUBFRAME_LEVEL + 5)
    pane:Hide()

    -- Centred in the title strip, on the same right edge as the paperdoll tab's cog.
    if CP.CreateFilterDropdown then
        local cf = _G.CharacterFrame
        filterButton = CP.CreateFilterDropdown(pane, "DragonUIReputationFilter", CP.FILTER_DROPDOWN_W, filterMenuEntries)
        filterButton:SetFrameLevel(cf:GetFrameLevel() + CP.SUBFRAME_LEVEL + 20)
        CP.AnchorFilterDropdown(pane, filterButton)
        updateSelection()
    end

    scroll, content = CP.BuildListPane(pane, "DragonUIReputationScroll", ROW_H, repaint)
    headers = CP.NewRowPool(content, function(parent)
        return CP.BuildListHeader(parent, toggleHeader)
    end)
    entries = CP.NewRowPool(content, buildEntry)
    subheaders = CP.NewRowPool(content, buildSubHeader)
    CP.PrewarmRowPools(scroll, ROW_H, { headers, entries, subheaders })

    CP.WireListPaneShow(pane, refresh)
    scroll:HookScript("OnSizeChanged", repaint)

    -- Geometry and skin belong to reputationdetail.lua; this only keeps its contents current.
    local detail = _G.ReputationDetailFrame
    if detail then
        detail:HookScript("OnShow", function()
            CP.PopulateReputationDetail(GetSelectedFaction())
        end)
    end

    local blizzard = _G.ReputationFrame
    if blizzard then
        suppressBlizzard(blizzard)
        blizzard:HookScript("OnShow", function()
            suppressBlizzard(blizzard)
            pane:Show()
        end)
        blizzard:HookScript("OnHide", function() pane:Hide() end)
        if blizzard:IsShown() then pane:Show() end
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("UPDATE_FACTION")
events:SetScript("OnEvent", refresh)

CP:RegisterBuilder("reputationpane", build)
