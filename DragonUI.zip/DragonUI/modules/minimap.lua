﻿-- Copyright (c) 2026 NeticSoul. Licensed under the MIT License; see LICENSE.
-- Portions adapted from RetailUI (MIT, (c) 2024 Dmitriy); see THIRD_PARTY_NOTICES.

-- ============================================================================
-- DragonUI - Minimap Module
-- ============================================================================

local addon = select(2, ...);
local L = addon.L

-- ============================================================================
-- MODULE STATE
-- ============================================================================

local MinimapModule = {
    initialized = false,
    applied = false,
    originalStates = {},
    farmMode = { active = false, holder = nil, parents = {}, layers = {} },
    hooks = {},
    stateDrivers = {},
    frames = {},
    launcherButtons = {},
    -- Legacy properties for compatibility
    minimapFrame = nil,
    borderFrame = nil,
    isEnabled = false,
    originalMinimapSettings = {},
    originalMask = nil
}
addon.MinimapModule = MinimapModule;

-- Register with ModuleRegistry (if available)
if addon.RegisterModule then
    addon:RegisterModule("minimap", MinimapModule,
        L["Minimap"],
        L["Custom minimap styling, positioning, tracking icons and calendar"])
end

-- Module config helpers (centralized in api.lua)
local function IsModuleEnabled()
    return addon:IsModuleEnabled("minimap")
end

local function IsMinimapSystemActive()
    return IsModuleEnabled() and MinimapModule.applied
end

local function IsDragonUIMinimapControlling()
    return MinimapModule.applied or MinimapModule._initializingMinimapSystem
end

-- ============================================================================
-- FARM MODE
-- ============================================================================

local function GetMinimapSettings()
    return addon.db and addon.db.profile and addon.db.profile.minimap
end

-- The farm bonus means this at UI scale 0.8; any other keeps the farm map's size on screen.
local FARM_REFERENCE_UI_SCALE = 0.8

-- The player's minimap scale, times the farm bonus while farm mode is on.
local function GetEffectiveMinimapScale()
    local settings = GetMinimapSettings()
    local scale = tonumber(settings and settings.scale) or 1
    if scale <= 0 then scale = 1 end

    if settings and settings.farm_mode_enabled == true then
        local bonus = math.min(math.max(tonumber(settings.farm_mode_scale) or 1, 1), 2)
        scale = scale * math.max(bonus * FARM_REFERENCE_UI_SCALE / UIParent:GetEffectiveScale(), 1)
    end

    return scale
end

local blipScale = 1.12
-- Sampled at load: ReplaceBlizzardFrame runs on every apply and would grow the map each time.
local mapUnscaledWidth = Minimap:GetWidth() * 1.36 / blipScale
local mapUnscaledHeight = Minimap:GetHeight() * 1.36 / blipScale
-- Drawn width: 284 was tuned under Texture:SetRotation, which draws the art 1/sqrt(2) smaller.
local BORDER_TO_MAP_RATIO = 284 / math.sqrt(2) / mapUnscaledWidth

local DRAGONUI_MINIMAP_MASK = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\uiminimapmask.tga"
local VANILLA_MINIMAP_MASK = "Textures\\MinimapMask"
local DRAGONUI_MINIMAP_CIRCLE = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\uiminimapborder.tga"
local FOREVER_MINIMAP_MASK = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_mask.tga"
local FOREVER_MINIMAP_CIRCLE = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_circle"
local FOREVER_MINIMAP_POINTER = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_pointer"
local SQUARE_MINIMAP_MASK = "Interface\\Buttons\\WHITE8X8"
local DRAGONUI_SQUARE_FRAME = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\uiminimapsquareborder.tga"
local DRAGONUI_SQUARE_COLLECTOR_ICON = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\collector_toggle_square.tga"
-- The icon is the frame's left chevron cut on 64 art texels, centred 201 texels left of centre.
local DRAGONUI_SQUARE_ARROW_SIZE, DRAGONUI_SQUARE_ARROW_X = 64, -201
-- Art texels across the map in game: the line sits ~2% inside the map's edge (measured, not 389).
local DRAGONUI_SQUARE_MAP_TEXELS = 397
local FOREVER_SQUARE_FRAME = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_square_frame.tga"
local FOREVER_SQUARE_FRAME_ROUNDED = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_square_frame_rounded.tga"
local FOREVER_SQUARE_POINTER = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\forever_square_pointer.tga"
-- The square frame's line runs 389 px apart in its 512 px art.
local DRAGONUI_SQUARE_SPAN = 389
-- The map's width inside the round ring's 256 px art: the square keeps the round style's map size.
local DRAGONUI_RING_MAP_SPAN = 238

-- WoW Forever's minimap (Camelot Skin.lua and Diel.lua) in its own units, around a 198-wide map.
local FOREVER_MAP_SIZE = 198
-- The 506 px ring art is padded to 512 px so the pointer turns about the texture centre.
local FOREVER_RING_SIZE = 253 * 512 / 506
local FOREVER_DIEL_X, FOREVER_DIEL_Y = 53, 88.75
-- The same spot on the band unwrapped onto the square frame; rounded corners shorten the band.
local FOREVER_SQUARE_DIEL_X, FOREVER_SQUARE_ROUNDED_DIEL_X, FOREVER_SQUARE_DIEL_Y = 68.37, 66.31, 103.37
local FOREVER_DIEL_RING_SIZE, FOREVER_DIEL_ICON_SIZE = 42, 33
-- Middle of the ring's band (94.5 to 105): where minimap buttons ride in Forever style.
local FOREVER_BAND_RADIUS = 99.75
-- The day/night ring doubles as the button border; its band sits further in than ours, so it draws larger.
local FOREVER_BUTTON_RING_GROWTH = 1.1
local FOREVER_BUTTON_RING_ATLAS = "Minimap-Forever-Frame-Cycle"
-- Zoom buttons' centre x, y and width, height (Minimap.xml): Retail's art, riding Forever's wider ring.
local FOREVER_ZOOM_IN, FOREVER_ZOOM_OUT = { 88, -68, 17, 17 }, { 72, -84, 17, 9 }
-- 3.3.5a's LibDBIcon puts launchers a fixed 80 units out; only their scale can move them.
local LIBDBICON_ORBIT = 80
local MAP_OFFSET_Y = -25
-- Forever keeps 13.5 units between the zone bar and the pointer tip; ours would overlap it by 12.
local FOREVER_MAP_DROP, FOREVER_CLUSTER_LIFT = 25, 12
-- Without its pointer the Forever square rises until its day/night badge nears the zone bar.
local FOREVER_SQUARE_POINTERLESS_RISE = 9
-- The square frame's top chevron rises past the round ring's; this keeps it as far below the bar.
local DRAGONUI_SQUARE_MAP_DROP = 11
-- GameTime.lua's own dawn and dusk, in minutes past midnight.
local GAMETIME_DAWN, GAMETIME_DUSK = 5 * 60 + 30, 21 * 60

local ADDON_ORBIT_RADIUS = 15
local DRAGONUI_SETTINGS_BUTTON_SIZE = 21
local DRAGONUI_SETTINGS_BUTTON_ICON = "Interface\\AddOns\\DragonUI\\Textures\\UI\\INV_Misc_Head_Dragon_01"
local DRAGONUI_CLASSIC_COLLECTOR_ICON = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\collector_toggle.tga"

local MAP_PIN_NAME_FRAGMENTS = {
    "Archy", "GameTimeFrame", "GatherMatePin", "GatherNote", "HandyNotesPin", "HelpOpenTicketButton",
    "MiniMapBattlefieldFrame", "MiniMapMailFrame", "MiniMapTrackingButton", "MinimMap", "QuestMapPOI",
    "QuestieFrame", "Questie_MiniMapNote", "Spy_MapNoteList_mini", "TimeManagerClockButton", "WorldMapPOIFrame",
    "ZGVMarker", "pfMap", "pfMinimap", "pfQuest", "pfquest", "poiWorldMapPOIFrame",
}

-- Keep launcher buttons skinnable while still excluding internal quest pins.
-- Questie launcher is LibDBIcon-based (LibDBIcon10_Questie), while pfQuest
-- uses a named minimap button (pfQuestIcon).
local QUEST_ADDON_LAUNCHER_BUTTONS = {
    ["pfQuestIcon"] = true,
    ["LibDBIcon10_Questie"] = true,
}

local function IsQuestAddonLauncherButton(button)
    if not button or not button.GetName then
        return false
    end

    local frameName = button:GetName()
    if not frameName then
        return false
    end

    if QUEST_ADDON_LAUNCHER_BUTTONS[frameName] then
        return true
    end

    -- Defensive future-proofing for Questie forks that keep the same LibDBIcon prefix.
    if frameName:find("LibDBIcon10_Questie", 1, true) == 1 then
        return true
    end

    return false
end

local function IsFrameWhitelisted(frameName)
    if type(frameName) ~= "string" then return false end
    for index = 1, #MAP_PIN_NAME_FRAGMENTS do
        if string.find(frameName, MAP_PIN_NAME_FRAGMENTS[index], 1, true) then return true end
    end
    return false
end

local function IsQuestMinimapPin(button)
    if not button then
        return false
    end

    -- Cache positive detections: quest pins are stable frame objects and this
    -- avoids repeated texture/region scans on frequent minimap button rescans.
    if button.DragonUI_IsQuestPin then
        return true
    end

    -- Do not classify the actual addon launcher icon as an internal quest pin.
    -- This lets DragonUI skin the launcher button while still skipping map pins.
    if IsQuestAddonLauncherButton(button) then
        return false
    end

    local frameName = button:GetName()
    if IsFrameWhitelisted(frameName) then
        button.DragonUI_IsQuestPin = true
        return true
    end

    local parent = button:GetParent()
    local parentName = parent and parent.GetName and parent:GetName()
    if IsFrameWhitelisted(parentName) then
        button.DragonUI_IsQuestPin = true
        return true
    end

    if button.GetNumChildren then
        local children = { button:GetChildren() }
        for i = 1, #children do
            local child = children[i]
            local childName = child and child.GetName and child:GetName()
            if IsFrameWhitelisted(childName) then
                button.DragonUI_IsQuestPin = true
                return true
            end
        end
    end

    -- pfQuest/Questie/TomTom pins and TotemRadius rings are nameless Buttons on Minimap that name checks miss;
    -- detect them (read-only) by their own AddOn folder in a region texture path so the skin leaves them alone.
    if button.GetNumRegions then
        for i = 1, button:GetNumRegions() do
            local region = select(i, button:GetRegions())
            if region and region.GetTexture then
                local tex = region:GetTexture()
                if type(tex) == "string" then
                    local lower = tex:lower()
                    if lower:find("pfquest", 1, true)
                       or lower:find("pfmap", 1, true)
                       or lower:find("pfminimap", 1, true)
                       or lower:find("questie", 1, true)
                       or lower:find("questhelper", 1, true)
                       or lower:find("totemradius", 1, true)
                       or lower:find("\\tomtom\\", 1, true) then
                        button.DragonUI_IsQuestPin = true
                        return true
                    end
                end
            end
        end
    end

    local isQuestPin = button.miniMapIcon or button.miniMapIconData or button.pfQuest or button.pfquest
    if isQuestPin then
        button.DragonUI_IsQuestPin = true
        return true
    end

    return false
end

local function GetMinimapStyle()
    local minimapConfig = addon.db and addon.db.profile and addon.db.profile.minimap
    if not minimapConfig then return nil end
    -- Pre-release name of the Forever square style.
    if minimapConfig.style == "square" then
        minimapConfig.style = "forever_square"
    end
    return minimapConfig.style
end

local function IsForeverStyle()
    local style = GetMinimapStyle()
    return style == "forever" or style == "forever_square"
end

local function IsSquareStyle()
    local style = GetMinimapStyle()
    return style == "dragonui_square" or style == "forever_square"
end

-- Forever units to MinimapBackdrop units; ReplaceBlizzardFrame scales the backdrop back to the cluster's.
local function ForeverScale()
    return Minimap:GetWidth() / MinimapBackdrop:GetScale() / FOREVER_MAP_SIZE
end

local function IsDragonUISquareFrame()
    local texture = MinimapModule.circleTexture
    return texture == DRAGONUI_SQUARE_FRAME
end

local function UpdateMinimapCircleSize()
    if not Minimap or not Minimap.Circle then return end

    local mapSize = math.max(Minimap:GetWidth(), Minimap:GetHeight())
    if not mapSize or mapSize <= 0 then return end

    local borderSize = mapSize * BORDER_TO_MAP_RATIO
    if MinimapModule.foreverShown then
        borderSize = FOREVER_RING_SIZE * ForeverScale()
    elseif IsDragonUISquareFrame() then
        borderSize = borderSize * DRAGONUI_RING_MAP_SPAN / 256 * 512 / DRAGONUI_SQUARE_SPAN
    end
    if MinimapModule.activeCircleSize ~= borderSize then
        Minimap.Circle:SetSize(borderSize, borderSize)
        Minimap.Circle:ClearAllPoints()
        Minimap.Circle:SetPoint("CENTER", Minimap, "CENTER", 0, 0)
        MinimapModule.activeCircleSize = borderSize
    end
end

-- Size and x offset from the map's centre, in btn's units, of the frame's left chevron.
local function GetSquareArrowPlacement(btn)
    if not IsDragonUISquareFrame() then return nil end
    local texel = Minimap:GetWidth() * Minimap:GetEffectiveScale() / btn:GetEffectiveScale() / DRAGONUI_SQUARE_MAP_TEXELS
    return DRAGONUI_SQUARE_ARROW_SIZE * texel, DRAGONUI_SQUARE_ARROW_X * texel
end

local function IsSexyMapHybridModeValue(mode)
    return mode == "hybrid"
end

local function UpdateMinimapMaskForRotation()
    if not Minimap or not IsDragonUIMinimapControlling() then return end

    local isHybridMode = MinimapModule.sexyMapHybridMode
        or MinimapModule._allowExternalMask
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))

    -- In hybrid mode, SexyMap owns the minimap shape/mask.
    if isHybridMode then
        MinimapModule.activeMask = nil
        return
    end

    local minimapConfig = addon.db and addon.db.profile and addon.db.profile.minimap
    local isSquare = IsSquareStyle()
    local useVanillaMask = not isSquare
        and minimapConfig
        and minimapConfig.animated_border_enabled == true
        and minimapConfig.animated_border_hide_dragonui_border == true
    local decorations = addon.MinimapDecorations
    local presetMask = isSquare and decorations and decorations.GetSquareMask and decorations:GetSquareMask()
    local desiredMask = isSquare and (presetMask or SQUARE_MINIMAP_MASK)
        or (useVanillaMask and VANILLA_MINIMAP_MASK
            or (IsForeverStyle() and FOREVER_MINIMAP_MASK or DRAGONUI_MINIMAP_MASK))

    if MinimapModule.activeMask ~= desiredMask then
        Minimap:SetMaskTexture(desiredMask)
        MinimapModule.activeMask = desiredMask
    end
end

local function IsHybridMinimapModeActive()
    return MinimapModule.sexyMapHybridMode
        or MinimapModule._allowExternalMask
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))
end

local function IsForeverLayout()
    return IsForeverStyle() and not IsHybridMinimapModeActive()
end

local function IsSquareLayout()
    return IsSquareStyle() and not IsHybridMinimapModeActive()
end

local function IsForeverActive()
    return IsForeverLayout() and IsDragonUIMinimapControlling()
        and not MinimapModule._allowExternalBorderControl
end

-- The thin box border the square style first shipped with, kept as an option for Forever square.
local function IsThinSquareBorder()
    if not (IsSquareLayout() and IsForeverActive()) then return false end
    return addon.db.profile.minimap.forever_square_border == "thin"
end

local function ShowSquareTopArrow()
    return addon.db.profile.minimap.square_top_arrow ~= false
end

-- In Minimap units; nil keeps DragonUI's own orbit.
local function GetForeverOrbitRadius()
    if not IsForeverActive() then return nil end
    return FOREVER_BAND_RADIUS * Minimap:GetWidth() / FOREVER_MAP_SIZE
end

local function GetLauncherScale()
    local foreverOrbit = GetForeverOrbitRadius()
    if foreverOrbit then
        return foreverOrbit / LIBDBICON_ORBIT
    end
    return (1 / blipScale) * (1 + ADDON_ORBIT_RADIUS / 100)
end

-- Old builds forced rotateMinimap off indoors, so a logout while forced saved it as 0.
local function RestoreForcedIndoorRotation()
    local minimapConfig = addon.db and addon.db.profile and addon.db.profile.minimap
    if not minimapConfig or minimapConfig.indoorRotatePreference == nil then return end
    if minimapConfig.indoorRotatePreference == "1" and GetCVar("rotateMinimap") == "0" then
        SetCVar("rotateMinimap", "1")
    end
    minimapConfig.indoorRotatePreference = nil
end

local function UpdateMinimapBackdropAlignment(force)
    if not Minimap or not MinimapBackdrop then return end

    local rotateEnabled = GetCVar("rotateMinimap") == "1"
    local isIndoor = IsIndoors and IsIndoors()
    local desiredYOffset = (rotateEnabled and isIndoor) and 0 or 3

    if force or MinimapModule.backdropYOffset ~= desiredYOffset then
        MinimapBackdrop:ClearAllPoints()
        MinimapBackdrop:SetPoint("CENTER", Minimap, "CENTER", 0, desiredYOffset)
        MinimapModule.backdropYOffset = desiredYOffset
    end
end

local function UpdateIndoorRotateScale()
    if not Minimap then return end

    local desiredScale = blipScale

    if MinimapModule.activeMinimapScale ~= desiredScale then
        Minimap:SetScale(desiredScale)
        MinimapModule.activeMinimapScale = desiredScale
    end
end

local function RotateTexCoords(texture, angle)
    local c = math.cos(angle)
    local s = math.sin(angle)
    local cx, cy = 0.5, 0.5

    local function RotatePoint(x, y)
        local dx = x - cx
        local dy = y - cy
        return cx + dx * c - dy * s, cy + dx * s + dy * c
    end

    local ulx, uly = RotatePoint(0, 0)
    local llx, lly = RotatePoint(0, 1)
    local urx, ury = RotatePoint(1, 0)
    local lrx, lry = RotatePoint(1, 1)
    texture:SetTexCoord(ulx, uly, llx, lly, urx, ury, lrx, lry)
end

-- ============================================================================
-- WOW FOREVER STYLE
-- ============================================================================

local foreverFrame

local function UpdateForeverDiel()
    local hour, minute = GetGameTime()
    local now = (hour or 0) * 60 + (minute or 0)
    local isDay = now >= GAMETIME_DAWN and now < GAMETIME_DUSK
    if foreverFrame.isDay ~= isDay then
        foreverFrame.isDay = isDay
        foreverFrame.dielIcon:SetAtlasTexture(isDay and "Minimap-Forever-DayCycle" or "Minimap-Forever-NightCycle")
    end
end

local function EnsureForeverFrame()
    if foreverFrame then return foreverFrame end

    -- One level above MinimapBackdrop: the pointer must draw over the ring texture at any draw layer.
    local frame = CreateFrame("Frame", nil, MinimapBackdrop)
    frame:SetAllPoints(MinimapBackdrop)
    frame:SetFrameLevel(MinimapBackdrop:GetFrameLevel() + 1)
    frame:Hide()

    frame.pointer = frame:CreateTexture(nil, "ARTWORK")
    frame.pointer:SetTexture(FOREVER_MINIMAP_POINTER)
    -- Forever raises the day/night badge so the turning pointer passes wholly beneath it (Diel.lua).
    frame.diel = CreateFrame("Frame", nil, frame)
    frame.diel:SetAllPoints(frame)
    frame.diel:SetFrameLevel(frame:GetFrameLevel() + 1)
    frame.dielIcon = frame.diel:CreateTexture(nil, "BORDER")
    frame.dielRing = frame.diel:CreateTexture(nil, "OVERLAY")
    frame.dielRing:SetAtlasTexture("Minimap-Forever-Frame-Cycle")

    local sinceCheck = 0
    frame:SetScript("OnShow", function()
        sinceCheck = 0
        UpdateForeverDiel()
    end)
    frame:SetScript("OnUpdate", function(_, elapsed)
        sinceCheck = sinceCheck + elapsed
        if sinceCheck >= 1 then
            sinceCheck = 0
            UpdateForeverDiel()
        end
    end)

    foreverFrame = frame
    return frame
end

-- Decorations, dark mode and hybrid mode drive the ring; the pointer and badge follow it.
local function SyncForeverOverlay()
    if not foreverFrame then return end
    local circle = Minimap.Circle
    local show = MinimapModule.foreverShown and circle and circle:IsShown()
        and not IsThinSquareBorder() and true or false
    if show then
        local r, g, b, a = circle:GetVertexColor()
        foreverFrame:SetAlpha(circle:GetAlpha())
        foreverFrame.pointer:SetVertexColor(r, g, b, a)
        foreverFrame.dielRing:SetVertexColor(r, g, b, a)
        foreverFrame.pointer:SetShownCompat(not IsSquareLayout() or ShowSquareTopArrow())
    end
    foreverFrame:SetShownCompat(show)
end

local function HookForeverMirror(circle)
    if circle.DragonUI_ForeverMirrored then return end
    circle.DragonUI_ForeverMirrored = true
    hooksecurefunc(circle, "Show", SyncForeverOverlay)
    hooksecurefunc(circle, "Hide", SyncForeverOverlay)
    hooksecurefunc(circle, "SetAlpha", SyncForeverOverlay)
    hooksecurefunc(circle, "SetVertexColor", SyncForeverOverlay)
end

-- Only Forever's round pointer turns; a turning ring drags its chevron off the arrow collector.
local function RotateRing(angle)
    if IsSquareLayout() or not MinimapModule.foreverShown then return end
    if foreverFrame then RotateTexCoords(foreverFrame.pointer, angle) end
end

local function ResetRingRotation()
    if MinimapModule.foreverShown then
        if foreverFrame then foreverFrame.pointer:SetTexCoord(0, 1, 0, 1) end
    elseif Minimap.Circle then
        -- Never SetRotation: it also shrinks the ring, and BORDER_TO_MAP_RATIO is its drawn size.
        Minimap.Circle:SetTexCoord(0, 1, 0, 1)
    end
end

local function LiftAbove(frame, key, cover)
    if not frame then return end
    local states = MinimapModule.originalStates
    if cover then
        if not states[key] then
            states[key] = frame:GetFrameLevel()
        end
        frame:SetFrameLevel(math.max(states[key], cover:GetFrameLevel() + 1))
    elseif states[key] then
        frame:SetFrameLevel(states[key])
        states[key] = nil
    end
end

-- The day/night badge and the square frames would otherwise cover these icons.
local function SyncCornerIconLevels(foreverActive)
    local square = IsSquareLayout() and IsDragonUIMinimapControlling()
    local border = MinimapModule.squareBorder
    if border and not border:IsShown() then border = nil end
    local cover = border or (foreverActive and foreverFrame and foreverFrame.diel) or (square and MinimapBackdrop) or nil
    LiftAbove(MiniMapInstanceDifficulty, "InstanceDifficultyLevel", cover)
    LiftAbove(MiniMapBattlefieldFrame, "BattlefieldLevel", square and cover or nil)
    LiftAbove(MiniMapMailFrame, "MailLevel", square and cover or nil)
    local foreverRound = foreverActive and not square
    LiftAbove(MinimapZoomIn, "ZoomInLevel", foreverRound and cover or nil)
    LiftAbove(MinimapZoomOut, "ZoomOutLevel", foreverRound and cover or nil)
end

local function UpdateZoomButtonsLayout()
    if not MinimapZoomIn or not MinimapZoomOut or IsHybridMinimapModeActive() then return end
    MinimapZoomIn:ClearAllPoints()
    MinimapZoomOut:ClearAllPoints()
    if IsForeverActive() and not IsSquareLayout() then
        for _, spot in ipairs({ { MinimapZoomIn, FOREVER_ZOOM_IN }, { MinimapZoomOut, FOREVER_ZOOM_OUT } }) do
            local button, place = spot[1], spot[2]
            local unit = Minimap:GetWidth() * Minimap:GetEffectiveScale() / button:GetEffectiveScale() / FOREVER_MAP_SIZE
            button:SetSize(place[3] * unit, place[4] * unit)
            button:SetPoint("CENTER", Minimap, "CENTER", place[1] * unit, place[2] * unit)
        end
    else
        MinimapZoomIn:SetPoint("BOTTOMRIGHT", 0, 15)
        MinimapZoomIn:SetSize(25, 24)
        MinimapZoomOut:SetPoint("BOTTOMRIGHT", -22, 0)
        MinimapZoomOut:SetSize(20, 12)
    end
end

-- The collector asks this when it hands a button back to the map; a module restore keeps the original scale.
local function AdoptLauncher(button)
    if MinimapModule._releasingLaunchers then return nil end
    if button:GetObjectType() ~= "Button" or IsFrameWhitelisted(button:GetName()) then return nil end
    MinimapModule.launcherButtons[button] = true
    return GetLauncherScale()
end

-- Only launchers we scaled ourselves; frames other addons parent later keep their own scale.
local function RescaleLaunchers()
    local scale = GetLauncherScale()
    local settingsButton = MinimapModule.frames and MinimapModule.frames.settingsButton
    for button in pairs(MinimapModule.launcherButtons) do
        if button ~= settingsButton and button:GetParent() == Minimap then
            button:SetScale(scale)
        end
    end
end

local function GetLibDBIcon()
    if not LibStub or not LibStub.GetLibrary then return nil end
    local ok, libDBIcon = pcall(LibStub.GetLibrary, LibStub, "LibDBIcon-1.0", true)
    if ok and libDBIcon and type(libDBIcon.SetButtonRadius) == "function" then
        return libDBIcon
    end
end

-- LibDBIcon repositions every button with the current shape when its radius is set.
local function SyncLibDBIconShape()
    local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
    if MinimapModule.libDBIconShape == shape then return end
    MinimapModule.libDBIconShape = shape
    local libDBIcon = GetLibDBIcon()
    local radius = libDBIcon and tonumber(libDBIcon.radius)
    if radius then
        libDBIcon:SetButtonRadius(radius)
    end
end

local function EnsureSquareBorder()
    if not MinimapModule.squareBorder then
        local border = addon.ForeverUI.AttachBoxBorder(Minimap)
        border:SetFrameLevel(Minimap:GetFrameLevel() + 5)
        border:EnableMouse(false)
        MinimapModule.squareBorder = border
    end
    return MinimapModule.squareBorder
end

-- Decorations' Hide DragonUI Border takes the thin line too, as it does the frames it stands in for.
local function SyncThinSquareBorder()
    local decorations = addon.MinimapDecorations
    local hidden = decorations and decorations.HidesDragonUIBorder and decorations:HidesDragonUIBorder()
    if IsThinSquareBorder() and not hidden and IsDragonUIMinimapControlling() then
        EnsureSquareBorder():Show()
    elseif MinimapModule.squareBorder then
        MinimapModule.squareBorder:Hide()
    end
end
MinimapModule.SyncThinSquareBorder = SyncThinSquareBorder

-- Calendar and tracking art share one 21x19 cell: pushed art sits one cell pixel down-right.
local function PressShift(frame)
    return frame:GetWidth() / 21, frame:GetHeight() / 19
end

-- The ADD highlight must follow the pushed art's shift or the icon draws twice.
local function AnchorPushedHighlight(button, cellFrame, pushed)
    local highlightTexture = button:GetHighlightTexture()
    if not highlightTexture then
        return
    end
    if pushed == nil then
        pushed = button:GetButtonState() == "PUSHED"
    end
    local dx, dy = 0, 0
    if pushed then
        dx, dy = PressShift(cellFrame)
    end
    highlightTexture:ClearAllPoints()
    highlightTexture:SetPoint("TOPLEFT", button, "TOPLEFT", dx, -dy)
    highlightTexture:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", dx, -dy)
end

-- The plate's shadow rim widens it right and down, so its centre sits up-left of the frame's.
local function TrackingPlateCenter(pushed)
    local w, h = MiniMapTracking:GetWidth(), MiniMapTracking:GetHeight()
    local x, y = -2 * w / 21, 1.5 * h / 19
    if pushed then
        local sx, sy = PressShift(MiniMapTracking)
        x, y = x + sx, y - sy
    end
    return x, y
end

local function UpdateMailPosition()
    if not MiniMapMailFrame or not MiniMapTracking then return end
    MiniMapMailFrame:ClearAllPoints()
    local plateX, plateY = TrackingPlateCenter()
    if IsSquareLayout() then
        MiniMapMailFrame:SetPoint("RIGHT", MiniMapTracking, "LEFT", -3, plateY)
    else
        -- The plate ends two cell px above the frame's bottom; keep 3 units under what is drawn.
        MiniMapMailFrame:SetPoint("TOP", MiniMapTracking, "BOTTOM", plateX, 2 * MiniMapTracking:GetHeight() / 19 - 3)
    end
end

local function UpdateCornerIconsPosition()
    -- SexyMap places these in hybrid mode.
    if IsHybridMinimapModeActive() then return end

    UpdateMailPosition()

    local isSquare = IsSquareLayout()

    local difficulty = MiniMapInstanceDifficulty
    if difficulty then
        difficulty:ClearAllPoints()
        -- Forever hangs the banner over its day/night badge, which the square frame keeps in that corner.
        if isSquare and (not IsForeverLayout() or IsThinSquareBorder()) then
            difficulty:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", -4, -4)
            difficulty:SetScale(0.85)
        else
            if MinimapBorderTop then
                difficulty:SetPoint("TOP", MinimapBorderTop, 'BOTTOMRIGHT', -20, 6)
            else
                difficulty:SetPoint("TOPRIGHT", Minimap, 'TOPRIGHT', -20, 6)
            end
            difficulty:SetScale(0.85)
        end
    end

    local pvpButton = MiniMapBattlefieldFrame
    if pvpButton then
        pvpButton:ClearAllPoints()
        if isSquare then
            pvpButton:SetPoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", -4, 4)
        else
            pvpButton:SetPoint("BOTTOMLEFT", Minimap, "BOTTOMLEFT", 0, 18)
        end
    end
end

local function UpdateForeverStyle()
    local circle = Minimap and Minimap.Circle
    if not circle then return end

    UpdateCornerIconsPosition()

    local active = IsForeverActive()
    local square = IsSquareLayout()
    if active ~= (MinimapModule.foreverShown == true) then
        MinimapModule.foreverShown = active
        RescaleLaunchers()
    end

    local thin = IsThinSquareBorder()
    SyncThinSquareBorder()

    -- An empty ring rather than a hidden one: decorations and restores Show() the circle on their own.
    local rounded = addon.db.profile.minimap.forever_square_rounded == true
    local foreverSquare = rounded and FOREVER_SQUARE_FRAME_ROUNDED or FOREVER_SQUARE_FRAME
    local texture = (thin and "") or (active and (square and foreverSquare or FOREVER_MINIMAP_CIRCLE))
        or (square and DRAGONUI_SQUARE_FRAME or DRAGONUI_MINIMAP_CIRCLE)
    if MinimapModule.circleTexture ~= texture then
        MinimapModule.circleTexture = texture
        if thin then
            circle:SetTexture(nil)
        else
            circle:SetTexture(texture)
        end
        circle:SetTexCoord(0, 1, 0, 1)
        if foreverFrame then foreverFrame.pointer:SetTexCoord(0, 1, 0, 1) end
        -- Forces the rotation loop to re-aim whichever texture turns now.
        if MinimapModule.borderFrame then
            MinimapModule.borderFrame._duiLastAppliedAngle = nil
        end
    end

    if active then
        local frame = EnsureForeverFrame()
        local scale = ForeverScale()
        local ringSize = FOREVER_RING_SIZE * scale
        frame.pointer:SetTexture(square and FOREVER_SQUARE_POINTER or FOREVER_MINIMAP_POINTER)
        frame.pointer:SetSize(ringSize, ringSize)
        frame.pointer:SetSinglePoint("CENTER", Minimap, "CENTER", 0, 0)
        local squareDielX = rounded and FOREVER_SQUARE_ROUNDED_DIEL_X or FOREVER_SQUARE_DIEL_X
        local dielX = (square and squareDielX or FOREVER_DIEL_X) * scale
        local dielY = (square and FOREVER_SQUARE_DIEL_Y or FOREVER_DIEL_Y) * scale
        frame.dielRing:SetSize(FOREVER_DIEL_RING_SIZE * scale, FOREVER_DIEL_RING_SIZE * scale)
        frame.dielRing:SetSinglePoint("CENTER", Minimap, "CENTER", dielX, dielY)
        frame.dielIcon:SetSize(FOREVER_DIEL_ICON_SIZE * scale, FOREVER_DIEL_ICON_SIZE * scale)
        frame.dielIcon:SetSinglePoint("CENTER", Minimap, "CENTER", dielX, dielY)
    end

    local minimapConfig = addon.db and addon.db.profile and addon.db.profile.minimap
    local decorationsActive = minimapConfig and minimapConfig.animated_border_enabled == true
        and addon.MinimapDecorations and addon.MinimapDecorations.applied
    local hideBorder = decorationsActive and minimapConfig.animated_border_hide_dragonui_border == true
    if not hideBorder and not IsHybridMinimapModeActive() then
        circle:SetAlpha(1)
        circle:Show()
    end

    UpdateMinimapCircleSize()
    SyncForeverOverlay()
    SyncCornerIconLevels(active)
    UpdateZoomButtonsLayout()
    if square or GetCVar("rotateMinimap") ~= "1" then
        ResetRingRotation()
    end
    SyncLibDBIconShape()
end

local function GetStyleOffsets()
    -- No pointer or badge to make room for: the thin line hugs the zone bar like the plain style.
    local thin = IsForeverLayout() and IsSquareLayout() and addon.db.profile.minimap.forever_square_border == "thin"
    if thin then
        return 0, MAP_OFFSET_Y
    end
    if IsForeverLayout() then
        local drop = FOREVER_MAP_DROP
        if IsSquareLayout() and addon.db.profile.minimap.square_top_arrow == false then
            drop = drop - FOREVER_SQUARE_POINTERLESS_RISE
        end
        return FOREVER_CLUSTER_LIFT, MAP_OFFSET_Y - drop
    end
    if IsSquareLayout() then
        return 0, MAP_OFFSET_Y - DRAGONUI_SQUARE_MAP_DROP
    end
    return 0, MAP_OFFSET_Y
end

-- Farm mode grows the map from the screen corner it sits in, so a map at an edge grows inward.
local function GetMinimapGrowthPivot(mover)
    local settings = GetMinimapSettings()
    if not (mover and settings and settings.farm_mode_enabled == true) then return "CENTER" end
    local x, y = mover:GetCenter()
    local width, height = UIParent:GetWidth(), UIParent:GetHeight()
    if not (x and y and width and height and width > 0 and height > 0) then return "CENTER" end
    -- GetCenter answers in the mover's own scaled units.
    local ratio = mover:GetEffectiveScale() / UIParent:GetEffectiveScale()
    x, y = x * ratio / width, y * ratio / height
    local pivot = ((y > 2 / 3 and "TOP") or (y < 1 / 3 and "BOTTOM") or "")
        .. ((x > 2 / 3 and "RIGHT") or (x < 1 / 3 and "LEFT") or "")
    return pivot ~= "" and pivot or "CENTER"
end

-- Farm parks the zone bar, so the map alone hugs the box's edges, as far in as it sits at scale 1.
local function GetClusterGrowthShift(mover, clusterLift, mapOffsetY)
    local pivot = GetMinimapGrowthPivot(mover)
    if pivot == "CENTER" then return 0, 0 end
    local scale = MinimapCluster:GetEffectiveScale() / mover:GetEffectiveScale()
    local inward = mapUnscaledWidth * blipScale / 2 * (scale - 1) / scale
    local shiftX = (pivot:find("RIGHT") and -inward) or (pivot:find("LEFT") and inward) or 0
    local mapY = (pivot:find("TOP") and -inward) or (pivot:find("BOTTOM") and inward)
    return shiftX, mapY and mapY - clusterLift - mapOffsetY or 0
end

-- Live style switches and farm growth; ReplaceBlizzardFrame anchors both frames itself on every apply.
local function ApplyStyleAnchors()
    local mover = MinimapModule.minimapFrame
    if not mover then return end
    local clusterLift, mapOffsetY = GetStyleOffsets()
    local shiftX, shiftY = GetClusterGrowthShift(mover, clusterLift, mapOffsetY)
    if MinimapModule.appliedMapOffsetY == mapOffsetY and MinimapModule.appliedShiftX == shiftX
        and MinimapModule.appliedShiftY == shiftY then
        return
    end
    if InCombatLockdown() then
        addon.CombatQueue:Add("minimap_style_anchors", ApplyStyleAnchors)
        return
    end

    MinimapCluster:ClearAllPoints()
    MinimapCluster:SetPoint("CENTER", mover, "CENTER", shiftX, clusterLift + shiftY)
    -- Anchor offsets are read in the map's own scaled units.
    Minimap:ClearAllPoints()
    Minimap:SetPoint("CENTER", MinimapCluster, "CENTER", 0, mapOffsetY / blipScale)
    MinimapModule.appliedMapOffsetY = mapOffsetY
    MinimapModule.appliedShiftX, MinimapModule.appliedShiftY = shiftX, shiftY
end

-- SECURE HOOKS: Add secure hooks for critical functions
local function SetupSecureHooks()
    if MinimapModule.hooks.CloseDropDownMenus then
        return -- Already hooked
    end

    -- Secure hook for CloseDropDownMenus
    MinimapModule.hooks.CloseDropDownMenus = function()
        if not MinimapModule.applied then return end
        if MiniMapTrackingIcon and MiniMapTrackingIcon:GetAlpha() > 0 then
            MiniMapTrackingIcon:ClearAllPoints()
            MiniMapTrackingIcon:SetPoint('CENTER', MiniMapTracking, 'CENTER', TrackingPlateCenter())
        end
    end
    hooksecurefunc("CloseDropDownMenus", MinimapModule.hooks.CloseDropDownMenus)

    -- Secure hook for SetTracking
    MinimapModule.hooks.SetTracking = function()
        if MinimapModule.applied then
            MinimapModule:UpdateTrackingIcon()
        end
    end
    hooksecurefunc("SetTracking", MinimapModule.hooks.SetTracking)

    -- Hook for Minimap_UpdateRotationSetting if it exists
    -- Uses indirection via MinimapModule.UpdateRotation to avoid infinite recursion
    -- (calling the global from a post-hook would re-trigger the hook)
    if Minimap_UpdateRotationSetting then
        MinimapModule.hooks.Minimap_UpdateRotationSetting = function()
            if MinimapModule.applied and MinimapModule.UpdateRotation then
                MinimapModule.UpdateRotation()
            end
        end
        hooksecurefunc("Minimap_UpdateRotationSetting", MinimapModule.hooks.Minimap_UpdateRotationSetting)
    end
end

-- CLEANUP: Function for cleaning up hooks
-- Phase 3B: Use flag-based approach instead of clearing table
-- (hooksecurefunc can't be undone; clearing the table enables re-registration and duplication)
local function CleanupSecureHooks()
    MinimapModule.hooksDisabled = true
end

local function UpdateCalendarDate()
    local _, _, day = CalendarGetDate()
    if not day or day < 1 or day > 31 then
        return
    end

    local gameTimeFrame = GameTimeFrame
    if not gameTimeFrame then
        return
    end

    local normalTexture = gameTimeFrame:GetNormalTexture()
    if not normalTexture then
        return
    end
    normalTexture:SetAllPoints(gameTimeFrame)
    normalTexture:SetAtlasTexture('Minimap-Calendar-' .. day .. '-Normal', true)

    local highlightTexture = gameTimeFrame:GetHighlightTexture()
    if highlightTexture then
        AnchorPushedHighlight(gameTimeFrame, gameTimeFrame)
        highlightTexture:SetAtlasTexture('Minimap-Calendar-' .. day .. '-Highlight', true)
    end

    local pushedTexture = gameTimeFrame:GetPushedTexture()
    if pushedTexture then
        pushedTexture:SetAllPoints(gameTimeFrame)
        pushedTexture:SetAtlasTexture('Minimap-Calendar-' .. day .. '-Pushed', true)
    end
end

local durabilityMover
local durabilityCaptureBarActive = false

local function GetDurabilityConfig()
    local widgets = addon.db and addon.db.profile and addon.db.profile.widgets
    return widgets and widgets.durability
end

local function IsDurabilityCustomPlaced()
    local cfg = GetDurabilityConfig()
    return durabilityMover ~= nil and cfg ~= nil and cfg.custom_position == true
end

local function ApplyDurabilityPosition()
    local durabilityFrame = DurabilityFrame
    if not durabilityFrame or durabilityFrame.DragonUI_SettingPoint then return end
    durabilityFrame.DragonUI_SettingPoint = true
    durabilityFrame:ClearAllPoints()
    if IsDurabilityCustomPlaced() then
        durabilityFrame:SetPoint("CENTER", durabilityMover, "CENTER", 0, 0)
    elseif durabilityCaptureBarActive then
        durabilityFrame:SetPoint("TOP", Minimap, "BOTTOM", -15, -35)
    else
        durabilityFrame:SetPoint("TOP", Minimap, "BOTTOM", -15, -5)
    end
    durabilityFrame.DragonUI_SettingPoint = nil
end

local function UpdateDurabilityPosition(captureBarVisible)
    durabilityCaptureBarActive = captureBarVisible and true or false
    ApplyDurabilityPosition()
end

local function SyncDurabilityMover()
    if not durabilityMover or not DurabilityFrame then return end
    local ratio = DurabilityFrame:GetEffectiveScale() / UIParent:GetEffectiveScale()
    durabilityMover:SetSize(DurabilityFrame:GetWidth() * ratio, DurabilityFrame:GetHeight() * ratio)
    local cfg = GetDurabilityConfig()
    if cfg and cfg.custom_position then
        local anchor = cfg.anchor or "CENTER"
        durabilityMover:ClearAllPoints()
        durabilityMover:SetPoint(anchor, UIParent, anchor, cfg.posX or 0, cfg.posY or 0)
    end
end

-- Snapshot coordinates, never anchor to DurabilityFrame: it anchors to the mover once detached.
local function SnapDurabilityMoverToFigure()
    local cx, cy = DurabilityFrame:GetCenter()
    local ux, uy = UIParent:GetCenter()
    durabilityMover:ClearAllPoints()
    if cx and cy and ux and uy then
        local ratio = DurabilityFrame:GetEffectiveScale() / UIParent:GetEffectiveScale()
        durabilityMover:SetPoint("CENTER", UIParent, "CENTER", cx * ratio - ux, cy * ratio - uy)
    else
        durabilityMover:SetPoint("TOP", Minimap, "BOTTOM", 0, 0)
    end
end

-- The snapshot goes stale when the minimap moves or rescales in the editor while the figure is attached.
local durabilityFollower = CreateFrame("Frame")
durabilityFollower:Hide()
durabilityFollower:SetScript("OnUpdate", function(self)
    if not (addon.EditorMode and addon.EditorMode:IsActive()) then
        self:Hide()
        return
    end
    if IsDurabilityCustomPlaced() then return end
    local cx, cy = DurabilityFrame:GetCenter()
    local scale = DurabilityFrame:GetEffectiveScale()
    if cx == self.cx and cy == self.cy and scale == self.scale then return end
    self.cx, self.cy, self.scale = cx, cy, scale
    SyncDurabilityMover()
    SnapDurabilityMoverToFigure()
end)

local function DetachDurabilityFrame()
    local widgets = addon.db and addon.db.profile and addon.db.profile.widgets
    if not widgets then return end
    widgets.durability = widgets.durability or {}
    widgets.durability.custom_position = true
    ApplyDurabilityPosition()
end

local function ReplaceBlizzardFrame(frame)
    -- Check combat lockdown before making secure frame changes
    if InCombatLockdown() then
        addon.CombatQueue:Add("minimap_replace_blizzard_frame", ReplaceBlizzardFrame, frame)
        return
    end

    -- Store original states before modification
    if not MinimapModule.originalStates.MinimapCluster then
        MinimapModule.originalStates.MinimapCluster = {
            points = {},
            scale = MinimapCluster:GetScale()
        }
        for i = 1, MinimapCluster:GetNumPoints() do
            MinimapModule.originalStates.MinimapCluster.points[i] = {MinimapCluster:GetPoint(i)}
        end
    end

    -- Store DurabilityFrame original state
    if DurabilityFrame and not MinimapModule.originalStates.DurabilityFrame then
        MinimapModule.originalStates.DurabilityFrame = {
            points = {},
            scale = DurabilityFrame:GetScale()
        }
        for i = 1, DurabilityFrame:GetNumPoints() do
            MinimapModule.originalStates.DurabilityFrame.points[i] = {DurabilityFrame:GetPoint(i)}
        end
    end

    local clusterLift, mapOffsetY = GetStyleOffsets()
    MinimapModule.appliedMapOffsetY = mapOffsetY

    local minimapCluster = MinimapCluster
    minimapCluster:ClearAllPoints()
    minimapCluster:SetPoint("CENTER", frame, "CENTER", 0, clusterLift)
    -- Blizzard caps UIPanels at a minimap still in its place; ours can be anywhere.
    minimapCluster:SetMovable(true)
    minimapCluster:SetDontSavePosition(true)
    minimapCluster:SetUserPlaced(true)
    MinimapModule.appliedShiftX, MinimapModule.appliedShiftY = 0, 0

    -- In hybrid mode with SexyMap, skip border/zone text customization
    -- SexyMap handles: borders, zone text styling, shapes
    -- DragonUI handles: positioning, tracking icons, calendar, POI textures
    local isHybridMode = MinimapModule.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))

    if not isHybridMode then
        -- DragonUI border top styling (skipped in hybrid mode)
        local minimapBorderTop = MinimapBorderTop
        minimapBorderTop:ClearAllPoints()
        minimapBorderTop:SetPoint("TOP", 0, 5)
        minimapBorderTop:SetAtlasTexture('Minimap-Border-Top', true)
        minimapBorderTop:SetSize(156, 20)

        local minimapZoneButton = MinimapZoneTextButton
        minimapZoneButton:ClearAllPoints()
        minimapZoneButton:SetPoint("LEFT", minimapBorderTop, "LEFT", 7, 1)
        minimapZoneButton:SetWidth(108)

        minimapZoneButton:EnableMouse(true)
        minimapZoneButton:SetScript("OnMouseUp", function(self, button)
            if button == "LeftButton" then
                if WorldMapFrame:IsShown() then
                    HideUIPanel(WorldMapFrame)
                else
                    ShowUIPanel(WorldMapFrame)
                end
            end
        end)

        local minimapZoneText = MinimapZoneText
        minimapZoneText:SetAllPoints(minimapZoneButton)
        minimapZoneText:SetJustifyH("LEFT")
    else
        -- In hybrid mode, only add the click handler for world map (SexyMap handles styling)
        MinimapZoneTextButton:EnableMouse(true)
        MinimapZoneTextButton:SetScript("OnMouseUp", function(self, button)
            if button == "LeftButton" then
                if WorldMapFrame:IsShown() then
                    HideUIPanel(WorldMapFrame)
                else
                    ShowUIPanel(WorldMapFrame)
                end
            end
        end)
    end

    if not isHybridMode then
        -- DragonUI clock/calendar positioning (anchored to DragonUI's border top)
        local timeClockButton = TimeManagerClockButton
        timeClockButton:GetRegions():Hide()
        timeClockButton:ClearAllPoints()
        timeClockButton:SetPoint("RIGHT", MinimapBorderTop, "RIGHT", -5, 0)
        timeClockButton:SetWidth(30)

        local gameTimeFrame = GameTimeFrame
        gameTimeFrame:ClearAllPoints()
        gameTimeFrame:SetPoint("LEFT", MinimapBorderTop, "RIGHT", 3, -1)
        gameTimeFrame:SetSize(26, 24)
        gameTimeFrame:SetHitRectInsets(0, 0, 0, 0)
        gameTimeFrame:GetFontString():Hide()

        UpdateCalendarDate()

        -- Blizzard refreshes calendar visuals on several events; re-apply our atlas after each update.
        if not gameTimeFrame.DragonUI_CalendarHooked then
            gameTimeFrame.DragonUI_CalendarHooked = true
            gameTimeFrame:HookScript("OnEvent", function()
                if MinimapModule.applied then
                    UpdateCalendarDate()
                end
            end)
            gameTimeFrame:HookScript("OnShow", function()
                if MinimapModule.applied then
                    UpdateCalendarDate()
                end
            end)
            gameTimeFrame:HookScript("OnMouseDown", function(self)
                if MinimapModule.applied then
                    AnchorPushedHighlight(self, self, true)
                    -- GetButtonState lags the mouse events by a frame.
                    addon:After(0, function() AnchorPushedHighlight(self, self) end)
                end
            end)
            gameTimeFrame:HookScript("OnMouseUp", function(self)
                if MinimapModule.applied then
                    addon:After(0, function() AnchorPushedHighlight(self, self) end)
                end
            end)
            -- Released off the button, OnMouseUp never arrives; resync before the highlight shows again.
            gameTimeFrame:HookScript("OnEnter", function(self)
                if MinimapModule.applied then
                    AnchorPushedHighlight(self, self)
                end
            end)
        end
    end

    -- Configure DurabilityFrame properly
    local durabilityFrame = DurabilityFrame
    if durabilityFrame then
        ApplyDurabilityPosition()
        -- Adjust scale to match the minimap
        durabilityFrame:SetScale(3 / blipScale)
    end

    -- Hook DurabilityFrame:SetPoint to prevent Blizzard from overriding our position
    if durabilityFrame and not durabilityFrame._dragonUISetPointHooked then
        hooksecurefunc(durabilityFrame, "SetPoint", ApplyDurabilityPosition)
        durabilityFrame._dragonUISetPointHooked = true
    end

    local minimapBattlefieldFrame = MiniMapBattlefieldFrame
    minimapBattlefieldFrame:ClearAllPoints()
    minimapBattlefieldFrame:SetPoint("BOTTOMLEFT", 8, 2)

    if not isHybridMode then
        -- DragonUI positioning for elements anchored to the border top
        local minimapInstanceFrame = MiniMapInstanceDifficulty
        minimapInstanceFrame:ClearAllPoints()
        minimapInstanceFrame:SetPoint("TOP", MinimapBorderTop, 'BOTTOMRIGHT', -20, 6)
        minimapInstanceFrame:SetScale(0.85) -- Fixed scale for difficulty icon

        local minimapTracking = MiniMapTracking
        minimapTracking:ClearAllPoints()
        -- Mirrors the calendar's gap: the plate stops 3 cell px short of this frame's right edge.
        minimapTracking:SetPoint("RIGHT", MinimapBorderTop, "LEFT", -3 + 3 * 26 / 21, -1)
        minimapTracking:SetSize(26, 24)

        local minimapMailFrame = MiniMapMailFrame
        minimapMailFrame:SetSize(20, 14)
        minimapMailFrame:SetHitRectInsets(0, 0, 0, 0)
        UpdateCornerIconsPosition()

        local minimapMailIconTexture = MiniMapMailIcon
        minimapMailIconTexture:SetAllPoints(minimapMailFrame)
        minimapMailIconTexture:SetAtlasTexture('Minimap-Mail-Normal', true)

        local backgroundTexture = _G[minimapTracking:GetName() .. "Background"]
        backgroundTexture:SetAllPoints(minimapTracking)
        backgroundTexture:SetAtlasTexture('Minimap-Tracking-Background', true)

        local minimapTrackingButton = _G[minimapTracking:GetName() .. 'Button']
        minimapTrackingButton:ClearAllPoints()
        minimapTrackingButton:SetPoint("CENTER", minimapTracking, "CENTER", TrackingPlateCenter())

        -- 17x15 binoculars plus room for the press shift (gen_minimap_tracking.py).
        minimapTrackingButton:SetSize(20, 18)
        minimapTrackingButton:SetHitRectInsets(0, 0, 0, 0)

        -- Left clicks stay Blizzard's own OnClick: the tracking menu must open from secure code.
        minimapTrackingButton:RegisterForClicks("LeftButtonUp")

        local shineTexture = _G[minimapTrackingButton:GetName() .. "Shine"]
        shineTexture:SetTexture(nil)

        local normalTexture = minimapTrackingButton:GetNormalTexture() or minimapTrackingButton:CreateTexture(nil, "BORDER")
        normalTexture:SetAllPoints(minimapTrackingButton)
        normalTexture:SetAtlasTexture('Minimap-Tracking-Normal', true)

        minimapTrackingButton:SetNormalTexture(normalTexture)

        local highlightTexture = minimapTrackingButton:GetHighlightTexture()
        highlightTexture:SetAllPoints(minimapTrackingButton)
        highlightTexture:SetAtlasTexture('Minimap-Tracking-Highlight', true)

        local pushedTexture = minimapTrackingButton:GetPushedTexture() or minimapTrackingButton:CreateTexture(nil, "BORDER")
        pushedTexture:SetAllPoints(minimapTrackingButton)
        pushedTexture:SetAtlasTexture('Minimap-Tracking-Pushed', true)

        minimapTrackingButton:SetPushedTexture(pushedTexture)
    end
    -- else: In hybrid mode, SexyMap's Buttons module handles tracking/mail positioning

    -- Resolve minimapTrackingButton at outer scope for click scripts below
    -- (the local above is only in the non-hybrid block)
    local minimapTrackingButton = _G[MiniMapTracking:GetName() .. 'Button']

    local minimapFrame = Minimap
    minimapFrame:ClearAllPoints()
    minimapFrame:SetPoint("CENTER", minimapCluster, "CENTER", 0, mapOffsetY)
    minimapFrame:SetScale(blipScale)
    minimapFrame:SetSize(mapUnscaledWidth, mapUnscaledHeight)
    MinimapModule.activeMinimapScale = blipScale

    -- In hybrid mode, don't override SexyMap's mask (it controls shape)
    if not isHybridMode then
        UpdateMinimapMaskForRotation()
    end

    -- POI (Point of Interest) Custom Textures
    minimapFrame:SetStaticPOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-static")
    minimapFrame:SetCorpsePOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-corpse")
    minimapFrame:SetPOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-guard")
    minimapFrame:SetPlayerTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-player")

    -- Player arrow size (configurable)
    local playerArrowSize = addon.db and addon.db.profile and addon.db.profile.minimap and
                                addon.db.profile.minimap.player_arrow_size or 16
    minimapFrame:SetPlayerTextureHeight(playerArrowSize)
    minimapFrame:SetPlayerTextureWidth(playerArrowSize)

    -- Blip texture (configurable: new DragonUI icons vs old Blizzard icons)
    local useNewBlipStyle = addon.db and addon.db.profile and addon.db.profile.minimap and
                                addon.db.profile.minimap.blip_skin
    if useNewBlipStyle == nil then
        useNewBlipStyle = true -- Default to new style
    end

    local blipTexture = useNewBlipStyle and "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\objecticons" or
                            'Interface\\Minimap\\ObjectIcons'
    minimapFrame:SetBlipTexture(blipTexture)

    -- =====================================================================
    -- BLIP TEXTURE PROTECTION: Override SetBlipTexture with a filter wrapper.
    -- Uses method override (pre-hook) instead of hooksecurefunc (post-hook)
    -- to intercept BEFORE the texture changes, eliminating any flicker from
    -- addons like Carbonite that call SetBlipTexture on a repeating timer.
    -- =====================================================================
    if not MinimapModule.hooks.SetBlipTexture then
        -- Public function: re-applies all DragonUI minimap textures
        -- Called by compatibility module after conflicting addons load
        MinimapModule.ReapplyMinimapTextures = function()
            local useNew = addon.db and addon.db.profile and addon.db.profile.minimap and
                               addon.db.profile.minimap.blip_skin
            if useNew == nil then useNew = true end

            local tex = useNew and "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\objecticons" or
                            'Interface\\Minimap\\ObjectIcons'

            MinimapModule._settingBlipTexture = true
            Minimap:SetBlipTexture(tex)
            MinimapModule._settingBlipTexture = false

            -- Re-apply POI textures (Carbonite resets these on init)
            Minimap:SetStaticPOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-static")
            Minimap:SetCorpsePOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-corpse")
            Minimap:SetPOIArrowTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-guard")
            Minimap:SetPlayerTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\poi-player")
            -- Only re-apply mask if not in hybrid mode (SexyMap controls the mask/shape)
            local hybridCheck = MinimapModule.sexyMapHybridMode
                or (addon.db and addon.db.profile and addon.db.profile.modules
                    and addon.db.profile.modules.minimap
                    and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))
            if not hybridCheck then
                UpdateMinimapMaskForRotation()
            end
        end

        -- Override SetBlipTexture: blocks external calls when our custom blip skin is active,
        -- passes through when using classic style or module is disabled
        local origSetBlipTexture = Minimap.SetBlipTexture
        Minimap.SetBlipTexture = function(self, texture)
            -- DragonUI's own calls always pass through
            if MinimapModule._settingBlipTexture then
                return origSetBlipTexture(self, texture)
            end
            -- If module is active with custom blip skin, block external changes
            if IsModuleEnabled() and MinimapModule.applied then
                local useNew = addon.db and addon.db.profile and addon.db.profile.minimap
                                   and addon.db.profile.minimap.blip_skin
                if useNew then
                    return -- Block: keep our custom texture
                end
            end
            -- Module disabled or classic blip style: let it through
            return origSetBlipTexture(self, texture)
        end
        MinimapModule.hooks.SetBlipTexture = true
        MinimapModule._origSetBlipTexture = origSetBlipTexture
    end

    do
        local childScale = 1 / blipScale
        local launcherScale = GetLauncherScale()
        local listed, mapChildren = pcall(function() return { minimapFrame:GetChildren() } end)
        for _, child in ipairs(listed and mapChildren or {}) do
            if child ~= WatchFrame then
                local isLauncher = child:GetObjectType() == "Button" and not IsFrameWhitelisted(child:GetName())
                child:SetScale(isLauncher and launcherScale or childScale)
                if isLauncher then
                    MinimapModule.launcherButtons[child] = true
                end
            end
        end

        -- Anchor offsets are read in the map's own scaled units, so the scale is divided back out.
        local function ShrinkAnchor(point, relativeTo, relativePoint, x, y)
            return { point, relativeTo, relativePoint, (x or 0) / blipScale, (y or 0) / blipScale }
        end
        local anchors = {}
        for index = 1, minimapFrame:GetNumPoints() do
            anchors[#anchors + 1] = ShrinkAnchor(minimapFrame:GetPoint(index))
        end
        minimapFrame:ClearAllPoints()
        for _, anchor in ipairs(anchors) do
            minimapFrame:SetPoint(unpack(anchor, 1, 5))
        end

        if not isHybridMode then
            _G.GetMinimapShape = function()
                return IsSquareLayout() and "SQUARE" or "ROUND"
            end
        end
    end

    -- Enable mouse wheel zooming on minimap
    minimapFrame:EnableMouseWheel(true)
    minimapFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            -- Scroll up = Zoom in
            Minimap_ZoomIn()
        else
            -- Scroll down = Zoom out
            Minimap_ZoomOut()
        end
    end)

    -- In hybrid mode, don't touch MinimapBackdrop, border, circle, or zoom button skins
    -- SexyMap controls all visual elements; DragonUI only handles positioning
    if not isHybridMode then
        local minimapBackdropTexture = MinimapBackdrop
        minimapBackdropTexture:ClearAllPoints()
        minimapBackdropTexture:SetPoint("CENTER", minimapFrame, "CENTER", 0, 3)
        MinimapModule.backdropYOffset = 3

        local minimapBorderTexture = MinimapBorder
        minimapBorderTexture:Hide()
        if not Minimap.Circle then
            Minimap.Circle = MinimapBackdrop:CreateTexture(nil, 'ARTWORK')
            Minimap.Circle:SetTexture(DRAGONUI_MINIMAP_CIRCLE)
            HookForeverMirror(Minimap.Circle)
        end
        -- A restore hid it; decorations re-hide it in UpdateSettings if they own the border.
        Minimap.Circle:Show()
        UpdateMinimapCircleSize()
        UpdateForeverStyle()

        local zoomInButton = MinimapZoomIn
        zoomInButton:SetHitRectInsets(0, 0, 0, 0)

        local normalTexture = zoomInButton:GetNormalTexture()
        normalTexture:SetAllPoints(zoomInButton)
        normalTexture:SetAtlasTexture('Minimap-ZoomIn-Normal', true)

        local highlightTexture = zoomInButton:GetHighlightTexture()
        highlightTexture:SetAllPoints(zoomInButton)
        highlightTexture:SetAtlasTexture('Minimap-ZoomIn-Highlight', true)

        local pushedTexture = zoomInButton:GetPushedTexture()
        pushedTexture:SetAllPoints(zoomInButton)
        pushedTexture:SetAtlasTexture('Minimap-ZoomIn-Pushed', true)

        local disabledTexture = zoomInButton:GetDisabledTexture()
        disabledTexture:SetAllPoints(zoomInButton)
        disabledTexture:SetAtlasTexture('Minimap-ZoomIn-Pushed', true)

        local zoomOutButton = MinimapZoomOut
        zoomOutButton:SetHitRectInsets(0, 0, 0, 0)

        local normalTexture = zoomOutButton:GetNormalTexture()
        normalTexture:SetAllPoints(zoomOutButton)
        normalTexture:SetAtlasTexture('Minimap-ZoomOut-Normal', true)

        local highlightTexture = zoomOutButton:GetHighlightTexture()
        highlightTexture:SetAllPoints(zoomOutButton)
        highlightTexture:SetAtlasTexture('Minimap-ZoomOut-Highlight', true)

        local pushedTexture = zoomOutButton:GetPushedTexture()
        pushedTexture:SetAllPoints(zoomOutButton)
        pushedTexture:SetAtlasTexture('Minimap-ZoomOut-Pushed', true)

        local disabledTexture = zoomOutButton:GetDisabledTexture()
        disabledTexture:SetAllPoints(zoomOutButton)
        disabledTexture:SetAtlasTexture('Minimap-ZoomOut-Pushed', true)

        UpdateZoomButtonsLayout()
    end -- not isHybridMode (backdrop, border, circle, zoom buttons)

    -- Reposition a single WorldStateCaptureBar to below the minimap
    local function RepositionCaptureBar(bar)
        if not bar then return end
        if not bar._dragonUISetPointHooked then
            -- Post-hook SetPoint to re-apply our positioning after any Blizzard repositioning
            hooksecurefunc(bar, "SetPoint", function(self, point, relativeTo, relativePoint)
                if not (point == 'CENTER' and relativeTo == minimapFrame and relativePoint == 'BOTTOM') then
                    if not self.DragonUI_SettingPoint then
                        self.DragonUI_SettingPoint = true
                        self:ClearAllPoints()
                        self:SetPoint('CENTER', minimapFrame, 'BOTTOM', 0, -20)
                        self.DragonUI_SettingPoint = nil
                    end
                end
            end)
            -- Hook Show/Hide to update durability position dynamically
            hooksecurefunc(bar, "Show", function() UpdateDurabilityPosition(true) end)
            hooksecurefunc(bar, "Hide", function() UpdateDurabilityPosition(false) end)
            -- OnHide fires after the frame is actually hidden (more reliable than Hide hook)
            bar:HookScript("OnHide", function() UpdateDurabilityPosition(false) end)
            bar:HookScript("OnShow", function() UpdateDurabilityPosition(true) end)
            bar._dragonUISetPointHooked = true
        end
        -- Always force our position (safe even with the hook's recursion guard)
        if not bar.DragonUI_SettingPoint then
            bar.DragonUI_SettingPoint = true
            bar:ClearAllPoints()
            bar:SetPoint('CENTER', minimapFrame, 'BOTTOM', 0, -20)
            bar.DragonUI_SettingPoint = nil
        end
    end

    -- Check and reposition all capture bars (there can be multiple in some BGs)
    local function SetupWorldStateCaptureBar()
        local anyVisible = false
        for i = 1, 5 do
            local bar = _G['WorldStateCaptureBar' .. i]
            if bar then
                RepositionCaptureBar(bar)
                if bar:IsVisible() then
                    anyVisible = true
                end
            end
        end
        -- Update durability frame position based on capture bar visibility
        UpdateDurabilityPosition(anyVisible)
        return anyVisible
    end

    -- Try to setup immediately (frame rarely exists at load time)
    SetupWorldStateCaptureBar()

    -- Hook UIParent_ManageFramePositions -Blizzard calls this AFTER creating/repositioning
    -- capture bars, so by the time our post-hook runs the frame is guaranteed to exist
    if UIParent_ManageFramePositions then
        hooksecurefunc("UIParent_ManageFramePositions", SetupWorldStateCaptureBar)
    end

    -- Also listen for key events as a safety net
    local captureBarWatcher = CreateFrame("Frame")
    local captureBarDelayFrame = CreateFrame("Frame")
    local captureBarDelayElapsed = 0
    local captureBarDelayRetries = 0
    captureBarWatcher:RegisterEvent("UPDATE_WORLD_STATES")
    captureBarWatcher:RegisterEvent("PLAYER_ENTERING_WORLD")
    captureBarWatcher:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    captureBarWatcher:RegisterEvent("ZONE_CHANGED")
    captureBarWatcher:SetScript("OnEvent", function(self, event)
        SetupWorldStateCaptureBar()
        -- After reload/login, capture bars may not exist yet -do delayed re-checks
        if event == "PLAYER_ENTERING_WORLD" then
            captureBarDelayElapsed = 0
            captureBarDelayRetries = 0
            captureBarDelayFrame:SetScript("OnUpdate", function(delaySelf, dt)
                captureBarDelayElapsed = captureBarDelayElapsed + dt
                if captureBarDelayElapsed >= 0.5 then
                    captureBarDelayElapsed = 0
                    captureBarDelayRetries = captureBarDelayRetries + 1
                    SetupWorldStateCaptureBar()
                    -- Stop after 5 retries (2.5 seconds total)
                    if captureBarDelayRetries >= 5 then
                        delaySelf:SetScript("OnUpdate", nil)
                    end
                end
            end)
        end
    end)

    -- In hybrid mode, don't override tracking button scripts -SexyMap's Buttons module handles them
    if not isHybridMode then
        --  MANUALLY CONTROL BUTTON MOVEMENT
        minimapTrackingButton:SetScript("OnMouseDown", function(self, button)
            AnchorPushedHighlight(self, MiniMapTracking, true)
            -- GetButtonState lags the mouse events by a frame.
            addon:After(0, function() AnchorPushedHighlight(self, MiniMapTracking) end)
            if button == "LeftButton" then
                -- Old style's tracking icon gets the same press shift as the pushed art.
                if MiniMapTrackingIcon and MiniMapTrackingIcon:GetAlpha() > 0 then
                    MiniMapTrackingIcon:ClearAllPoints()
                    MiniMapTrackingIcon:SetPoint('CENTER', MiniMapTracking, 'CENTER', TrackingPlateCenter(true))
                end
            end
        end)

        minimapTrackingButton:SetScript("OnMouseUp", function(self, button)
            addon:After(0, function() AnchorPushedHighlight(self, MiniMapTracking) end)
            if button == "LeftButton" then
                -- Restore original position on release
                if MiniMapTrackingIcon and MiniMapTrackingIcon:GetAlpha() > 0 then
                    MiniMapTrackingIcon:ClearAllPoints()
                    MiniMapTrackingIcon:SetPoint('CENTER', MiniMapTracking, 'CENTER', TrackingPlateCenter())
                end
            elseif button == "RightButton" and self:IsMouseOver() then
                SetTracking()
                MinimapModule:UpdateTrackingIcon()
            end
        end)

        if not minimapTrackingButton.DragonUI_PushedHighlightHooked then
            minimapTrackingButton.DragonUI_PushedHighlightHooked = true
            minimapTrackingButton:HookScript("OnEnter", function(self)
                if not MinimapModule.applied then return end
                -- Released off the button, OnMouseUp never arrives; resync before the highlight shows again.
                AnchorPushedHighlight(self, MiniMapTracking)
                -- Blizzard's ANCHOR_RIGHT lays the tooltip over the icon and the zone bar; Retail opens it left.
                GameTooltip:SetOwner(self, "ANCHOR_NONE")
                GameTooltip:SetPoint("TOPRIGHT", MiniMapTracking, "TOPLEFT", -2, 0)
                GameTooltip:SetTracking()
            end)
        end

        --  HOOK TO RESET ICON POSITION AFTER CLICKS
    end -- not isHybridMode (tracking button scripts)

    -- Setup secure hooks after frame modifications (handles CloseDropDownMenus)
    SetupSecureHooks()

end -- End of ReplaceBlizzardFrame function

local function CreateMinimapBorderFrame(width, height)
    -- The original signature was CreateFrame('Frame', UIParent), which passed UIParent as
    -- the global `name` (not the parent). That left the border frame orphaned: without an
    -- explicit parent it never inherits UIParent's effective scale, so the client's UI Scale
    -- slider (useUiScale) leaves the square border visually frozen while the rest of the
    -- UI rescales. Pass UIParent as the third argument to actually parent it.
    local minimapBorderFrame = CreateFrame('Frame', nil, UIParent)
    minimapBorderFrame:SetSize(width, height)
    minimapBorderFrame._duiHeavyUpdateElapsed = 0
    minimapBorderFrame._duiRotationElapsed = 0
    minimapBorderFrame._duiLastRotateEnabled = nil
    minimapBorderFrame._duiLastAppliedAngle = nil
    minimapBorderFrame:SetScript("OnUpdate", function(self, elapsed)
        if not IsDragonUIMinimapControlling() then return end

        local rotateEnabled = GetCVar("rotateMinimap") == "1"
        local rotationInterval = rotateEnabled and 0.016 or 0.05

        self._duiRotationElapsed = self._duiRotationElapsed + elapsed
        if self._duiRotationElapsed >= rotationInterval then
            self._duiRotationElapsed = 0

            local facing = GetPlayerFacing()
            if Minimap and Minimap.Circle and facing then
                if rotateEnabled then
                    local desiredAngle = -facing
                    local shouldApply = true

                    if self._duiLastAppliedAngle then
                        local delta = math.abs(desiredAngle - self._duiLastAppliedAngle)
                        if delta > math.pi then
                            delta = (2 * math.pi) - delta
                        end
                        -- Skip tiny angle changes to keep CPU stable while preserving smoothness.
                        shouldApply = delta >= 0.0025
                    end

                    if shouldApply then
                        RotateRing(desiredAngle)
                        self._duiLastAppliedAngle = desiredAngle
                    end
                elseif self._duiLastRotateEnabled then
                    ResetRingRotation()
                    self._duiLastAppliedAngle = nil
                end
            end

            self._duiLastRotateEnabled = rotateEnabled
        end

        self._duiHeavyUpdateElapsed = self._duiHeavyUpdateElapsed + elapsed
        if self._duiHeavyUpdateElapsed >= 0.1 then
            self._duiHeavyUpdateElapsed = 0
            UpdateMinimapMaskForRotation()
            UpdateMinimapBackdropAlignment(false)
            UpdateIndoorRotateScale()
            UpdateMinimapCircleSize()
        end
    end)

    do
        local texture = minimapBorderFrame:CreateTexture(nil, "BORDER")
        texture:SetAllPoints(minimapBorderFrame)
        texture:SetTexture("Interface\\AddOns\\DragonUI\\Textures\\Minimap\\MinimapBorder.blp")
        texture:SetAlpha(0)

        minimapBorderFrame.border = texture
    end

    minimapBorderFrame:Hide()
    return minimapBorderFrame
end

-- Helper: is addon button fade currently enabled?
local function IsFadeEnabled()
    return addon.db and addon.db.profile and addon.db.profile.minimap
        and addon.db.profile.minimap.addon_button_fade or false
end

-- Collector buttons should stay fully visible inside the collector box.
local function IsInsideCollector(button)
    local collector = MinimapModule.frames and MinimapModule.frames.iconCollector
    return collector and button and button:GetParent() == collector
end

-- Blizzard's fade helpers share one global table of fading frames; securecall keeps it untainted.
local function FadeAddonButton(frame, helperName, targetAlpha)
    if IsInsideCollector(frame) then
        frame:SetAlpha(1)
    elseif IsFadeEnabled() then
        securecall(helperName, frame, 0.2, frame:GetAlpha(), targetAlpha)
    end
end

local function fadein(frame)
    FadeAddonButton(frame, "UIFrameFadeIn", 1)
end

local function fadeout(frame)
    FadeAddonButton(frame, "UIFrameFadeOut", 0.2)
end

local ADDON_ICON_RING = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\border_buttons.tga"
local ADDON_ICON_FADE_SCRIPTS = { OnEnter = fadein, OnLeave = fadeout }

-- Returns the size factor the current style draws button rings at; sizes the ring too when given one.
local function DressButtonRing(ring, side)
    local growth = 1
    if IsForeverActive() then
        ring:SetAtlasTexture(FOREVER_BUTTON_RING_ATLAS)
        growth = FOREVER_BUTTON_RING_GROWTH
    else
        ring:SetTexture(ADDON_ICON_RING)
        ring:SetTexCoord(0, 1, 0, 1)
    end
    if side then
        ring:SetSize(side * growth, side * growth)
    end
    return growth
end
local DECORATION_PATH_WORDS = { "Border", "Background", "AlphaMask" }
local addonIconLayouts = {}

local function IsTextureRegion(region)
    return region ~= nil and region:GetObjectType() == "Texture"
end

local function IsDecorationTexture(region)
    local path = tostring(region:GetTexture() or "")
    for _, word in ipairs(DECORATION_PATH_WORDS) do
        if path:find(word, 1, true) then return true end
    end
    return false
end

-- UnskinAddonButton restores from exactly these fields.
local function SnapshotRegion(region)
    local anchors = {}
    for index = 1, region:GetNumPoints() do
        local point, relativeTo, relativePoint, x, y = region:GetPoint(index)
        anchors[index] = { point, relativeTo, relativePoint, x, y }
    end
    region.DragonUI_OrigPoints = anchors
    region.DragonUI_OrigW, region.DragonUI_OrigH = region:GetSize()
    region.DragonUI_OrigLayer = region:GetDrawLayer()
    region.DragonUI_OrigAlpha = region:GetAlpha()
    region.DragonUI_OrigTexCoord = { region:GetTexCoord() }
end

local function BuildAddonIconLayout(button)
    button.DragonUI_Skinned = true
    button.DragonUI_OrigW, button.DragonUI_OrigH = button:GetSize()

    local normal, pushed = button:GetNormalTexture(), button:GetPushedTexture()
    local stateful = (normal and pushed and normal:GetTexture() and pushed:GetTexture()) and true or false
    button.DragonUI_UsesStateTextures = stateful

    local icons, highlights, decorations, snapshotted = {}, {}, {}, {}
    local function Adopt(region, list)
        if snapshotted[region] then return end
        snapshotted[region] = true
        SnapshotRegion(region)
        list[#list + 1] = region
    end

    for _, region in ipairs({ button:GetRegions() }) do
        if IsTextureRegion(region) then
            if region:GetDrawLayer() == "HIGHLIGHT" then
                Adopt(region, highlights)
            elseif IsDecorationTexture(region) then
                region.DragonUI_OrigAlpha = region:GetAlpha()
                decorations[#decorations + 1] = region
            else
                Adopt(region, icons)
            end
        end
    end
    if IsTextureRegion(normal) then Adopt(normal, icons) end
    if IsTextureRegion(pushed) then Adopt(pushed, icons) end
    local hover = button:GetHighlightTexture()
    if IsTextureRegion(hover) then Adopt(hover, highlights) end

    button.DragonUI_IconRegions = icons
    button.DragonUI_HighlightRegions = highlights
    button.DragonUI_DecoRegions = decorations

    local layout = { primary = icons, extra = {} }
    if stateful and IsTextureRegion(normal) then
        layout.primary = { normal, IsTextureRegion(pushed) and pushed or nil }
        for _, region in ipairs(icons) do
            if region ~= normal and region ~= pushed then
                layout.extra[#layout.extra + 1] = region
            end
        end
    end
    addonIconLayouts[button] = layout

    local ring = button:CreateTexture(nil, "OVERLAY")
    ring:SetTexture(ADDON_ICON_RING)
    ring:SetPoint("CENTER", button, "CENTER")
    ring:SetWidth(23)
    ring:SetHeight(23)
    button.circle = ring

    if not button.DragonUI_FadeHooked then
        button.DragonUI_FadeHooked = true
        for scriptName, handler in pairs(ADDON_ICON_FADE_SCRIPTS) do
            button:HookScript(scriptName, handler)
        end
    end
end

local function ShowAddonIconLayout(button)
    local layout = addonIconLayouts[button]
    if not layout then return end
    local stateful = button.DragonUI_UsesStateTextures
    local inset = stateful and 0 or 2
    local side = stateful and 24 or 21

    button.DragonUI_SkinActive = true
    button:SetSize(side, side)

    for _, hidden in ipairs({ button.DragonUI_DecoRegions, layout.extra }) do
        for _, region in ipairs(hidden) do region:SetAlpha(0) end
    end

    for _, region in ipairs(layout.primary) do
        region:SetAlpha(1)
        region:SetSinglePoint("TOPLEFT", button, "TOPLEFT", inset, -inset)
        region:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -inset, inset)
        local savedCoords = stateful and region.DragonUI_OrigTexCoord
        if savedCoords then
            region:SetTexCoord(unpack(savedCoords))
        else
            region:SetTexCoord(0.1, 0.9, 0.1, 0.9)
        end
        region:SetDrawLayer("ARTWORK")
    end

    for _, region in ipairs(button.DragonUI_HighlightRegions) do
        region:ClearAllPoints()
        region:SetAllPoints(button)
    end

    local ring = button.circle
    if ring then
        DressButtonRing(ring, stateful and 26 or 23)
        ring:Show()
    end

    button:SetAlpha(IsFadeEnabled() and 0.2 or 1)
end

local function ApplyAddonIconSkin(button)
    if not button or button:GetObjectType() ~= "Button" or IsQuestMinimapPin(button) then
        return
    end
    if not button.DragonUI_Skinned then
        BuildAddonIconLayout(button)
    end
    ShowAddonIconLayout(button)
end

-- Restore original button appearance (non-destructive toggle)
local function UnskinAddonButton(button)
    if not button or not button.DragonUI_Skinned then return end

    button.DragonUI_SkinActive = false

    -- Restore original size
    if button.DragonUI_OrigW then
        button:SetSize(button.DragonUI_OrigW, button.DragonUI_OrigH)
    end

    -- Restore decoration regions
    if button.DragonUI_DecoRegions then
        for _, region in ipairs(button.DragonUI_DecoRegions) do
            region:SetAlpha(region.DragonUI_OrigAlpha or 1)
        end
    end

    -- Restore icon regions to original positioning
    if button.DragonUI_IconRegions then
        for _, region in ipairs(button.DragonUI_IconRegions) do
            region:SetAlpha(region.DragonUI_OrigAlpha or 1)
            if region.DragonUI_OrigTexCoord then
                region:SetTexCoord(unpack(region.DragonUI_OrigTexCoord))
            else
                region:SetTexCoord(0, 1, 0, 1)
            end
            region:SetDrawLayer(region.DragonUI_OrigLayer or 'ARTWORK')
            region:ClearAllPoints()
            if region.DragonUI_OrigPoints then
                for _, pt in ipairs(region.DragonUI_OrigPoints) do
                    region:SetPoint(pt[1], pt[2], pt[3], pt[4], pt[5])
                end
            else
                region:SetAllPoints(button)
            end
            if region.DragonUI_OrigW then
                region:SetSize(region.DragonUI_OrigW, region.DragonUI_OrigH)
            end
        end
    end

    -- Restore highlight regions to original positioning
    if button.DragonUI_HighlightRegions then
        for _, region in ipairs(button.DragonUI_HighlightRegions) do
            region:ClearAllPoints()
            if region.DragonUI_OrigPoints then
                for _, pt in ipairs(region.DragonUI_OrigPoints) do
                    region:SetPoint(pt[1], pt[2], pt[3], pt[4], pt[5])
                end
            else
                region:SetAllPoints(button)
            end
            if region.DragonUI_OrigW then
                region:SetSize(region.DragonUI_OrigW, region.DragonUI_OrigH)
            end
        end
    end

    -- Hide DragonUI circle border
    if button.circle then button.circle:Hide() end

    -- Full alpha
    button:SetAlpha(1)
end

-- Skin addon icons by removing borders

-- Collect all minimap-related buttons from multiple parent frames
-- Some addons (e.g. Carbonite) parent buttons to MinimapBackdrop instead of Minimap
-- NOTE: Do NOT scan MinimapCluster - it contains Blizzard UI buttons (zone text,
-- zoom buttons, clock, etc.) that should never be skinned as addon icons.
local BLIZZARD_MINIMAP_BUTTONS = {
    ['MinimapZoneTextButton'] = true,
    ['MinimapZoomIn'] = true,
    ['MinimapZoomOut'] = true,
    ['MiniMapWorldMapButton'] = true,
    ['MinimapBackdrop'] = true,
    ['MiniMapBattlefieldFrame'] = true,
    ['MiniMapTrackingButton'] = true,
    ['MiniMapMailFrame'] = true,
    ['GameTimeFrame'] = true,
    ['TimeManagerClockButton'] = true,
    ['MiniMapInstanceDifficulty'] = true,
    ['MiniMapLFGFrame'] = true,   -- dungeon eye -has its own styling, skip skin
    ['MiniMapVoiceChatFrame'] = true,
    ['MiniMapVoiceChatFrameIcon'] = true,
    ['DragonUI_MinimapSettingsButton'] = true,
}

local function GetAllMinimapButtons()
    local buttons = {}
    local seen = {}

    local function TryAddButton(button)
        if not button or seen[button] or button:GetObjectType() ~= "Button" then
            return
        end

        local buttonName = button:GetName()
        if buttonName and BLIZZARD_MINIMAP_BUTTONS[buttonName] then
            return
        end
        if IsQuestMinimapPin(button) then
            return
        end

        seen[button] = true
        table.insert(buttons, button)
    end

    -- Scan direct Button children, plus one level of Frame wrappers (e.g. AtlasButtonFrame > AtlasButton).
    local function ScanFrame(parentFrame, nested)
        if not parentFrame then
            return
        end
        
        -- Addons like Questie parent hundreds of map pins directly to Minimap, which overflows the Lua
        -- C stack before we can filter them. pcall catches that error so we fail gracefully instead of
        -- spamming an error every frame.
        local ok, children = pcall(function() return { parentFrame:GetChildren() } end)
        if not ok then return end
        for i = 1, #children do
            local child = children[i]
            if not child then
            elseif child:GetObjectType() == "Button" then
                TryAddButton(child)
            elseif not nested and child:GetObjectType() == "Frame" then
                local childName = child:GetName()
                if not (childName and BLIZZARD_MINIMAP_BUTTONS[childName]) then
                    ScanFrame(child, true)
                end
            end
        end
    end

    -- Scan Minimap and MinimapBackdrop only
    -- MinimapCluster is excluded: it contains Blizzard frames (zone text, zoom, etc.)
    ScanFrame(Minimap, false)
    ScanFrame(MinimapBackdrop, false)

    return buttons
end

-- EnableMouse doesn't cascade to children, so every clickable minimap element (native Blizzard
-- buttons, third-party addon icons, collected icons) needs to be listed individually for the
-- hidden-minimap click-through to actually let clicks pass through everywhere, not just the circle.
local function CollectMinimapClickThroughFrames()
    local frames = {}
    for name in pairs(BLIZZARD_MINIMAP_BUTTONS) do
        -- MinimapBackdrop excluded: mouse-off overlay over the circle; enabling it eats native blip tooltips.
        local namedFrame = name ~= 'MinimapBackdrop' and _G[name]
        if namedFrame then table.insert(frames, namedFrame) end
    end
    for _, btn in ipairs(GetAllMinimapButtons()) do
        table.insert(frames, btn)
    end
    local iconCollector = MinimapModule.frames and MinimapModule.frames.iconCollector
    if iconCollector then
        local ok, children = pcall(function() return { iconCollector:GetChildren() } end)
        if ok then
            for _, child in ipairs(children) do
                if child and child.EnableMouse then table.insert(frames, child) end
            end
        end
    end
    return frames
end

-- ============================================================================
-- ADDON BUTTON DISTANCE
-- ============================================================================

-- LibDBIcon r15, still shipped by most 3.3.5a addons, has no SetButtonRadius, so its SetPoint is hooked.
local AddonButtonDistance = { hooked = {} }

function AddonButtonDistance.Get()
    -- Off while RestoreMinimapSystem hands the buttons back: it runs before `applied` clears.
    if AddonButtonDistance.off then return 0 end
    local settings = GetMinimapSettings()
    return IsDragonUIMinimapControlling() and settings and tonumber(settings.addon_button_distance) or 0
end

-- The r15 library, or nil when a newer one (with SetButtonRadius) is loaded.
function AddonButtonDistance.GetOldLibrary()
    if not LibStub or not LibStub.GetLibrary then return nil end
    local ok, libDBIcon = pcall(LibStub.GetLibrary, LibStub, "LibDBIcon-1.0", true)
    if ok and libDBIcon and type(libDBIcon.objects) == "table" and type(libDBIcon.SetButtonRadius) ~= "function" then
        return libDBIcon
    end
end

-- Offsets are in the button's launcher scale; scaling both keeps r15's square-map clamp square.
function AddonButtonDistance.OnSetPoint(button, point, relativeTo, relativePoint, x, y)
    if AddonButtonDistance.busy or point ~= "CENTER" or relativeTo ~= Minimap or type(x) ~= "number" then return end
    if button:GetParent() ~= Minimap then return end -- collected
    -- The collector puts back the point it saved on the way in, which is already pushed out.
    local placed = button.DragonUI_DistancePoint
    if placed and math.abs(x - placed[1]) < 0.05 and math.abs(y - placed[2]) < 0.05 then return end
    local distance = AddonButtonDistance.Get()
    button.DragonUI_Distance = distance
    if distance == 0 then
        button.DragonUI_DistancePoint = nil
        return
    end
    local orbit = LIBDBICON_ORBIT * button:GetScale()
    local outward = (orbit + distance) / orbit
    x, y = x * outward, y * outward
    placed = placed or {}
    placed[1], placed[2] = x, y
    button.DragonUI_DistancePoint = placed
    AddonButtonDistance.busy = true
    button:SetPoint(point, relativeTo, relativePoint, x, y)
    AddonButtonDistance.busy = nil
end

-- Collected buttons are the collector's to place; the library re-places the rest when their distance is stale.
function AddonButtonDistance.ApplyToOldLibrary()
    local libDBIcon = AddonButtonDistance.GetOldLibrary()
    if not libDBIcon then return end
    local distance = AddonButtonDistance.Get()
    for name, button in pairs(libDBIcon.objects) do
        if not AddonButtonDistance.hooked[button] then
            AddonButtonDistance.hooked[button] = true
            hooksecurefunc(button, "SetPoint", AddonButtonDistance.OnSetPoint)
        end
        if (button.DragonUI_Distance or 0) ~= distance and button:GetParent() == Minimap and libDBIcon.Refresh then
            -- With its saved db, so a button its addon hides stays hidden (Refresh shows it otherwise).
            libDBIcon:Refresh(name, button.db)
        end
    end
end

-- Compatibility: some addons ship LibDBIcon with a larger default radius,
-- which pushes minimap addon buttons farther from the map edge.
-- Keep this defensive and minimal: only clamp excessive defaults while DragonUI minimap is active.
local function NormalizeLibDBIconRadius()
    AddonButtonDistance.ApplyToOldLibrary()

    local libDBIcon = GetLibDBIcon()
    if not libDBIcon then return end

    local currentRadius = tonumber(libDBIcon.radius)
    if not currentRadius then return end
    if MinimapModule.originalStates.LibDBIconRadius == nil then
        if currentRadius <= 5 then return end
        MinimapModule.originalStates.LibDBIconRadius = currentRadius
    elseif currentRadius <= 5 and currentRadius ~= AddonButtonDistance.radius then
        return -- an addon picked its own small radius after ours
    end

    local radius = -5 + AddonButtonDistance.Get()
    if currentRadius ~= radius then
        libDBIcon:SetButtonRadius(radius)
    end
    AddonButtonDistance.radius = radius
end

local function RestoreLibDBIconRadius()
    -- r15 buttons: placed again with the distance off, so they go back to the library's own spot.
    AddonButtonDistance.off = true
    AddonButtonDistance.ApplyToOldLibrary()
    AddonButtonDistance.off = nil

    local originalRadius = MinimapModule.originalStates.LibDBIconRadius
    if originalRadius == nil then return end

    local libDBIcon = GetLibDBIcon()
    if libDBIcon then
        libDBIcon:SetButtonRadius(originalRadius)
    end

    MinimapModule.originalStates.LibDBIconRadius = nil
end

-- ============================================================================
-- MINIMAP ICON COLLECTOR (bridge to minimap_collector.lua)
-- ============================================================================

local function GetConfiguredMinimapCollector()
    local collector = addon and addon.MinimapCollector
    if not collector or type(collector.Configure) ~= "function" then
        return nil
    end

    collector:Configure({
        addon = addon,
        L = L,
        MinimapModule = MinimapModule,
        DRAGONUI_SETTINGS_BUTTON_SIZE = DRAGONUI_SETTINGS_BUTTON_SIZE,
        DRAGONUI_SETTINGS_BUTTON_ICON = DRAGONUI_SETTINGS_BUTTON_ICON,
        DRAGONUI_CLASSIC_COLLECTOR_ICON = DRAGONUI_CLASSIC_COLLECTOR_ICON,
        GetAllMinimapButtons = GetAllMinimapButtons,
        IsQuestMinimapPin = IsQuestMinimapPin,
        ApplyAddonIconSkin = ApplyAddonIconSkin,
        UnskinAddonButton = UnskinAddonButton,
        IsFadeEnabled = IsFadeEnabled,
        fadein = fadein,
        fadeout = fadeout,
        IsForeverActive = IsForeverActive,
        GetForeverOrbitRadius = GetForeverOrbitRadius,
        IsDragonUISquareFrame = IsDragonUISquareFrame,
        GetSquareArrowPlacement = GetSquareArrowPlacement,
        DRAGONUI_SQUARE_COLLECTOR_ICON = DRAGONUI_SQUARE_COLLECTOR_ICON,
        DressButtonRing = DressButtonRing,
        AdoptLauncher = AdoptLauncher,
    })

    return collector
end

local function RefreshIntegratedMinimapCollector()
    local collector = GetConfiguredMinimapCollector()
    if collector and collector.Refresh then
        collector:Refresh()
    end
end

local function HideIntegratedAddonMinimapButtons()
    local collector = GetConfiguredMinimapCollector()
    if collector and collector.HideIntegratedAddonButtons then
        collector:HideIntegratedAddonButtons()
    end
end

local function HideIntegratedMinimapCollector()
    local collector = GetConfiguredMinimapCollector()
    if collector and collector.Hide then
        collector:Hide()
    end
end

local function RestoreCollectedButtonsToOrigin()
    local collector = GetConfiguredMinimapCollector()
    if collector and collector.Restore then
        collector:Restore()
    end
end

local function UpdateDragonUISettingsButton()
    local collector = GetConfiguredMinimapCollector()
    if collector and collector.UpdateSettingsButton then
        collector:UpdateSettingsButton()
    end
end

-- Function to apply skins to all minimap buttons (exposed for re-application on addon load)
local function ApplySkinsToAllMinimapButtons()
    if not IsMinimapSystemActive() then return end

    local skinEnabled = addon.db and addon.db.profile and addon.db.profile.minimap and
                            addon.db.profile.minimap.addon_button_skin
    if not skinEnabled then return end

    local buttons = GetAllMinimapButtons()
    for _, child in ipairs(buttons) do
        -- Always re-apply. Some addons/editor transitions mutate existing icon regions in-place.
        ApplyAddonIconSkin(child)
    end
end

-- Update fade alpha on all addon buttons (works with or without skin)
local function UpdateAddonButtonFade()
    local fadeEnabled = IsFadeEnabled()
    local buttons = GetAllMinimapButtons()
    for _, child in ipairs(buttons) do
        if not IsQuestMinimapPin(child) then
            -- Hook fade scripts once if not already hooked
            if not child.DragonUI_FadeHooked then
                child.DragonUI_FadeHooked = true
                child:HookScript('OnEnter', fadein)
                child:HookScript('OnLeave', fadeout)
            end
            child:SetAlpha(fadeEnabled and 0.2 or 1)
        end
    end
end

-- Expose for options to trigger
MinimapModule.ApplySkinsToAllMinimapButtons = ApplySkinsToAllMinimapButtons

-- Unskin all addon buttons (toggle back to original Blizzard appearance)
local function UnskinAllMinimapButtons()
    local buttons = GetAllMinimapButtons()
    for _, child in ipairs(buttons) do
        if child.DragonUI_Skinned then
            UnskinAddonButton(child)
        end
    end
end
MinimapModule.UnskinAllMinimapButtons = UnskinAllMinimapButtons

local function RemoveAllMinimapIconBorders()

    -- PVP/Battlefield borders
    if MiniMapBattlefieldIcon then
        MiniMapBattlefieldIcon:Hide()
    end
    if MiniMapBattlefieldBorder then
        MiniMapBattlefieldBorder:Hide()
    end

    -- LFG border
    if MiniMapLFGFrameBorder then
        MiniMapLFGFrameBorder:SetTexture(nil)
    end

    -- Apply immediately
    ApplySkinsToAllMinimapButtons()
end

-- Create frame to re-apply skins when new addons load or after reload
local minimapButtonSkinFrame = CreateFrame("Frame")
minimapButtonSkinFrame:RegisterEvent("ADDON_LOADED")
minimapButtonSkinFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
minimapButtonSkinFrame:SetScript("OnEvent", function(self, event, addonName)
    if not IsMinimapSystemActive() then
        self:SetScript("OnUpdate", nil)
        return
    end

    if event == "PLAYER_ENTERING_WORLD" then
        -- Watch for new minimap children for a few seconds after login/reload.
        -- Re-scan periodically: some addons mutate existing icon regions without changing child count.
        local skinEnabled = addon.db and addon.db.profile and addon.db.profile.minimap and
            addon.db.profile.minimap.addon_button_skin
        if skinEnabled then
            ApplySkinsToAllMinimapButtons()
        end
        UpdateCalendarDate()
        RefreshIntegratedMinimapCollector()
        local elapsed = 0
        local checkInterval = 0
        self:SetScript("OnUpdate", function(self, dt)
            elapsed = elapsed + dt
            if elapsed > 6.0 then
                self:SetScript("OnUpdate", nil)
                return
            end
            checkInterval = checkInterval + dt
            if checkInterval >= 0.3 then
                checkInterval = 0
                if skinEnabled then
                    ApplySkinsToAllMinimapButtons()
                end
                UpdateCalendarDate()
                RefreshIntegratedMinimapCollector()
            end
        end)
        return
    end

    -- ADDON_LOADED handling
    -- Skip DragonUI's own loading to avoid double-processing
    if addonName == "DragonUI" then return end

    -- Apply defensive LibDBIcon compatibility for late-loading addons.
    NormalizeLibDBIconRadius()

    -- Allow the loading addon to create its minimap button before we rescan.
    local skinEnabled = addon.db and addon.db.profile and addon.db.profile.minimap and
        addon.db.profile.minimap.addon_button_skin
    local elapsed = 0
    self:SetScript("OnUpdate", function(self, dt)
        elapsed = elapsed + dt
        if elapsed > 0.5 then
            if skinEnabled then
                ApplySkinsToAllMinimapButtons()
            end
            RefreshIntegratedMinimapCollector()
            self:SetScript("OnUpdate", nil)
        end
    end)
end)

local function GetUnmanagedCollectorButtonCount()
    local buttons = GetAllMinimapButtons()
    local settingsButton = MinimapModule.frames and MinimapModule.frames.settingsButton
    local count = 0

    for _, child in ipairs(buttons) do
        if child ~= settingsButton and not IsQuestMinimapPin(child) and not child.DragonUI_CollectorManaged then
            count = count + 1
        end
    end

    return count
end

local minimapCollectorSyncFrame = CreateFrame("Frame")
local SetCollectorSyncEnabled
do
    local elapsed = 0
    local syncInterval = 1.00
    local lastUnmanagedCount = 0
    local lastMinimapChildCount = -1
    local lastBackdropChildCount = -1

    local function ResetSyncState()
        lastUnmanagedCount = 0
        lastMinimapChildCount = -1
        lastBackdropChildCount = -1
    end

    local function CollectorSync_OnUpdate(_, dt)
        elapsed = elapsed + dt
        if elapsed < syncInterval then
            return
        end
        elapsed = 0

        if not IsMinimapSystemActive() then
            ResetSyncState()
            return
        end

        local minimapConfig = addon.db and addon.db.profile and addon.db.profile.minimap
        if minimapConfig and minimapConfig.collector_enabled == false then
            ResetSyncState()
            return
        end

        local iconCollector = MinimapModule.frames and MinimapModule.frames.iconCollector
        if iconCollector and iconCollector.isOpen then
            ResetSyncState()
            return
        end

        local minimapChildCount = (Minimap and Minimap.GetNumChildren and Minimap:GetNumChildren()) or 0
        local backdropChildCount = (MinimapBackdrop and MinimapBackdrop.GetNumChildren and MinimapBackdrop:GetNumChildren()) or 0
        local childCountChanged = minimapChildCount ~= lastMinimapChildCount
            or backdropChildCount ~= lastBackdropChildCount

        if not childCountChanged then
            return
        end

        lastMinimapChildCount = minimapChildCount
        lastBackdropChildCount = backdropChildCount

        local unmanagedCount = GetUnmanagedCollectorButtonCount()
        if unmanagedCount <= 0 then
            lastUnmanagedCount = 0
            return
        end

        local shouldRefresh = unmanagedCount ~= lastUnmanagedCount

        lastUnmanagedCount = unmanagedCount

        if shouldRefresh then
            RefreshIntegratedMinimapCollector()
            if addon.VisibilityFade then
                addon.VisibilityFade.AddHoverFrames("minimap", CollectMinimapClickThroughFrames())
            end
        end
    end

    -- Armed by Apply, disarmed by Restore: a disabled module must not keep a per-frame poller.
    SetCollectorSyncEnabled = function(enabled)
        ResetSyncState()
        elapsed = 0
        minimapCollectorSyncFrame:SetScript("OnUpdate", enabled and CollectorSync_OnUpdate or nil)
    end
end

-- Style PVP battleground frame with faction detection
local function StylePVPBattlefieldFrame()
    if not MiniMapBattlefieldFrame then
        return
    end

    local pvpButton = MiniMapBattlefieldFrame
    pvpButton:SetSize(44, 44)
    if IsSquareLayout() then
        pvpButton:SetSinglePoint("BOTTOMRIGHT", Minimap, "BOTTOMRIGHT", -4, 4)
    else
        pvpButton:SetSinglePoint("BOTTOMLEFT", Minimap, "BOTTOMLEFT", 0, 18)
    end
    pvpButton:SetNormalTexture("")
    pvpButton:SetPushedTexture("")

    local faction = UnitFactionGroup("player")
    if faction then
        local atlasPrefix = "Minimap-PVP-" .. faction:lower()
        local normal, pushed = pvpButton:GetNormalTexture(), pvpButton:GetPushedTexture()
        if normal then normal:SetAtlasTexture(atlasPrefix .. "-Normal", true) end
        if pushed then pushed:SetAtlasTexture(atlasPrefix .. "-Pushed", true) end
    end

    -- Every module apply lands here; a second post-hook would toggle the PvP frame shut again.
    if not MinimapModule.hooks.battlefieldClick then
        MinimapModule.hooks.battlefieldClick = true
        pvpButton:HookScript("OnClick", function(self, mouseButton)
            if self.status ~= "active" and mouseButton ~= "RightButton" then
                TogglePVPFrame()
            end
        end)
    end
end

local function RemoveBlizzardFrames()
    -- Determine if hybrid mode is active
    local isHybridMode = MinimapModule.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))

    -- Hidden is enough, and its scripts stay: nulled, the button comes back dead if anything shows it.
    if MiniMapWorldMapButton then
        MiniMapWorldMapButton:Hide()
        MiniMapWorldMapButton:UnregisterAllEvents()
    end

    -- In hybrid mode, don't hide tracking/mail elements -SexyMap's Buttons module manages them
    if not isHybridMode then
        local blizzFrames =
            {MiniMapTrackingIcon, MiniMapTrackingIconOverlay, MiniMapMailBorder, MiniMapTrackingButtonBorder}

        for _, frame in pairs(blizzFrames) do
            frame:SetAlpha(0)
        end
    end

    -- Hide vanilla north indicator and compass -DragonUI doesn't use them
    if MinimapNorthTag then MinimapNorthTag:Hide() end
    if MinimapCompassTexture then MinimapCompassTexture:Hide() end

    --  CALL THE NEW FUNCTIONS
    RemoveAllMinimapIconBorders()
    StylePVPBattlefieldFrame()
    UpdateDragonUISettingsButton()
end

-- Stored on module table so the hooksecurefunc post-hook can reference it
-- without calling the global (which would cause infinite recursion)
MinimapModule.UpdateRotation = function()
    if not IsDragonUIMinimapControlling() then return end

    -- In hybrid mode, let SexyMap control the border visibility
    local isHybridMode = MinimapModule.sexyMapHybridMode
        or MinimapModule._allowExternalBorderControl

    if not isHybridMode then
        -- Always hide the vanilla MinimapBorder -DragonUI uses Minimap.Circle instead.
        -- Blizzard's Minimap_UpdateRotationSetting re-shows MinimapBorder when rotation
        -- is toggled off (e.g. closing Interface Options); our post-hook must counteract that.
        if MinimapBorder then
            MinimapBorder:Hide()
        end
    end

    if GetCVar("rotateMinimap") == "1" then
        if MinimapModule.borderFrame then
            MinimapModule.borderFrame:Show()
        end
        UpdateMinimapMaskForRotation()
        UpdateMinimapBackdropAlignment(false)
        UpdateIndoorRotateScale()
        UpdateMinimapCircleSize()
    else
        if MinimapModule.borderFrame then
            MinimapModule.borderFrame:Hide()
        end
        UpdateMinimapMaskForRotation()
        UpdateMinimapBackdropAlignment(false)
        UpdateIndoorRotateScale()
        UpdateMinimapCircleSize()
        if Minimap then
            ResetRingRotation()
        end
    end

    MinimapNorthTag:Hide()
    MinimapCompassTexture:Hide()
end

local selectedRaidDifficulty
local allowedRaidDifficulty

-- Update tracking icon using atlas textures
function MinimapModule:UpdateTrackingIcon()
    -- In hybrid mode, don't override tracking icon -SexyMap controls it
    local isHybridMode = self.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))
    if isHybridMode then return end

    local texture = GetTrackingTexture()

    local useOldStyle = addon.db and addon.db.profile and addon.db.profile.minimap and
                            addon.db.profile.minimap.tracking_icons

    --  SECURITY CHECK
    if not addon or not addon.db then
        return
    end

    if useOldStyle == nil then
        useOldStyle = false
    end

    --  ADDITIONAL CHECK: Ensure frames exist
    if not MiniMapTrackingIcon or not MiniMapTrackingButton then
        return
    end

    if useOldStyle then

        if texture == 'Interface\\Minimap\\Tracking\\None' then

            -- OLD STYLE + No tracking = Show default magnifying glass icon
            MiniMapTrackingIcon:SetTexture('')
            MiniMapTrackingIcon:SetAlpha(0)

            -- Show the modern button as default "magnifying glass icon"
            local normalTexture = MiniMapTrackingButton:GetNormalTexture()
            if normalTexture then
                normalTexture:SetAtlasTexture('Minimap-Tracking-Normal', true)
            end

            local pushedTexture = MiniMapTrackingButton:GetPushedTexture()
            if pushedTexture then
                pushedTexture:SetAtlasTexture('Minimap-Tracking-Pushed', true)
            end

            local highlightTexture = MiniMapTrackingButton:GetHighlightTexture()
            if highlightTexture then
                highlightTexture:SetAtlasTexture('Minimap-Tracking-Highlight', true)
            end
        else

            -- OLD STYLE + Tracking active = Show the specific tracking icon
            MiniMapTrackingIcon:SetTexture(texture)
            MiniMapTrackingIcon:SetTexCoord(0, 1, 0, 1)
            MiniMapTrackingIcon:SetSize(20, 20)
            MiniMapTrackingIcon:SetAlpha(1)
            MiniMapTrackingIcon:ClearAllPoints()
            MiniMapTrackingIcon:SetPoint('CENTER', MiniMapTracking, 'CENTER', TrackingPlateCenter())

            -- Clear button textures so they don't interfere with the specific icon
            MiniMapTrackingButton:SetNormalTexture('')
            MiniMapTrackingButton:SetPushedTexture('')
            local highlightTexture = MiniMapTrackingButton:GetHighlightTexture()
            if highlightTexture then
                highlightTexture:SetTexture('')
            end
        end
    else

        --  MODERN STYLE: Always show modern button (RetailUI style)

        -- Clear the classic icon so it doesn't interfere
        MiniMapTrackingIcon:SetTexture('')
        MiniMapTrackingIcon:SetAlpha(0)

        -- Use the RetailUI textures that already work (the ones from ReplaceBlizzardFrame)
        local normalTexture = MiniMapTrackingButton:GetNormalTexture()
        if normalTexture then
            normalTexture:SetAtlasTexture('Minimap-Tracking-Normal', true)
        end

        local pushedTexture = MiniMapTrackingButton:GetPushedTexture()
        if pushedTexture then
            pushedTexture:SetAtlasTexture('Minimap-Tracking-Pushed', true)
        end

        local highlightTexture = MiniMapTrackingButton:GetHighlightTexture()
        if highlightTexture then
            highlightTexture:SetAtlasTexture('Minimap-Tracking-Highlight', true)
        end

    end

    -- Always hide overlay
    if MiniMapTrackingIconOverlay then
        MiniMapTrackingIconOverlay:SetAlpha(0)
    end
end

-- =================================================================
-- MODULE ENABLE/DISABLE SYSTEM
-- =================================================================

function MinimapModule:StoreOriginalSettings()
    -- Store original Blizzard minimap settings
    if MinimapCluster then
        local point, relativeTo, relativePoint, xOfs, yOfs = MinimapCluster:GetPoint()
        self.originalMinimapSettings = {
            scale = MinimapCluster:GetScale(),
            point = point,
            relativeTo = relativeTo,
            relativePoint = relativePoint,
            xOfs = xOfs,
            yOfs = yOfs,
            isStored = true
        }
    end

    -- Store original DurabilityFrame settings
    if DurabilityFrame then
        local point, relativeTo, relativePoint, xOfs, yOfs = DurabilityFrame:GetPoint(1)
        self.originalMinimapSettings.durability = {
            scale = DurabilityFrame:GetScale(),
            point = point,
            relativeTo = relativeTo,
            relativePoint = relativePoint,
            xOfs = xOfs,
            yOfs = yOfs
        }
    end

    -- Store that we need to restore to Blizzard default mask
    if not self.originalMask then
        self.originalMask = "Textures\\MinimapMask" -- Standard Blizzard default

    end
end

-- Dungeon Eye editor frame -separate from full minimap init so it works
--    even when sexymap_mode == "sexymap" (micromenu styles LFG independently)
function MinimapModule:RegisterLFGEditorFrame()
    if not MiniMapLFGFrame then return end
    if self.lfgWrapper then return end  -- already registered

    -- Size wrapper to match the eye frame (hardcoded fallback: eye is ~52Ã—56)
    local lfgW = (MiniMapLFGFrame:GetWidth()  > 0 and MiniMapLFGFrame:GetWidth())  or 52
    local lfgH = (MiniMapLFGFrame:GetHeight() > 0 and MiniMapLFGFrame:GetHeight()) or 56
    local lfgWrapper = addon.CreateUIFrame(lfgW, lfgH, "LFGFrame")

    -- Apply saved or default position
    local lfgCfg    = addon.db and addon.db.profile.widgets and addon.db.profile.widgets.lfgframe
    local lfgAnchor = (lfgCfg and lfgCfg.anchor) or "TOPRIGHT"
    local lfgX      = (lfgCfg and lfgCfg.posX)   or -20
    local lfgY      = (lfgCfg and lfgCfg.posY)   or -220
    lfgWrapper:SetPoint(lfgAnchor, UIParent, lfgAnchor, lfgX, lfgY)

    -- Hook SetPoint/ClearAllPoints BEFORE reparenting so Blizzard can't move it
    local origLFGSetPoint       = MiniMapLFGFrame.SetPoint
    local origLFGClearAllPoints = MiniMapLFGFrame.ClearAllPoints
    local lfgLocked = false

    MiniMapLFGFrame.SetPoint = function(self, ...)
        if lfgLocked then return end
        origLFGSetPoint(self, ...)
    end
    MiniMapLFGFrame.ClearAllPoints = function(self)
        if lfgLocked then return end
        origLFGClearAllPoints(self)
    end

    -- Reparent and lock in place
    MiniMapLFGFrame:SetParent(lfgWrapper)
    origLFGClearAllPoints(MiniMapLFGFrame)
    origLFGSetPoint(MiniMapLFGFrame, "TOPLEFT", lfgWrapper, "TOPLEFT", 0, 0)
    lfgLocked = true

    -- Keep track of original Show/Hide so we can force-show in editor mode
    local origLFGShow = MiniMapLFGFrame.Show
    local origLFGHide = MiniMapLFGFrame.Hide

    -- Register wrapper in editor so it becomes a moveable mover
    addon:RegisterEditableFrame({
        name    = "lfgframe",
        frame   = lfgWrapper,
        configPath = {"widgets", "lfgframe"},
        showTest = function()
            -- Hide the real eye so the wrapper can receive mouse/drag events
            origLFGHide(MiniMapLFGFrame)
            lfgWrapper:Show()
        end,
        hideTest = function()
            -- Same test as MiniMapLFG_UpdateIsShown: the queue may have changed while editing.
            if GetLFGMode() then
                origLFGShow(MiniMapLFGFrame)
            else
                origLFGHide(MiniMapLFGFrame)
            end
        end,
        module  = self
    })

    self.lfgWrapper = lfgWrapper
end

-- Durability figure follows the minimap (and dodges the PvP capture bar) until dragged.
function MinimapModule:RegisterDurabilityEditorFrame()
    if not DurabilityFrame or durabilityMover then return end

    durabilityMover = addon.CreateUIFrame(DurabilityFrame:GetWidth(), DurabilityFrame:GetHeight(), "DurabilityFrame")
    durabilityMover:HookScript("OnDragStart", DetachDurabilityFrame)
    SyncDurabilityMover()

    addon:RegisterEditableFrame({
        name = "durability",
        frame = durabilityMover,
        blizzardFrame = DurabilityFrame,
        configPath = {"widgets", "durability"},
        showTest = function()
            SyncDurabilityMover()
            if not IsDurabilityCustomPlaced() then
                SnapDurabilityMoverToFigure()
            end
            durabilityMover:Show()
            durabilityFollower.cx, durabilityFollower.cy, durabilityFollower.scale = nil, nil, nil
            durabilityFollower:Show()
        end,
        onNudge = DetachDurabilityFrame,
        onHide = function()
            durabilityFollower:Hide()
            durabilityMover.DragonUI_WasDragged = nil
            durabilityMover.DragonUI_WasAdjustedByEditor = nil
            ApplyDurabilityPosition()
        end,
        module = self
    })

    self.durabilityMover = durabilityMover
end

function MinimapModule:ResetDurabilityPosition()
    local cfg = GetDurabilityConfig()
    if cfg then
        cfg.custom_position = false
    end
    ApplyDurabilityPosition()
end

function MinimapModule:ApplyMinimapSystem()
    if self.applied then
        return -- Already applied
    end

    -- Check module enabled state
    if not IsModuleEnabled() then
        return
    end

    -- If SexyMap-only mode, don't apply any DragonUI minimap modifications
    local minimapModuleConfig = addon.db and addon.db.profile and addon.db.profile.modules
        and addon.db.profile.modules.minimap
    if minimapModuleConfig and minimapModuleConfig.sexymap_mode == "sexymap" then
        -- Still register the LFG editor frame -micromenu styles it independently
        self:RegisterLFGEditorFrame()
        return
    end

    -- Check combat lockdown
    if InCombatLockdown() then
        addon.CombatQueue:Add("minimap_apply", function()
            MinimapModule:ApplyMinimapSystem()
        end)
        return
    end

    -- Store original settings before applying DragonUI changes
    self:StoreOriginalSettings()

    -- Defensive compatibility for LibDBIcon-based addon buttons.
    NormalizeLibDBIconRadius()
    HideIntegratedAddonMinimapButtons()
    
    RestoreForcedIndoorRotation()

    -- Initialize the DragonUI minimap system
    self._initializingMinimapSystem = true
    self:InitializeMinimapSystem()
    self.applied = true
    self._initializingMinimapSystem = nil
    self.isEnabled = true -- Legacy compatibility
    SetCollectorSyncEnabled(true)
end

function MinimapModule:RestoreMinimapSystem()
    if not self.applied then
        return -- Already restored
    end

    -- Check combat lockdown
    if InCombatLockdown() then
        addon.CombatQueue:Add("minimap_restore", function()
            MinimapModule:RestoreMinimapSystem()
        end)
        return
    end

    if addon.VisibilityFade then addon.VisibilityFade.Reset("minimap", 1) end

    self:RestoreFarmMode()

    SetCollectorSyncEnabled(false)

    -- Hide DragonUI frames
    if self.minimapFrame then
        self.minimapFrame:Hide()
        self.frames.minimapFrame = nil
    end
    if self.borderFrame then
        self.borderFrame:SetScript("OnUpdate", nil)
        self.borderFrame:Hide()
        self.frames.borderFrame = nil
    end
    if self.frames.settingsButton then
        self.frames.settingsButton:Hide()
    end
    HideIntegratedMinimapCollector()
    self._releasingLaunchers = true
    RestoreCollectedButtonsToOrigin()
    self._releasingLaunchers = nil

    if MinimapCluster then
        MinimapCluster:SetUserPlaced(false)
        MinimapCluster:SetDontSavePosition(false)
        MinimapCluster:SetMovable(false)
    end
    -- Restore original MinimapCluster state
    if MinimapCluster and self.originalStates.MinimapCluster then
        MinimapCluster:ClearAllPoints()
        local originalState = self.originalStates.MinimapCluster
        for _, point in ipairs(originalState.points) do
            MinimapCluster:SetPoint(unpack(point))
        end
        MinimapCluster:SetScale(originalState.scale)
    elseif MinimapCluster and self.originalMinimapSettings.isStored then
        -- Fallback to legacy method
        MinimapCluster:ClearAllPoints()
        MinimapCluster:SetPoint(self.originalMinimapSettings.point or "TOPRIGHT",
            self.originalMinimapSettings.relativeTo or UIParent,
            self.originalMinimapSettings.relativePoint or "TOPRIGHT", self.originalMinimapSettings.xOfs or -16,
            self.originalMinimapSettings.yOfs or -116)
        MinimapCluster:SetScale(self.originalMinimapSettings.scale or 1.0)
    end

    -- Restore original DurabilityFrame state
    if DurabilityFrame and self.originalStates.DurabilityFrame then
        DurabilityFrame:ClearAllPoints()
        local originalState = self.originalStates.DurabilityFrame
        for _, point in ipairs(originalState.points) do
            DurabilityFrame:SetPoint(unpack(point))
        end
        DurabilityFrame:SetScale(originalState.scale)
    elseif DurabilityFrame and self.originalMinimapSettings.durability then
        -- Fallback to legacy method
        local durSettings = self.originalMinimapSettings.durability
        DurabilityFrame:ClearAllPoints()
        DurabilityFrame:SetPoint(
            durSettings.point or "TOPLEFT",
            durSettings.relativeTo or MinimapCluster,
            durSettings.relativePoint or "BOTTOMLEFT",
            durSettings.xOfs or -15,
            durSettings.yOfs or -10
        )
        DurabilityFrame:SetScale(durSettings.scale or 1.0)
    end

    -- Restore other original states
    if MiniMapWorldMapButton then
        -- Its OnLoad took this to keep the binding in the tooltip; UnregisterAllEvents dropped it.
        MiniMapWorldMapButton:RegisterEvent("UPDATE_BINDINGS")
        MiniMapWorldMapButton:Show()
    end

    -- CRITICAL: Restore original Blizzard minimap mask
    if Minimap and self.originalMask then
        Minimap:SetMaskTexture(self.originalMask)
    end

    -- Restore original Blizzard blip texture
    if Minimap then
        MinimapModule._settingBlipTexture = true
        Minimap:SetBlipTexture('Interface\\Minimap\\ObjectIcons')
        MinimapModule._settingBlipTexture = false
    end

    -- Restore external LibDBIcon radius if we normalized it.
    RestoreLibDBIconRadius()

    -- Fully disable minimap icon/calendar styling when the module is toggled off.
    UnskinAllMinimapButtons()
    if GameTimeFrame and GameTimeFrame.GetFontString then
        local gameTimeText = GameTimeFrame:GetFontString()
        if gameTimeText then
            gameTimeText:Show()
        end
    end
    if GameTimeFrame_Update then
        GameTimeFrame_Update()
    end

    -- Cleanup hooks (tracked for debugging)
    CleanupSecureHooks()

    -- Stop DragonUI control before decoration teardown re-syncs rotation/mask state.
    self.applied = false
    self._initializingMinimapSystem = nil
    self.isEnabled = false -- Legacy compatibility

    if addon.MinimapDecorations and addon.MinimapDecorations.Restore then
        addon.MinimapDecorations:Restore()
    end

    -- Undo DragonUI-owned chrome only after we applied; never run this on cold start (fights other minimap addons).
    local wasHybrid = self.sexyMapHybridMode or self._allowExternalBorderControl
    if Minimap and Minimap.Circle then
        Minimap.Circle:Hide()
    end
    if self.squareBorder then
        self.squareBorder:Hide()
    end
    if foreverFrame then
        foreverFrame:Hide()
    end
    SyncCornerIconLevels(false)
    if self.appliedMapOffsetY and self.appliedMapOffsetY ~= MAP_OFFSET_Y and Minimap and MinimapCluster then
        Minimap:ClearAllPoints()
        Minimap:SetPoint("CENTER", MinimapCluster, "CENTER", 0, MAP_OFFSET_Y / blipScale)
    end
    self.appliedMapOffsetY = nil
    -- The Blizzard mask went back on above; a re-apply must not trust the cached one.
    self.activeMask = nil
    if not wasHybrid then
        if MinimapBorder then
            MinimapBorder:Show()
        end
        if MinimapBorderTop then
            MinimapBorderTop:ClearAllPoints()
            MinimapBorderTop:SetPoint("TOPRIGHT")
            MinimapBorderTop:SetTexture("Interface\\Minimap\\UI-Minimap-Border")
            MinimapBorderTop:SetTexCoord(0.25, 1.0, 0.0, 0.125)
            MinimapBorderTop:SetSize(192, 32)
            MinimapBorderTop:SetAlpha(1)
        end
        if MinimapBackdrop and MinimapCluster then
            MinimapBackdrop:ClearAllPoints()
            MinimapBackdrop:SetPoint("CENTER", MinimapCluster, "CENTER", 0, -20)
        end
        local blizzFrames = {
            MiniMapTrackingIcon, MiniMapTrackingIconOverlay, MiniMapMailBorder, MiniMapTrackingButtonBorder,
        }
        for _, frame in pairs(blizzFrames) do
            if frame then
                frame:SetAlpha(1)
            end
        end
    end
    if Minimap and self.activeMinimapScale then
        Minimap:SetScale(1)
        self.activeMinimapScale = nil
    end
    self.backdropYOffset = nil
    if Minimap_UpdateRotationSetting then
        Minimap_UpdateRotationSetting()
    end

    addon:Print(L["Minimap module restored to Blizzard defaults"])
end

-- Blips don't respect MinimapCluster's cascaded alpha (confirmed: swapping to Blizzard's stock
-- atlas only restyles them, doesn't hide them — they're still fully opaque). A nonexistent texture
-- path renders nothing at all, so point there while hidden instead of touching Minimap's own alpha,
-- which risks blips not refreshing until /reload.
local function ApplyBlipTextureForFadeVisibility(shouldShow)
    if not Minimap then return end
    local settings = addon.db and addon.db.profile and addon.db.profile.minimap
    if not settings then return end
    local texture
    if shouldShow then
        texture = settings.blip_skin and "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\objecticons"
            or 'Interface\\Minimap\\ObjectIcons'
    else
        texture = "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\blip_blank"
    end
    MinimapModule._settingBlipTexture = true
    Minimap:SetBlipTexture(texture)
    MinimapModule._settingBlipTexture = false
end

-- After the minimap's effective alpha (even cascaded, not just its own) sits at 0 for a while, the
-- client stops refreshing the terrain texture — it comes back frozen/blank until something like a
-- zoom change wakes it up. Bump the zoom a level and immediately revert it to force that refresh
-- without an actual visible zoom change.
local function ForceMinimapTerrainRefresh()
    if not Minimap or not Minimap.GetZoom or not Minimap.SetZoom then return end
    local currentZoom = Minimap:GetZoom()
    Minimap:SetZoom(currentZoom + 1)
    if Minimap:GetZoom() == currentZoom then
        Minimap:SetZoom(math.max(0, currentZoom - 1))
    end
    Minimap:SetZoom(currentZoom)
end

local function OnMinimapFadeComplete(shouldShow)
    if shouldShow then
        ForceMinimapTerrainRefresh()
    end
end

-- Alpha-only fade on MinimapCluster (never Minimap itself, and never Hide/Show) — Minimap's own
-- SetAlpha/Hide has been reported to stall blip texture updates in 3.3.5a until /reload.
local function SyncMinimapVisibility()
    if not MinimapCluster or not addon.VisibilityFade then return end
    local isHybridMode = MinimapModule.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))
    if isHybridMode then
        -- SexyMap owns the minimap's visuals in hybrid mode; don't fight it with our own fade.
        addon.VisibilityFade.Reset("minimap", 1)
        return
    end
    -- MinimapCluster's cascade covers Minimap/zone text/buttons, but DragonUI's own border ring
    -- (self.borderFrame) and the addon-icon collector are siblings parented to UIParent, not
    -- children — fade them explicitly too.
    local extraFrames = {}
    if MinimapModule.borderFrame then table.insert(extraFrames, MinimapModule.borderFrame) end
    local iconCollector = MinimapModule.frames and MinimapModule.frames.iconCollector
    if iconCollector then table.insert(extraFrames, iconCollector) end
    -- MinimapBackdrop excluded on purpose: mouse-off overlay over the circle; enabling it eats native blip tooltips.
    local hoverFrames = { MinimapCluster }
    if Minimap then table.insert(hoverFrames, Minimap) end
    if iconCollector then table.insert(hoverFrames, iconCollector) end
    addon.VisibilityFade.Register("minimap", MinimapCluster, {
        frames = extraFrames,
        hoverFrames = hoverFrames,
        -- IsMouseOver() polling (not OnEnter/OnLeave) so hovering any button drawn on top of the
        -- minimap (settings gear, addon icon collector, zoom, tracking...) still counts as hover —
        -- a plain geometric check doesn't care which frame actually wins the hit-test at that pixel.
        pollHover = true,
        -- Minimap isn't a secure/protected frame, so EnableMouse can react live even mid-combat.
        clickThrough = true,
        mouseSafeInCombat = true,
        onVisibilityChange = ApplyBlipTextureForFadeVisibility,
        onFadeComplete = OnMinimapFadeComplete,
        dbTable = function() return addon.db and addon.db.profile and addon.db.profile.minimap end,
    })
    addon.VisibilityFade.AddHoverFrames("minimap", CollectMinimapClickThroughFrames())
    addon.VisibilityFade.Update("minimap")
end
MinimapModule.SyncMinimapVisibility = SyncMinimapVisibility

-- Always on while editing: the client's minimap renderer breaks once the map is partly off screen.
function MinimapModule:ApplyEditorClamp()
    local mover = self.minimapFrame
    if not mover then return end
    if not self.editorActive then
        mover:SetClampRectInsets(0, 0, 0, 0)
        mover:SetClampedToScreen(false)
        return
    end

    local moverLeft, moverRight = mover:GetLeft(), mover:GetRight()
    local moverTop, moverBottom = mover:GetTop(), mover:GetBottom()
    if not (moverLeft and moverRight and moverTop and moverBottom) then return end
    local moverScale = mover:GetEffectiveScale()
    local left, right, top, bottom
    -- A top border faded out by Border Alpha 0 doesn't count; the zone text still can.
    for _, frame in ipairs({ Minimap, MinimapBorderTop, MinimapZoneTextButton }) do
        local shown = frame and frame:IsVisible() and frame:GetAlpha() > 0
        local frameLeft, frameRight = shown and frame:GetLeft(), shown and frame:GetRight()
        local frameTop, frameBottom = shown and frame:GetTop(), shown and frame:GetBottom()
        if frameLeft and frameRight and frameTop and frameBottom then
            -- Edges come back in each frame's own scaled units; a texture (the top border) has its parent's.
            local scaled = frame.GetEffectiveScale and frame or frame:GetParent()
            local ratio = scaled:GetEffectiveScale() / moverScale
            frameLeft, frameRight = frameLeft * ratio, frameRight * ratio
            frameTop, frameBottom = frameTop * ratio, frameBottom * ratio
            left = left and math.min(left, frameLeft) or frameLeft
            right = right and math.max(right, frameRight) or frameRight
            top = top and math.max(top, frameTop) or frameTop
            bottom = bottom and math.min(bottom, frameBottom) or frameBottom
        end
    end
    if not left then return end

    -- Positive left/bottom and negative right/top shrink the clamp rect toward the visible map.
    mover:SetClampRectInsets(left - moverLeft, right - moverRight, top - moverTop, bottom - moverBottom)
    mover:SetClampedToScreen(true)
end

function MinimapModule:InitializeMinimapSystem()
    -- Load TimeManager addon if not loaded
    if not IsAddOnLoaded('Blizzard_TimeManager') then
        LoadAddOn('Blizzard_TimeManager')
    end

    self.minimapFrame = addon.CreateUIFrame(230, 230, "MinimapFrame")
    -- Simple visual tweak: keep minimap editor overlay 10px lower.
    do
        if self.minimapFrame then
            self.minimapFrame.DragonUI_BoxShiftY = -10
            addon.SetEditorBoxScale(self.minimapFrame, addon.db.profile.minimap.scale or 1)
        end
        if self.minimapFrame and self.minimapFrame.editorText then
            self.minimapFrame.editorText:ClearAllPoints()
            self.minimapFrame.editorText:SetPoint("CENTER", self.minimapFrame, "CENTER", 0, -10)
        end
    end

    --  AUTOMATIC REGISTRATION IN THE CENTRALIZED SYSTEM
    addon:RegisterEditableFrame({
        name = "minimap",
        frame = self.minimapFrame,
        blizzardFrame = MinimapCluster,
        configPath = {"widgets", "minimap"},
        onShow = function()
            -- Match quest tracker behavior: clamp while editing.
            self.editorActive = true
            self:ApplyEditorClamp()
            -- Force full opacity while dragging so the user can actually see what they're moving.
            if addon.VisibilityFade then addon.VisibilityFade.Reset("minimap", 1) end
        end,
        onHide = function()
            -- Remove custom clamp settings after editor mode.
            self.editorActive = false
            self:ApplyEditorClamp()
            self:UpdateWidgets() -- Apply new configuration on editor exit
            addon:RefreshMinimap()
        end,
        module = self
    })

    -- Dungeon Eye (MiniMapLFGFrame) -independent moveable frame
    self:RegisterLFGEditorFrame()
    self:RegisterDurabilityEditorFrame()

    local defaultX, defaultY = -7, 0
    local widgetConfig = addon.db and addon.db.profile.widgets and addon.db.profile.widgets.minimap

    if widgetConfig then
        self.minimapFrame:SetPoint(widgetConfig.anchor or "TOPRIGHT", UIParent, widgetConfig.anchor or "TOPRIGHT",
            widgetConfig.posX or defaultX, widgetConfig.posY or defaultY)
    else
        self.minimapFrame:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", defaultX, defaultY)
    end

    -- Determine hybrid mode for conditional border creation
    local isHybridMode = self.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))

    if not isHybridMode then
        self.borderFrame = CreateMinimapBorderFrame(232, 232)
        -- Anchor to Minimap, not MinimapBorder: MinimapBorder keeps a fijo local-pixel
        -- size that doesn't re-scale with the client's uiScale slider, leaving the
        -- square border visually frozen while the rest of the UI resizes on reload.
        self.borderFrame:ClearAllPoints()
        self.borderFrame:SetPoint("CENTER", Minimap, "CENTER", -1, 3)
    end

    RemoveBlizzardFrames()
    ReplaceBlizzardFrame(self.minimapFrame)
    UpdateDragonUISettingsButton()

    --  ADD THIS LINE TO APPLY ALL SETTINGS AT STARTUP
    self:UpdateSettings()

    -- Must run AFTER UpdateSettings(): it unconditionally applies settings.blip_skin's texture,
    -- which would otherwise stomp the fade-aware blip texture chosen here right after login.
    SyncMinimapVisibility()

    if self.UpdateRotation then
        self.UpdateRotation()
    end

    -- Hook tracking changes to update icon automatically (not in hybrid mode)
    if not isHybridMode then
        MiniMapTrackingButton:HookScript("OnEvent", function()
            self:UpdateTrackingIcon()
        end)

        -- Initial tracking icon update
        self:UpdateTrackingIcon()
    end

    -- A /reload with farm mode on never goes through RefreshMinimap, so park here too.
    self:ApplyFarmMode()
end

function MinimapModule:Initialize()
    if self.initialized then
        return -- Already initialized
    end
    
    -- Check if minimap module is enabled
    if not IsModuleEnabled() then
        return
    end

    -- If SexyMap-only mode is saved, skip all DragonUI minimap modifications
    -- so SexyMap gets a clean, unmodified minimap to work with
    local minimapModuleConfig = addon.db and addon.db.profile and addon.db.profile.modules
        and addon.db.profile.modules.minimap
    if minimapModuleConfig and minimapModuleConfig.sexymap_mode == "sexymap" then
        -- Still register the LFG editor frame -the eye lives independently
        self:RegisterLFGEditorFrame()
        return
    end

    -- Only apply DragonUI modifications if module is enabled
    self:ApplyMinimapSystem()
    
    self.initialized = true
end

-- Remove functions that no longer exist and convert to DragonUI functions
function MinimapModule:UpdateSettings()
    local scale = GetEffectiveMinimapScale()

    if self.minimapFrame then
        local widgetConfig = addon.db.profile.widgets.minimap
        local anchor = widgetConfig.anchor or "TOPRIGHT"
        local x = widgetConfig.posX or 0
        local y = widgetConfig.posY or 0

        -- Update DurabilityFrame position
        if DurabilityFrame then
            DurabilityFrame:SetScale(addon.db.profile.minimap.scale or 1.0)
            SyncDurabilityMover()
            ApplyDurabilityPosition()
        end
        
        --  APPLY POSITION
        self.minimapFrame:ClearAllPoints()
        self.minimapFrame:SetPoint(anchor, UIParent, anchor, x, y)

        --  APPLY SCALE (works perfectly now)
        if MinimapCluster then
            MinimapCluster:SetScale(scale)
            addon.SetEditorBoxScale(self.minimapFrame, scale, GetMinimapGrowthPivot(self.minimapFrame))
        end

        if self.borderFrame then
            self.borderFrame:SetScale(scale)
        end

        ApplyStyleAnchors()
        UpdateForeverStyle()
        UpdateMinimapMaskForRotation()
        UpdateMinimapCircleSize()

        --  APPLY ALL SETTINGS
        self:ApplyAllSettings()
    end

    --  GLOBAL MINIMAP SETTINGS
    if Minimap then
        -- Apply blip texture based on user setting (new vs old style)
        local useNewBlipStyle = addon.db.profile.minimap.blip_skin
        if useNewBlipStyle == nil then
            useNewBlipStyle = true -- Default to new style
        end

        local blipTexture = useNewBlipStyle and "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\objecticons" or
                                'Interface\\Minimap\\ObjectIcons'
        -- Use re-entrancy guard to avoid triggering our own SetBlipTexture hook
        MinimapModule._settingBlipTexture = true
        Minimap:SetBlipTexture(blipTexture)
        MinimapModule._settingBlipTexture = false

        local playerArrowSize = addon.db.profile.minimap.player_arrow_size
        if playerArrowSize then
            Minimap:SetPlayerTextureHeight(playerArrowSize)
            Minimap:SetPlayerTextureWidth(playerArrowSize)
        end
    end

    --  REFRESH OTHER ELEMENTS
    self:UpdateTrackingIcon()

    if addon.MinimapDecorations and addon.MinimapDecorations.Refresh then
        addon.MinimapDecorations:Refresh()
    end

end

local function GetClockTextFrame()
    if not TimeManagerClockButton then
        return nil
    end

    -- Try multiple methods to find the clock text
    local clockText = TimeManagerClockButton.text
    if clockText then
        return clockText
    end

    clockText = TimeManagerClockButton:GetFontString()
    if clockText then
        return clockText
    end

    -- Search in children
    local children = { TimeManagerClockButton:GetChildren() }
    for i = 1, #children do
        local child = children[i]
        if child and child.GetFont then
            return child
        end
    end

    -- Search in regions
    for i = 1, TimeManagerClockButton:GetNumRegions() do
        local region = select(i, TimeManagerClockButton:GetRegions())
        if region and region.GetFont then
            return region
        end
    end

    return nil
end

local function SetShowClockCVar(enabled)
    if not (GetCVar and SetCVar) then
        return
    end

    local desired = enabled and "1" or "0"
    local current = GetCVar("showClock")
    if current ~= desired then
        SetCVar("showClock", desired)
    end
end

local function ApplyClockAndZoneLayout(showClock)
    if TimeManagerClockButton then
        if showClock then
            TimeManagerClockButton:Show()
        else
            TimeManagerClockButton:Hide()
        end
    end

    if MinimapZoneTextButton and MinimapBorderTop then
        MinimapZoneTextButton:ClearAllPoints()
        if showClock then
            -- Restore default DragonUI position when clock is visible.
            MinimapZoneTextButton:SetPoint("LEFT", MinimapBorderTop, "LEFT", 7, 1)
            MinimapZoneTextButton:SetWidth(108)
        else
            -- Center the zone text when clock is hidden.
            MinimapZoneTextButton:SetPoint("CENTER", MinimapBorderTop, "CENTER", 0, 1)
            MinimapZoneTextButton:SetWidth(150)
        end
    end

    if MinimapZoneText then
        MinimapZoneText:SetJustifyH(showClock and "LEFT" or "CENTER")
        if MinimapZoneTextButton then
            MinimapZoneText:SetAllPoints(MinimapZoneTextButton)
        end
    end
end

-- ============================================================================
-- FARM MODE TOGGLE
-- ============================================================================

-- Parked on a hidden holder, so they stay hidden whatever calls Show(); missing globals are skipped.
local FARM_MODE_CHROME = {
    "MinimapBorderTop",
    "MinimapZoneTextButton",
    "GameTimeFrame",
    "TimeManagerClockButton",
    "MiniMapTracking",
    "MiniMapMailFrame",
    "MiniMapInstanceDifficulty",
    "MiniMapBattlefieldFrame",
    "DragonUI_MinimapSettingsButton",
    "DragonUI_MinimapIconCollector",
}

function MinimapModule:ToggleFarmMode()
    local settings = GetMinimapSettings()
    if not settings or not IsMinimapSystemActive() then
        addon:Print(L["Minimap module not available."])
        return
    end

    local active = settings.farm_mode_enabled == true
    settings.farm_mode_enabled = not active

    addon:Print(active and L["Farm mode disabled"] or L["Farm mode enabled"])

    addon:RefreshMinimap()
end

local function CreateFarmModeHolder()
    local holder = CreateFrame("Frame", nil, UIParent)
    holder:Hide()
    return holder
end

local function SaveFrameLayers(frame, layers)
    if not frame.GetFrameLevel then return end
    layers[frame] = { frame:GetFrameStrata(), frame:GetFrameLevel() }
    local children = { frame:GetChildren() }
    for index = 1, #children do
        SaveFrameLayers(children[index], layers)
    end
end

-- Top-down, since a parent's SetFrameStrata also moves its children.
local function RestoreFrameLayers(frame, layers)
    if not frame.GetFrameLevel then return end
    local saved = layers[frame]
    if saved then
        if frame:GetFrameStrata() ~= saved[1] then frame:SetFrameStrata(saved[1]) end
        if frame:GetFrameLevel() ~= saved[2] then frame:SetFrameLevel(saved[2]) end
    end
    local children = { frame:GetChildren() }
    for index = 1, #children do
        RestoreFrameLayers(children[index], layers)
    end
end

-- Parents are read for everything before anything moves: a parked child would record the holder.
local function ParkFarmModeFrames()
    local holder = MinimapModule.farmMode.holder or CreateFarmModeHolder()
    MinimapModule.farmMode.holder = holder
    local parents, layers = MinimapModule.farmMode.parents, MinimapModule.farmMode.layers

    local parkable = {}
    for index = 1, #FARM_MODE_CHROME do
        local region = _G[FARM_MODE_CHROME[index]]
        if region and not parents[region] then
            parents[region] = region:GetParent()
            SaveFrameLayers(region, layers)
            parkable[#parkable + 1] = region
        end
    end

    for index = 1, #parkable do
        parkable[index]:SetParent(holder)
    end
end

-- SetParent resets strata and level (e.g. the gear sits at Minimap + 20), so both are put back.
local function RestoreFarmModeFrames()
    local parents, layers = MinimapModule.farmMode.parents, MinimapModule.farmMode.layers

    for region, parent in pairs(parents) do
        region:SetParent(parent)
    end
    for region in pairs(parents) do
        RestoreFrameLayers(region, layers)
    end
    wipe(parents)
    wipe(layers)
end

function MinimapModule:RestoreFarmMode()
    RestoreFarmModeFrames()
    self.farmMode.active = false
end

-- RefreshMinimap already queues this while in combat.
function MinimapModule:ApplyFarmMode()
    local settings = GetMinimapSettings()
    if not settings then return end

    if settings.farm_mode_enabled ~= true then
        if self.farmMode.active then self:RestoreFarmMode() end
        return
    end

    self.farmMode.active = true
    -- Hybrid hands the chrome to SexyMap; the bigger map still applies there.
    if IsHybridMinimapModeActive() then return end

    -- Runs while active too: chrome created since (the gear once the collector is enabled) gets parked.
    ParkFarmModeFrames()
end

-- Apply all minimap settings from the database
function MinimapModule:ApplyAllSettings()
    if not addon.db or not addon.db.profile or not addon.db.profile.minimap then
        return
    end

    local settings = addon.db.profile.minimap

    -- In hybrid mode, skip settings that modify DragonUI-styled elements
    -- (border top, zone text positioning, clock anchoring, calendar)
    -- SexyMap controls those visual elements
    local isHybridMode = self.sexyMapHybridMode
        or (addon.db and addon.db.profile and addon.db.profile.modules
            and addon.db.profile.modules.minimap
            and IsSexyMapHybridModeValue(addon.db.profile.modules.minimap.sexymap_mode))

    if not isHybridMode then
        --  APPLY BORDER ALPHA
        if MinimapBorderTop and settings.border_alpha then
            MinimapBorderTop:SetAlpha(settings.border_alpha)
        end

        --  APPLY CALENDAR VISIBILITY
        if settings.calendar ~= nil then
            if GameTimeFrame then
                if settings.calendar then
                    GameTimeFrame:Show()
                else
                    GameTimeFrame:Hide()
                end
            end
        end

        --  APPLY CLOCK VISIBILITY AND ADJUST ZONE TEXT
        if settings.clock ~= nil then
            SetShowClockCVar(settings.clock)
            ApplyClockAndZoneLayout(settings.clock)
        end
    end -- not isHybridMode (border, calendar, clock, zone text)

    --  APPLY ZOOM BUTTONS VISIBILITY (applies in all modes)
    if settings.zoom_buttons ~= nil then
        if MinimapZoomIn and MinimapZoomOut then
            if settings.zoom_buttons then
                MinimapZoomIn:Show()
                MinimapZoomOut:Show()
            else
                MinimapZoomIn:Hide()
                MinimapZoomOut:Hide()
            end
        end
    end

    -- Apply clock font size (skip in hybrid mode)
    if not isHybridMode and settings.clock_font_size and TimeManagerClockButton then
        local clockText = GetClockTextFrame()
        if clockText then
            local font, _, flags = clockText:GetFont()
            clockText:SetFont(font, settings.clock_font_size, flags)

        else

        end
    end

    --  APPLY ZONE TEXT FONT SIZE -skip in hybrid mode
    if not isHybridMode and settings.zonetext_font_size and MinimapZoneText then
        local font, _, flags = MinimapZoneText:GetFont()
        MinimapZoneText:SetFont(font, settings.zonetext_font_size, flags)
    end

    --  APPLY BLIP TEXTURE (NEW VS OLD STYLE)
    if settings.blip_skin ~= nil and Minimap then
        local blipTexture = settings.blip_skin and "Interface\\AddOns\\DragonUI\\Textures\\Minimap\\objecticons" or
                                'Interface\\Minimap\\ObjectIcons'
        Minimap:SetBlipTexture(blipTexture)
    end

    --  APPLY PLAYER ARROW SIZE
    if settings.player_arrow_size and Minimap then
        Minimap:SetPlayerTextureHeight(settings.player_arrow_size)
        Minimap:SetPlayerTextureWidth(settings.player_arrow_size)
    end

    UpdateCornerIconsPosition()
end
-- Editor mode interface
function MinimapModule:LoadDefaultSettings()
    -- Use correct database: addon.db (not addon.core.db)
    if not addon.db.profile.widgets then
        addon.db.profile.widgets = {}
    end
    addon.db.profile.widgets.minimap = {
        anchor = "TOPRIGHT",
        posX = 0,
        posY = 0
    }
end

function MinimapModule:UpdateWidgets()
    -- Use correct database: addon.db (not addon.core.db)
    if not addon.db or not addon.db.profile.widgets or not addon.db.profile.widgets.minimap then

        self:LoadDefaultSettings()
        return
    end

    local widgetOptions = addon.db.profile.widgets.minimap
    self.minimapFrame:SetPoint(widgetOptions.anchor, widgetOptions.posX, widgetOptions.posY)

end

-- Editor mode uses centralized system

-- Refresh function to be called from options.lua
function addon:RefreshMinimap()
    if InCombatLockdown() then
        if addon.CombatQueue then
            addon.CombatQueue:Add("minimap_refresh", addon.RefreshMinimap)
        end
        return
    end

    if MinimapModule.isEnabled then
        -- Parks or restores the chrome first: the settings pass below re-applies visibility.
        MinimapModule:ApplyFarmMode()
        MinimapModule:UpdateSettings()
        -- Also update tracking icon when settings change
        MinimapModule:UpdateTrackingIcon()
        MinimapModule.SyncMinimapVisibility()
        -- Addon Button Distance (LibDBIcon radius, or the r15 hook).
        NormalizeLibDBIconRadius()

        -- Refresh addon icon skinning
        local skinEnabled = addon.db and addon.db.profile and addon.db.profile.minimap
            and addon.db.profile.minimap.addon_button_skin
        if skinEnabled then
            RemoveAllMinimapIconBorders()
        else
            UnskinAllMinimapButtons()
        end

        -- Instant toggle for addon button fade
        UpdateAddonButtonFade()
        UpdateDragonUISettingsButton()

        if addon.MinimapDecorations and addon.MinimapDecorations.Refresh then
            addon.MinimapDecorations:Refresh()
        end

        -- Parks chrome this pass just created, e.g. the gear when the collector gets enabled.
        MinimapModule:ApplyFarmMode()

        -- Scale, style and farm mode move the map inside its mover; refit the editor clamp to it.
        if MinimapModule.editorActive then MinimapModule:ApplyEditorClamp() end
    end
end

-- Profile Callbacks for configuration change handling
MinimapModule.OnProfileChanged = function()
    addon:RefreshMinimapSystem()
end

MinimapModule.OnProfileCopied = function()
    addon:RefreshMinimapSystem()
end

MinimapModule.OnProfileReset = function()
    addon:RefreshMinimapSystem()
end

-- System refresh function for enable/disable
function addon:RefreshMinimapSystem()
    -- If SexyMap-only mode, never apply DragonUI minimap
    local minimapModuleConfig = addon.db and addon.db.profile and addon.db.profile.modules
        and addon.db.profile.modules.minimap
    if minimapModuleConfig and minimapModuleConfig.sexymap_mode == "sexymap" then
        if MinimapModule.applied then
            if addon:ShouldDeferModuleDisable("minimap", MinimapModule) then
                return
            end
            MinimapModule:RestoreMinimapSystem()
        end
        return
    end

    local isEnabled =
        addon.db and addon.db.profile and addon.db.profile.modules and addon.db.profile.modules.minimap and
            addon.db.profile.modules.minimap.enabled

    if isEnabled == nil then
        isEnabled = true -- Default to enabled
    end

    if isEnabled then
        if MinimapModule.applied then
            addon:RefreshMinimap()
        else
            MinimapModule:ApplyMinimapSystem()
        end
    else
        if addon:ShouldDeferModuleDisable("minimap", MinimapModule) then
            return
        end
        MinimapModule:RestoreMinimapSystem()
    end
end

-- Clean all skinned minimap button borders
-- Debug utility for minimap button inspection
function addon:DebugMinimapButtons()
    local buttons = GetAllMinimapButtons()
    for _, child in ipairs(buttons) do
        local name = child:GetName() or "Unnamed"
        local width, height = child:GetSize()
    end
end

-- =================================================================
-- INITIALIZATION
-- =================================================================

-- Initialize when the addon is ready
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("ADDON_LOADED")
initFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
initFrame:SetScript("OnEvent", function(self, event, addonName)
    if event == "ADDON_LOADED" and addonName == "DragonUI" then
        -- Set original mask to standard Blizzard default
        if not MinimapModule.originalMask then
            MinimapModule.originalMask = "Textures\\MinimapMask"
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        MinimapModule:Initialize()
        self:UnregisterAllEvents()
    end
end)

-- The farm map's size follows the UI scale, which changes without a reload.
local function RefreshFarmForUIScale()
    local settings = GetMinimapSettings()
    if settings and settings.farm_mode_enabled == true then addon:RefreshMinimap() end
end

addon.core.RegisterMessage(MinimapModule, "DRAGONUI_UI_SCALE_CHANGED", RefreshFarmForUIScale)
local uiScaleWatcher = CreateFrame("Frame")
uiScaleWatcher:RegisterEvent("UI_SCALE_CHANGED")
uiScaleWatcher:RegisterEvent("DISPLAY_SIZE_CHANGED")
-- A frame later: the client settles UIParent's scale around these events.
uiScaleWatcher:SetScript("OnEvent", function() addon:After(0, RefreshFarmForUIScale) end)
